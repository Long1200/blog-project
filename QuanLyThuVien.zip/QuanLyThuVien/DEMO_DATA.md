# Dữ liệu demo – Quản lý thư viện

Dữ liệu được nạp **tự động** khi chạy `dotnet run` lần đầu (file `Infrastructure/DemoData.cs`). Nạp 1 lần, chạy lại không bị nhân đôi.

- **Mật khẩu chung của mọi tài khoản độc giả: `Demo123`**
- Tài khoản admin: theo `Admin:Email` / `Admin:Password` đã đặt (mặc định `admin@thuvien.local`), đăng nhập tại `/admin/login`.

## Bật / tắt / làm mới (appsettings.json)
```json
"Demo": { "Enabled": true, "Reset": false }
```
- `Enabled = false`: không nạp dữ liệu demo.
- `Reset = true`: **xóa riêng dữ liệu demo** (thẻ TVD001–012, tài khoản docgia01–15 và mọi thứ gắn với chúng) rồi nạp lại với ngày tháng mới theo "hôm nay". Nên làm ngay trước buổi demo, chạy xong đặt lại `false`.
- Sách / thẻ / tài khoản bạn tự nhập **không bị đụng tới**.

## Độc giả và kịch bản demo
| Tài khoản (@thuvien.local) | Họ tên | Thẻ | Tình huống để demo |
|---|---|---|---|
| docgia01 | Nguyễn Minh Anh | TVD001 | Thẻ sạch, có 4 phiếu đã trả, không mượn gì → mượn mới, viết đánh giá |
| docgia02 | Trần Quốc Bảo | TVD002 | Đang mượn 3 cuốn, còn 10 ngày |
| docgia03 | Lê Thị Cẩm Tú | TVD003 | Đang mượn 2 cuốn, **sắp đến hạn** (huy hiệu vàng); thẻ sắp hết hạn |
| docgia04 | Phạm Gia Huy | TVD004 | Đang mượn 1 cuốn, **quá hạn 6 ngày** (huy hiệu đỏ) |
| docgia05 | Võ Thanh Hằng | TVD005 | Thẻ **bị khóa**: làm mất 1 cuốn, nợ 150.000 ₫ → demo thanh toán bồi thường, thẻ tự mở lại |
| docgia06 | Đặng Hoàng Long | TVD006 | Thẻ **bị khóa**: 1 hỏng + 1 mất, nợ 200.000 ₫ (thử tick/bỏ tick từng khoản) |
| docgia07 | Bùi Ngọc Mai | TVD007 | Thẻ **đã hết hạn** → demo gia hạn thẻ 50.000 ₫ |
| docgia08 | Hoàng Đức Thịnh | TVD008 | Từng làm hỏng sách, đã bồi thường xong, có lịch sử thanh toán |
| docgia09 | Ngô Khánh Linh | TVD009 | Vừa mượn 3 cuốn hôm nay |
| docgia10 | Đỗ Anh Tuấn | TVD010 | Không có phiếu dở → mượn tối đa 3 cuốn để demo giỏ mượn |
| docgia11 | Lý Phương Thảo | *(chưa liên kết)* | Demo **Liên kết thẻ**: nhập `TVD011` + `Lý Phương Thảo` |
| docgia12–15 | Dương Quang Vinh, Mai Thùy Dung, Huỳnh Thanh Phong, Phan Bảo Ngọc | – | Chỉ có đánh giá / bình luận / thích |
| *(không có tài khoản)* | Trịnh Văn Khoa | TVD012 | Admin lập phiếu mượn giúp; thẻ còn 12 ngày là hết hạn |

## Dữ liệu khác
- **Đánh giá sao + bình luận:** 84 đánh giá (5–7 / cuốn, điểm trung bình khoảng 3,5 → 4,9 sao), một số chỉ chấm sao không bình luận, vài bình luận có nhãn "đã chỉnh sửa". Mỗi tài khoản chỉ đánh giá 1 lần / sách (khớp unique index).
- **Thích / Không thích:** khoảng 100+ lượt, tỉ lệ theo số sao đánh giá.
- **Sách:** mỗi sách mẫu (trừ Harry Potter) có thêm đầu sách 004. **Harry Potter (VH003) bị mượn hết 3 bản** → demo trạng thái "hết sách".
- **Sách mất / hỏng:** VH013 mất, VH002 hỏng, VH004 mất (chưa bồi thường); VH009 hỏng, VH005 mất (đã bồi thường, VH005 thuộc **năm trước**) → báo cáo theo năm có ≥ 2 năm.
- **Sách hot / xếp hạng:** có lượt mượn thật trong 30 ngày gần đây (cộng với lượt mượn mẫu có sẵn).
- **Thanh toán:** 4 lần gia hạn thẻ + 2 lần bồi thường đã xử lý (MoMo, ZaloPay, ATM/Visa, chuyển khoản).
- **Sách bổ sung:** thêm 30 mã sách VH016–VH045 (file `Infrastructure/SeedMoreBooks.cs`), mỗi mã có 3 đầu sách 001–003, ảnh bìa, tóm tắt và lượt mượn mẫu. Tự nạp khi chạy `dotnet run` (chỉ thêm mã còn thiếu, không nhân đôi). Dữ liệu demo độc giả/phiếu mượn vẫn chỉ dùng 15 cuốn VH001–VH015.
