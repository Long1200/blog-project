using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using System.Text.RegularExpressions;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class BookController : Controller
    {
        private readonly MongoDbContext _context;

        public BookController(MongoDbContext context)
        {
            _context = context;
        }

        // Số sách hiển thị tối đa trên mỗi trang danh sách.
        private const int PageSize = 5;

        // Danh sách toàn bộ mã sách, có thể lọc theo từ khóa tìm kiếm (Mã sách/Tên sách/Tác giả/
        // Thể loại/Nhà xuất bản), và phân trang (mỗi trang tối đa PageSize cuốn) để không tải
        // một lèo toàn bộ dữ liệu khi số lượng sách lớn.
        public IActionResult Index(string? searchString, int page = 1)
        {
            ViewData["CurrentFilter"] = searchString;

            var filter = FilterDefinition<Book>.Empty;

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                // Regex không phân biệt hoa thường (Escape để ký tự đặc biệt như "." "(" được coi là chữ thường)
                // thay cho Contains() của EF; giữ hành vi tìm kiếm giống bản SQL Server cũ.
                var pattern = new BsonRegularExpression(Regex.Escape(searchString.Trim()), "i");
                var f = Builders<Book>.Filter;
                filter = f.Or(
                    f.Regex(b => b.BookCode, pattern),
                    f.Regex(b => b.Title, pattern),
                    f.Regex(b => b.Author, pattern),
                    f.Regex(b => b.Genre, pattern),
                    f.Regex(b => b.Publisher, pattern));
            }

            var totalCount = (int)_context.Books.CountDocuments(filter);
            var totalPages = totalCount == 0 ? 1 : (int)Math.Ceiling(totalCount / (double)PageSize);

            if (page < 1) page = 1;
            if (page > totalPages) page = totalPages;

            var books = _context.Books
                .Find(filter)
                .SortBy(b => b.BookCode)
                .Skip((page - 1) * PageSize)
                .Limit(PageSize)
                .ToList();

            ViewData["CurrentPage"] = page;
            ViewData["TotalPages"] = totalPages;

            return View(books);
        }

        // Chi tiết 1 mã sách kèm danh sách đầu sách (BookCopy) để partial _BookCopyList hiển thị.
        // MongoDB không có Include() nên nạp BookCopies thủ công ngay trong Controller,
        // đúng quy tắc không truy vấn DbContext trong View.
        public IActionResult Details(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var book = FindBookWithCopies(id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // Hiển thị form thêm mã sách mới
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Xử lý thêm mã sách mới. Kiểm tra trùng BookCode trước khi lưu vì BookCode là khóa
        // chính tự nhiên do thủ thư tự nhập, không phải khóa tự tăng nên rất dễ trùng.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Book book)
        {
            if (_context.Books.Find(b => b.BookCode == book.BookCode).Any())
            {
                ModelState.AddModelError(nameof(Book.BookCode), "Mã sách đã tồn tại");
            }

            if (!ModelState.IsValid)
            {
                return View(book);
            }

            try
            {
                _context.Books.InsertOne(book);
            }
            catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
            {
                // Hai thủ thư cùng thêm 1 mã trong cùng lúc: bước kiểm tra ở trên lọt qua nhưng _id vẫn chặn được
                ModelState.AddModelError(nameof(Book.BookCode), "Mã sách đã tồn tại");
                return View(book);
            }

            return RedirectToAction(nameof(Index));
        }

        // Hiển thị form sửa mã sách theo BookCode
        [HttpGet]
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var book = _context.Books.Find(b => b.BookCode == id).FirstOrDefault();
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // Xử lý cập nhật mã sách. Không cho đổi BookCode (khóa chính) qua form Edit;
        // chỉ $set đúng các field được sửa (không ReplaceOne cả document) để không
        // vô tình ghi đè những field khác của document.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(string id, Book book)
        {
            if (id != book.BookCode)
            {
                return NotFound();
            }

            if (!ModelState.IsValid)
            {
                return View(book);
            }

            var update = Builders<Book>.Update
                .Set(b => b.Title, book.Title)
                .Set(b => b.Author, book.Author)
                .Set(b => b.Genre, book.Genre)
                .Set(b => b.PublicationYear, book.PublicationYear)
                .Set(b => b.Publisher, book.Publisher)
                .Set(b => b.ImageUrl, book.ImageUrl)
                .Set(b => b.Summary, book.Summary);

            var result = _context.Books.UpdateOne(b => b.BookCode == id, update);
            if (result.MatchedCount == 0)
            {
                return NotFound();
            }

            return RedirectToAction(nameof(Index));
        }

        // Hiển thị trang xác nhận xóa, kèm số lượng đầu sách hiện có để cảnh báo trước
        [HttpGet]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var book = FindBookWithCopies(id);
            if (book == null)
            {
                return NotFound();
            }

            return View(book);
        }

        // Xử lý xóa mã sách. MongoDB không có Cascade nên bắt buộc tự chặn ở đây: nếu còn
        // BookCopy thì xóa Book sẽ để lại các đầu sách "mồ côi" trỏ tới mã sách không còn tồn tại.
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            var book = FindBookWithCopies(id);
            if (book == null)
            {
                return NotFound();
            }

            if (book.BookCopies.Any())
            {
                ModelState.AddModelError(string.Empty, "Không thể xóa mã sách này vì còn đầu sách (BookCopy) liên quan");
                return View("Delete", book);
            }

            _context.Books.DeleteOne(b => b.BookCode == id);

            return RedirectToAction(nameof(Index));
        }

        // Thay cho .Include(b => b.BookCopies): lấy Book rồi nạp các đầu sách theo BookCode,
        // sắp theo Số kiểm soát để danh sách hiển thị ổn định (001, 002, 003...).
        private Book? FindBookWithCopies(string bookCode)
        {
            var book = _context.Books.Find(b => b.BookCode == bookCode).FirstOrDefault();
            if (book == null)
            {
                return null;
            }

            book.BookCopies = _context.BookCopies
                .Find(c => c.BookCode == bookCode)
                .SortBy(c => c.ControlNumber)
                .ToList();

            return book;
        }
    }
}
