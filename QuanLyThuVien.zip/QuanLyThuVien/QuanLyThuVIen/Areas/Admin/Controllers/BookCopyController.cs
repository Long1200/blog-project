using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class BookCopyController : Controller
    {
        private readonly MongoDbContext _context;

        public BookCopyController(MongoDbContext context)
        {
            _context = context;
        }

        // Hiển thị form thêm đầu sách (BookCopy) mới cho 1 mã sách.
        // bookCode được truyền qua query string từ nút "+ Thêm đầu sách" ở trang Details của Book.
        [HttpGet]
        public IActionResult Create(string bookCode)
        {
            if (string.IsNullOrEmpty(bookCode))
            {
                return NotFound();
            }

            var book = _context.Books.Find(b => b.BookCode == bookCode).FirstOrDefault();
            if (book == null)
            {
                return NotFound();
            }

            // Gán sẵn BookCode vào model để form không cần người dùng tự nhập lại mã sách
            var bookCopy = new BookCopy { BookCode = bookCode };
            ViewBag.BookTitle = book.Title;

            return View(bookCopy);
        }

        // Xử lý thêm đầu sách mới. Kiểm tra trùng (BookCode, ControlNumber) ở tầng Controller
        // trước khi lưu, dù DB đã có unique index (tạo ở MongoDbContext.EnsureIndexes), để trả lỗi
        // rõ ràng lên form thay vì để văng MongoWriteException.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(BookCopy bookCopy)
        {
            var book = _context.Books.Find(b => b.BookCode == bookCopy.BookCode).FirstOrDefault();
            if (book == null)
            {
                return NotFound();
            }

            if (_context.BookCopies.Find(c => c.BookCode == bookCopy.BookCode && c.ControlNumber == bookCopy.ControlNumber).Any())
            {
                ModelState.AddModelError(nameof(BookCopy.ControlNumber), "Số kiểm soát này đã tồn tại cho mã sách này");
            }

            // Đầu sách mới thêm luôn ở tình trạng "Còn"; không cho chọn tình trạng khác ngay lúc tạo
            // (đổi tình trạng thủ công là chức năng riêng ở action ChangeStatus)
            bookCopy.Status = BookCopyStatus.Available;
            ModelState.Remove(nameof(BookCopy.Status));

            if (!ModelState.IsValid)
            {
                ViewBag.BookTitle = book.Title;
                return View(bookCopy);
            }

            // Id chỉ cấp sau khi đã qua kiểm tra hợp lệ để hạn chế tạo "lỗ hổng" trong dãy Id
            bookCopy.BookCopyId = _context.NextId(nameof(BookCopy));

            try
            {
                _context.BookCopies.InsertOne(bookCopy);
            }
            catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
            {
                // Có người vừa thêm cùng Số kiểm soát giữa lúc kiểm tra và lúc lưu: unique index chặn lại
                ModelState.AddModelError(nameof(BookCopy.ControlNumber), "Số kiểm soát này đã tồn tại cho mã sách này");
                ViewBag.BookTitle = book.Title;
                return View(bookCopy);
            }

            return RedirectToAction("Details", "Book", new { id = bookCopy.BookCode });
        }

        // Hiển thị form đổi tình trạng thủ công (Hỏng/Mất) cho 1 đầu sách
        [HttpGet]
        public IActionResult ChangeStatus(int id)
        {
            var bookCopy = _context.BookCopies.Find(c => c.BookCopyId == id).FirstOrDefault();
            if (bookCopy == null)
            {
                return NotFound();
            }

            return View(bookCopy);
        }

        // Xử lý đổi tình trạng thủ công. Chỉ cho đổi khi đầu sách đang KHÔNG ở trạng thái "Cho mượn";
        // nếu đang cho mượn thì phải xử lý qua chức năng Báo mất/Báo hỏng khi trả sách để đồng bộ với
        // LoanDetail/CompensationCase, không cho sửa tắt trực tiếp ở đây.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ChangeStatus(int id, BookCopyStatus newStatus)
        {
            var bookCopy = _context.BookCopies.Find(c => c.BookCopyId == id).FirstOrDefault();
            if (bookCopy == null)
            {
                return NotFound();
            }

            if (bookCopy.Status == BookCopyStatus.Borrowed)
            {
                ModelState.AddModelError(string.Empty, "Đầu sách đang cho mượn, phải xử lý qua chức năng Báo mất/Báo hỏng khi trả sách");
                return View(bookCopy);
            }

            if (newStatus != BookCopyStatus.Lost && newStatus != BookCopyStatus.Damaged)
            {
                ModelState.AddModelError(string.Empty, "Chỉ được đổi thủ công sang tình trạng Mất hoặc Hỏng");
                return View(bookCopy);
            }

            // Cập nhật có điều kiện (Status vẫn là giá trị vừa đọc): nếu trong lúc thủ thư đang xem form
            // mà đầu sách vừa được cho mượn thì không ghi đè nhầm tình trạng "Cho mượn".
            var result = _context.BookCopies.UpdateOne(
                c => c.BookCopyId == id && c.Status == bookCopy.Status,
                Builders<BookCopy>.Update.Set(c => c.Status, newStatus));

            if (result.MatchedCount == 0)
            {
                ModelState.AddModelError(string.Empty, "Tình trạng đầu sách vừa thay đổi, vui lòng tải lại trang và thử lại");
                var latest = _context.BookCopies.Find(c => c.BookCopyId == id).FirstOrDefault();
                return latest == null ? NotFound() : View(latest);
            }

            return RedirectToAction("Details", "Book", new { id = bookCopy.BookCode });
        }
    }
}
