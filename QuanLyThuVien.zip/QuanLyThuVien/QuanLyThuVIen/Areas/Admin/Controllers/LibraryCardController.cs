using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using System.Text.RegularExpressions;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class LibraryCardController : Controller
    {
        private readonly MongoDbContext _context;

        public LibraryCardController(MongoDbContext context)
        {
            _context = context;
        }

        // Danh sách toàn bộ thẻ thư viện, có thể lọc theo từ khóa (Số thẻ/Họ tên sinh viên).
        public IActionResult Index(string? searchString)
        {
            ViewData["CurrentFilter"] = searchString;

            var filter = FilterDefinition<LibraryCard>.Empty;

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                // Regex không phân biệt hoa thường thay cho Contains() của EF
                var pattern = new BsonRegularExpression(Regex.Escape(searchString.Trim()), "i");
                var f = Builders<LibraryCard>.Filter;
                filter = f.Or(
                    f.Regex(c => c.CardNumber, pattern),
                    f.Regex(c => c.StudentName, pattern));
            }

            var cards = _context.LibraryCards
                .Find(filter)
                .SortBy(c => c.CardNumber)
                .ToList();

            return View(cards);
        }

        // Chi tiết 1 thẻ thư viện. Danh sách phiếu mượn đang hoạt động và trang bồi thường/mở lại thẻ
        // chỉ đặt link sang LoanController/CompensationController ở View, không load sẵn dữ liệu ở đây
        // để Controller này không phải biết logic của Service khác.
        public IActionResult Details(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var card = FindCard(id);
            if (card == null)
            {
                return NotFound();
            }

            return View(card);
        }

        // Hiển thị form cấp thẻ thư viện mới
        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        // Xử lý cấp thẻ mới. Kiểm tra trùng CardNumber trước khi lưu vì CardNumber là khóa
        // chính tự nhiên do thư viện tự đặt, không phải khóa tự tăng nên rất dễ trùng.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(LibraryCard card)
        {
            if (_context.LibraryCards.Find(c => c.CardNumber == card.CardNumber).Any())
            {
                ModelState.AddModelError(nameof(LibraryCard.CardNumber), "Số thẻ đã tồn tại");
            }

            // Thẻ mới cấp luôn ở tình trạng "Sử dụng được"; không cho chọn tình trạng khác lúc cấp thẻ
            card.Status = LibraryCardStatus.Active;
            ModelState.Remove(nameof(LibraryCard.Status));

            if (!ModelState.IsValid)
            {
                return View(card);
            }

            // Trường ExpiryDate lưu dạng DateOnly nên phải cắt bỏ phần giờ trước khi ghi, nếu không driver báo lỗi
            card.ExpiryDate = card.ExpiryDate.Date;

            try
            {
                _context.LibraryCards.InsertOne(card);
            }
            catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
            {
                // Hai thủ thư cùng cấp 1 số thẻ trong cùng lúc: _id vẫn chặn được dù bước kiểm tra ở trên lọt qua
                ModelState.AddModelError(nameof(LibraryCard.CardNumber), "Số thẻ đã tồn tại");
                return View(card);
            }

            return RedirectToAction(nameof(Index));
        }

        // Hiển thị form gia hạn thẻ theo CardNumber
        [HttpGet]
        public IActionResult Edit(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var card = FindCard(id);
            if (card == null)
            {
                return NotFound();
            }

            return View(card);
        }

        // Xử lý gia hạn thẻ: CHỈ cập nhật Ngày hết hạn, không đụng tới Họ tên/Tình trạng.
        // Đổi tình trạng (khóa/mở) là chức năng riêng, xem action ToggleStatus bên dưới.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(string id, LibraryCard card)
        {
            if (id != card.CardNumber)
            {
                return NotFound();
            }

            var existing = FindCard(id);
            if (existing == null)
            {
                return NotFound();
            }

            if (card.ExpiryDate.Date < DateTime.Today)
            {
                ModelState.AddModelError(nameof(LibraryCard.ExpiryDate), "Ngày hết hạn mới phải từ hôm nay trở đi");
            }

            if (!ModelState.IsValid)
            {
                // Giữ lại Họ tên/Tình trạng thật của thẻ để hiển thị đúng trên form khi có lỗi
                card.StudentName = existing.StudentName;
                card.Status = existing.Status;
                return View(card);
            }

            // Chỉ $set đúng 1 field để không ghi đè Họ tên/Tình trạng (có thể vừa bị đổi bởi thao tác khác)
            _context.LibraryCards.UpdateOne(
                c => c.CardNumber == id,
                Builders<LibraryCard>.Update.Set(c => c.ExpiryDate, card.ExpiryDate.Date));

            return RedirectToAction(nameof(Details), new { id });
        }

        // Hiển thị trang xác nhận khóa/mở thẻ thủ công
        [HttpGet]
        public IActionResult ToggleStatus(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var card = FindCard(id);
            if (card == null)
            {
                return NotFound();
            }

            return View(card);
        }

        // Xử lý khóa/mở thẻ thủ công.
        // - Khóa tay (Active -> Inactive): luôn cho phép.
        // - Mở tay (Inactive -> Active): CHẶN nếu thẻ còn CompensationCase chưa xử lý (IsResolved = false),
        //   để nhất quán với CompensationService - bắt buộc phải bồi thường xong thì thẻ mới được mở lại,
        //   không cho thủ thư override bỏ qua bước bồi thường.
        [HttpPost, ActionName("ToggleStatus")]
        [ValidateAntiForgeryToken]
        public IActionResult ToggleStatusConfirmed(string id)
        {
            var card = FindCard(id);
            if (card == null)
            {
                return NotFound();
            }

            if (card.Status == LibraryCardStatus.Inactive)
            {
                var hasUnresolvedCase = _context.CompensationCases
                    .Find(c => c.CardNumber == card.CardNumber && !c.IsResolved)
                    .Any();

                if (hasUnresolvedCase)
                {
                    ModelState.AddModelError(string.Empty, "Không thể mở khóa thủ công: thẻ còn case bồi thường chưa xử lý. Phải bồi thường xong để thẻ tự mở lại.");
                    return View("ToggleStatus", card);
                }
            }

            var newStatus = card.Status == LibraryCardStatus.Active
                ? LibraryCardStatus.Inactive
                : LibraryCardStatus.Active;

            // Cập nhật có điều kiện theo tình trạng vừa đọc: nếu cùng lúc có thao tác khác (ví dụ báo mất sách
            // làm thẻ tự khóa) đã đổi tình trạng thì không lật ngược lại nhầm.
            var result = _context.LibraryCards.UpdateOne(
                c => c.CardNumber == id && c.Status == card.Status,
                Builders<LibraryCard>.Update.Set(c => c.Status, newStatus));

            if (result.MatchedCount == 0)
            {
                ModelState.AddModelError(string.Empty, "Tình trạng thẻ vừa thay đổi, vui lòng kiểm tra lại rồi thao tác tiếp");
                var latest = FindCard(id);
                return latest == null ? NotFound() : View("ToggleStatus", latest);
            }

            return RedirectToAction(nameof(Details), new { id = card.CardNumber });
        }

        // Hiển thị trang xác nhận xóa thẻ (kèm các cảnh báo: còn sách mượn, còn bồi thường, đang gắn với tài khoản...)
        [HttpGet]
        public IActionResult Delete(string id)
        {
            if (string.IsNullOrEmpty(id))
            {
                return NotFound();
            }

            var card = FindCard(id);
            if (card == null)
            {
                return NotFound();
            }

            FillDeleteInfo(card.CardNumber);
            return View(card);
        }

        // Xử lý xóa thẻ.
        // - CHẶN nếu thẻ còn sách đang mượn hoặc còn khoản bồi thường chưa xử lý (xóa lúc đó là mất dấu nợ).
        // - Nếu thẻ đang liên kết với tài khoản độc giả thì tự gỡ liên kết đó để tài khoản không giữ số thẻ đã xóa.
        // - Lịch sử phiếu mượn / thanh toán cũ vẫn giữ nguyên (chỉ còn số thẻ, không còn họ tên).
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(string id)
        {
            var card = FindCard(id);
            if (card == null)
            {
                return NotFound();
            }

            var info = FillDeleteInfo(card.CardNumber);
            if (info.ActiveLoanDetails > 0)
            {
                ModelState.AddModelError(string.Empty, "Không thể xóa: thẻ còn sách đang mượn. Hãy trả hết sách trước.");
                return View("Delete", card);
            }
            if (info.UnresolvedCases > 0)
            {
                ModelState.AddModelError(string.Empty, "Không thể xóa: thẻ còn khoản bồi thường chưa xử lý. Hãy xử lý xong bồi thường trước.");
                return View("Delete", card);
            }

            _context.LibraryCards.DeleteOne(c => c.CardNumber == card.CardNumber);

            // Gỡ liên kết ở mọi tài khoản đang giữ số thẻ này
            _context.Users.UpdateMany(
                u => u.LibraryCardNumber == card.CardNumber,
                Builders<ApplicationUser>.Update.Set(u => u.LibraryCardNumber, null));

            TempData["Success"] = $"Đã xóa thẻ {card.CardNumber} - {card.StudentName}.";
            return RedirectToAction(nameof(Index));
        }

        // Đếm các thứ liên quan tới thẻ để trang xác nhận xóa hiển thị cảnh báo, đồng thời dùng lại để chặn khi POST
        private (long ActiveLoanDetails, long UnresolvedCases, long LoanCount, string? LinkedEmail) FillDeleteInfo(string cardNumber)
        {
            var loanIds = _context.Loans.Find(l => l.CardNumber == cardNumber).Project(l => l.LoanId).ToList();

            long active = 0;
            if (loanIds.Count > 0)
            {
                active = _context.LoanDetails.CountDocuments(
                    Builders<LoanDetail>.Filter.In(ld => ld.LoanId, loanIds)
                    & Builders<LoanDetail>.Filter.Eq(ld => ld.Status, LoanDetailStatus.Borrowed));
            }

            var unresolved = _context.CompensationCases.CountDocuments(c => c.CardNumber == cardNumber && !c.IsResolved);
            var linked = _context.Users.Find(u => u.LibraryCardNumber == cardNumber).FirstOrDefault();

            ViewBag.ActiveLoanDetails = active;
            ViewBag.UnresolvedCases = unresolved;
            ViewBag.LoanCount = loanIds.Count;
            ViewBag.LinkedEmail = linked?.Email;

            return (active, unresolved, loanIds.Count, linked?.Email);
        }

        // Thay cho _context.LibraryCards.Find(id) của EF
        private LibraryCard? FindCard(string cardNumber)
        {
            return _context.LibraryCards.Find(c => c.CardNumber == cardNumber).FirstOrDefault();
        }
    }
}
