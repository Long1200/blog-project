using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    // Trang tổng quan của admin (trước đây là Home/Index): số liệu tổng hợp toàn hệ thống
    [Area("Admin")]
    [AdminOnly]
    public class DashboardController : Controller
    {
        private readonly MongoDbContext _context;

        public DashboardController(MongoDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var model = new DashboardViewModel
            {
                TotalBooks = (int)_context.Books.CountDocuments(FilterDefinition<Book>.Empty),
                TotalBookCopies = (int)_context.BookCopies.CountDocuments(FilterDefinition<BookCopy>.Empty),
                BorrowedCopies = (int)_context.BookCopies.CountDocuments(bc => bc.Status == BookCopyStatus.Borrowed),
                LostOrDamagedCopies = (int)_context.BookCopies.CountDocuments(bc =>
                    bc.Status == BookCopyStatus.Lost || bc.Status == BookCopyStatus.Damaged),
                TotalCards = (int)_context.LibraryCards.CountDocuments(FilterDefinition<LibraryCard>.Empty),
                LockedCards = (int)_context.LibraryCards.CountDocuments(c => c.Status == LibraryCardStatus.Inactive),
                ActiveLoans = _context.LoanDetails
                    .Distinct(ld => ld.LoanId, Builders<LoanDetail>.Filter.Eq(ld => ld.Status, LoanDetailStatus.Borrowed))
                    .ToList()
                    .Count,
                UnresolvedCompensationCases = (int)_context.CompensationCases.CountDocuments(c => !c.IsResolved)
            };

            return View(model);
        }
    }
}
