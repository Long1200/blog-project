using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using MongoDB.Bson;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;
using QuanLyThuVIen.Services;
using System.Text.RegularExpressions;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class LoanController : Controller
    {
        private readonly MongoDbContext _context;
        private readonly LoanService _loanService;

        public LoanController(MongoDbContext context, LoanService loanService)
        {
            _context = context;
            _loanService = loanService;
        }

        // Tra cứu toàn bộ phiếu mượn: tìm theo số thẻ, họ tên sinh viên, mã phiếu mượn (LoanId)
        // hoặc tên/mã sách đang có trong phiếu. Đây là trang danh sách chính của mục "Mượn sách".
        [HttpGet]
        public IActionResult Index(string? searchString)
        {
            ViewData["CurrentFilter"] = searchString;

            var filter = FilterDefinition<Loan>.Empty;

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                var keyword = searchString.Trim();

                // MongoDB không có JOIN nên không lọc theo cột của bảng khác được trong 1 truy vấn.
                // Cách làm: tìm "ngược" ở từng collection liên quan (thẻ, sách, đầu sách, dòng mượn)
                // để gom ra tập số thẻ/mã phiếu khớp từ khóa, rồi mới lọc Loans theo các tập đó.
                // Regex không phân biệt hoa thường để giống hành vi Contains trên SQL Server.
                var pattern = new BsonRegularExpression(Regex.Escape(keyword), "i");

                var matchedCardNumbers = _context.LibraryCards
                    .Find(Builders<LibraryCard>.Filter.Regex(c => c.StudentName, pattern))
                    .Project(c => c.CardNumber)
                    .ToList();

                var matchedBookCodes = _context.Books
                    .Find(Builders<Book>.Filter.Regex(b => b.BookCode, pattern)
                        | Builders<Book>.Filter.Regex(b => b.Title, pattern))
                    .Project(b => b.BookCode)
                    .ToList();

                var matchedCopyIds = _context.BookCopies
                    .Find(Builders<BookCopy>.Filter.In(bc => bc.BookCode, matchedBookCodes))
                    .Project(bc => bc.BookCopyId)
                    .ToList();

                var matchedLoanIds = _context.LoanDetails
                    .Find(Builders<LoanDetail>.Filter.In(ld => ld.BookCopyId, matchedCopyIds))
                    .Project(ld => ld.LoanId)
                    .ToList()
                    .Distinct()
                    .ToList();

                var loanFilters = Builders<Loan>.Filter;
                var conditions = new List<FilterDefinition<Loan>>
                {
                    loanFilters.Regex(l => l.CardNumber, pattern),
                    loanFilters.In(l => l.CardNumber, matchedCardNumbers),
                    loanFilters.In(l => l.LoanId, matchedLoanIds)
                };

                // Nhập số thì còn tìm chính xác theo mã phiếu mượn (LoanId)
                if (int.TryParse(keyword, out var loanId))
                {
                    conditions.Add(loanFilters.Eq(l => l.LoanId, loanId));
                }

                filter = loanFilters.Or(conditions);
            }

            var loans = _context.Loans
                .Find(filter)
                .SortByDescending(l => l.LoanDate)
                .ThenByDescending(l => l.LoanId)
                .ToList();

            // Nạp thẻ, dòng mượn, đầu sách, sách theo lô thay cho Include()
            _loanService.LoadRelations(loans);

            return View(loans);
        }

        // Hiển thị form tạo phiếu mượn mới
        [HttpGet]
        public IActionResult Create()
        {
            LoadSelectLists();

            var model = new LoanCreateViewModel { LoanDate = DateTime.Today };
            return View(model);
        }

        // Xử lý tạo phiếu mượn: gom 3 ô chọn mã sách thành danh sách rồi giao toàn bộ
        // việc validate + tạo Loan/LoanDetail cho LoanService.CreateLoan (đã viết ở 4.1-4.2),
        // Controller không tự kiểm tra lại nghiệp vụ để tránh trùng logic 2 nơi.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(LoanCreateViewModel model)
        {
            var bookCodes = new[] { model.BookCode1, model.BookCode2, model.BookCode3 }
                .Where(code => !string.IsNullOrWhiteSpace(code))
                .Select(code => code!)
                .ToList();

            // Chỉ kiểm tra định dạng cơ bản (có chọn mã sách hay không) ở Controller;
            // các quy tắc nghiệp vụ còn lại (trùng mã, quá 3 mã, thẻ khóa/hết hạn...)
            // đều do LoanService.CreateLoan kiểm tra.
            if (bookCodes.Count == 0)
            {
                ModelState.AddModelError(string.Empty, "Phải chọn ít nhất 1 mã sách để mượn");
            }

            if (!ModelState.IsValid)
            {
                LoadSelectLists();
                return View(model);
            }

            var result = _loanService.CreateLoan(model.CardNumber, bookCodes, model.LoanDate);

            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.ErrorMessage);
                LoadSelectLists();
                return View(model);
            }

            // Sau khi mượn thành công, quay về trang danh sách phiếu mượn đang hoạt động
            // của chính thẻ vừa mượn để thủ thư thấy ngay kết quả (bước 4.6)
            return RedirectToAction(nameof(ActiveLoans), new { cardNumber = model.CardNumber });
        }

        // Danh sách phiếu mượn đang hoạt động (tính runtime) của 1 thẻ - bước 4.6
        [HttpGet]
        public IActionResult ActiveLoans(string cardNumber)
        {
            if (string.IsNullOrEmpty(cardNumber))
            {
                return NotFound();
            }

            var card = _context.LibraryCards.Find(c => c.CardNumber == cardNumber).FirstOrDefault();
            if (card == null)
            {
                return NotFound();
            }

            var loans = _loanService.GetActiveLoans(cardNumber);
            ViewBag.Card = card;

            return View(loans);
        }

        // Hiển thị form xác nhận trả sách cho 1 dòng mượn - bước 5.3
        [HttpGet]
        public IActionResult Return(int id)
        {
            var detail = LoadLoanDetailForForm(id);
            if (detail == null)
            {
                return NotFound();
            }

            return View(detail);
        }

        // Xử lý trả sách. Ngày trả lấy theo ngày hiện tại của hệ thống (thủ thư xác nhận trả
        // ngay lúc thao tác), không cho tự nhập để tránh sai lệch dữ liệu.
        [HttpPost, ActionName("Return")]
        [ValidateAntiForgeryToken]
        public IActionResult ReturnConfirmed(int id)
        {
            var cardNumber = FindCardNumberOfLoanDetail(id);
            if (cardNumber == null)
            {
                return NotFound();
            }

            var result = _loanService.Return(id, DateTime.Today);

            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.ErrorMessage);
                var full = LoadLoanDetailForForm(id);
                if (full == null)
                {
                    return NotFound();
                }
                return View("Return", full);
            }

            return RedirectToAction(nameof(ActiveLoans), new { cardNumber });
        }

        // Hiển thị form báo mất/báo hỏng cho 1 dòng mượn - bước 5.4
        [HttpGet]
        public IActionResult ReportLostOrDamaged(int id)
        {
            var detail = LoadLoanDetailForForm(id);
            if (detail == null)
            {
                return NotFound();
            }

            return View(detail);
        }

        // Xử lý báo mất/báo hỏng. Ngày phát sinh lấy theo ngày hiện tại của hệ thống, cùng lý do
        // với action Return để đảm bảo dữ liệu báo cáo (Giai đoạn 7) chính xác theo thời gian thực.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ReportLostOrDamaged(int id, CompensationReason reason)
        {
            var cardNumber = FindCardNumberOfLoanDetail(id);
            if (cardNumber == null)
            {
                return NotFound();
            }

            var result = _loanService.ReportLostOrDamaged(id, reason, DateTime.Today);

            if (!result.Success)
            {
                ModelState.AddModelError(string.Empty, result.ErrorMessage);
                var full = LoadLoanDetailForForm(id);
                if (full == null)
                {
                    return NotFound();
                }
                return View(full);
            }

            return RedirectToAction(nameof(ActiveLoans), new { cardNumber });
        }

        // Lấy 1 LoanDetail kèm BookCopy/Book/Loan để đổ đủ thông tin cho form Return/ReportLostOrDamaged,
        // dùng chung cho cả action GET và action POST khi cần hiển thị lại form lúc có lỗi.
        private LoanDetail? LoadLoanDetailForForm(int id)
        {
            var detail = _context.LoanDetails.Find(ld => ld.LoanDetailId == id).FirstOrDefault();
            if (detail == null)
            {
                return null;
            }

            // Nạp BookCopy + Book qua hàm dùng chung, riêng Loan nạp tay vì chỉ có 1 phiếu cha
            _loanService.LoadDetailRelations(new[] { detail });
            detail.Loan = _context.Loans.Find(l => l.LoanId == detail.LoanId).FirstOrDefault();

            return detail;
        }

        // Chỉ cần số thẻ của dòng mượn (để chuyển hướng sau khi xử lý) nên chỉ đọc đúng 2 trường,
        // không nạp cả đối tượng. Trả null nếu dòng mượn hoặc phiếu cha không tồn tại.
        private string? FindCardNumberOfLoanDetail(int loanDetailId)
        {
            var loanId = _context.LoanDetails
                .Find(ld => ld.LoanDetailId == loanDetailId)
                .Project(ld => (int?)ld.LoanId)
                .FirstOrDefault();

            if (loanId == null)
            {
                return null;
            }

            return _context.Loans
                .Find(l => l.LoanId == loanId.Value)
                .Project(l => l.CardNumber)
                .FirstOrDefault();
        }

        // Chuẩn bị danh sách thẻ + danh sách sách để đổ vào 2 dropdown của form Create,
        // lấy dữ liệu phụ trợ 1 lần trong Controller rồi truyền qua ViewBag theo đúng quy tắc.
        private void LoadSelectLists()
        {
            // Chỉ lấy đúng 2 trường cần hiển thị, sắp xếp ở phía MongoDB, ghép chuỗi ở phía C#
            ViewBag.Cards = _context.LibraryCards
                .Find(FilterDefinition<LibraryCard>.Empty)
                .SortBy(c => c.CardNumber)
                .Project(c => new { c.CardNumber, c.StudentName })
                .ToList()
                .Select(c => new SelectListItem
                {
                    Value = c.CardNumber,
                    Text = c.CardNumber + " - " + c.StudentName
                })
                .ToList();

            ViewBag.Books = _context.Books
                .Find(FilterDefinition<Book>.Empty)
                .SortBy(b => b.BookCode)
                .Project(b => new { b.BookCode, b.Title })
                .ToList()
                .Select(b => new SelectListItem
                {
                    Value = b.BookCode,
                    Text = b.BookCode + " - " + b.Title
                })
                .ToList();
        }
    }
}
