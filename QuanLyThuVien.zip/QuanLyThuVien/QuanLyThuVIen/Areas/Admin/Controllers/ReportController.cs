using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Services;
using System.Text.RegularExpressions;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class ReportController : Controller
    {
        private readonly MongoDbContext _context;
        private readonly LoanService _loanService;

        public ReportController(MongoDbContext context, LoanService loanService)
        {
            _context = context;
            _loanService = loanService;
        }

        // Báo cáo sách mất/hỏng theo năm, tính theo năm phát sinh case bồi thường (CreatedDate)
        // vì đây là ngày thủ thư ghi nhận mất/hỏng, đúng với nghiệp vụ "báo cáo hàng năm để thanh lý".
        // year = null: hiển thị toàn bộ các năm, không lọc.
        [HttpGet]
        public IActionResult Index(int? year, string? searchString)
        {
            // Lấy trước danh sách các năm đã từng phát sinh case (chưa lọc) để đổ vào dropdown lọc trên View
            ViewBag.Years = _context.CompensationCases
                .Distinct(c => c.CreatedDate, FilterDefinition<CompensationCase>.Empty)
                .ToList()
                .Select(d => d.Year)
                .Distinct()
                .OrderByDescending(y => y)
                .ToList();

            var f = Builders<CompensationCase>.Filter;
            var conditions = new List<FilterDefinition<CompensationCase>>();

            if (year.HasValue)
            {
                // Lọc theo khoảng ngày [1/1, 1/1 năm sau) thay cho c.CreatedDate.Year của EF
                // vì khoảng ngày dùng được index và luôn dịch được sang truy vấn MongoDB.
                conditions.Add(f.Gte(c => c.CreatedDate, new DateTime(year.Value, 1, 1))
                    & f.Lt(c => c.CreatedDate, new DateTime(year.Value + 1, 1, 1)));
            }

            if (!string.IsNullOrWhiteSpace(searchString))
            {
                conditions.Add(BuildSearchFilter(searchString.Trim()));
            }

            var filter = conditions.Count == 0 ? FilterDefinition<CompensationCase>.Empty : f.And(conditions);

            ViewBag.SelectedYear = year;
            ViewData["CurrentFilter"] = searchString;

            var cases = _context.CompensationCases
                .Find(filter)
                .SortByDescending(c => c.CreatedDate)
                .ThenByDescending(c => c.CompensationCaseId)
                .ToList();

            LoadRelations(cases);

            return View(cases);
        }

        // MongoDB không có JOIN nên không lọc theo cột của collection khác trong 1 truy vấn được.
        // Cách làm: tìm "ngược" ở từng collection liên quan (thẻ, sách, đầu sách, dòng mượn) để gom ra
        // tập Số thẻ / Id dòng mượn khớp từ khóa, rồi mới lọc CompensationCases theo các tập đó.
        // Khớp theo: Số thẻ, Họ tên sinh viên, Mã sách, Tên sách (giống bản EF cũ).
        private FilterDefinition<CompensationCase> BuildSearchFilter(string keyword)
        {
            var pattern = new BsonRegularExpression(Regex.Escape(keyword), "i");

            var matchedCardNumbers = _context.LibraryCards
                .Find(Builders<LibraryCard>.Filter.Regex(c => c.StudentName, pattern))
                .Project(c => c.CardNumber)
                .ToList();

            var matchedBookCodes = _context.Books
                .Find(Builders<Book>.Filter.Regex(b => b.BookCode, pattern)
                    | Builders<Book>.Filter.Regex(b => b.Title, pattern))
                .Project(b => b.BookCode)
                .ToList();

            var matchedCopyIds = _context.BookCopies
                .Find(Builders<BookCopy>.Filter.In(bc => bc.BookCode, matchedBookCodes))
                .Project(bc => bc.BookCopyId)
                .ToList();

            var matchedDetailIds = _context.LoanDetails
                .Find(Builders<LoanDetail>.Filter.In(ld => ld.BookCopyId, matchedCopyIds))
                .Project(ld => ld.LoanDetailId)
                .ToList();

            var f = Builders<CompensationCase>.Filter;
            return f.Or(
                f.Regex(c => c.CardNumber, pattern),
                f.In(c => c.CardNumber, matchedCardNumbers),
                f.In(c => c.LoanDetailId, matchedDetailIds));
        }

        // Thay cho Include().ThenInclude(): nạp LoanDetail -> BookCopy -> Book và LibraryCard
        // cho cả danh sách case bằng vài truy vấn theo lô (không truy vấn lặp theo từng case).
        private void LoadRelations(List<CompensationCase> cases)
        {
            if (cases.Count == 0)
            {
                return;
            }

            var detailIds = cases.Select(c => c.LoanDetailId).Distinct().ToList();
            var details = _context.LoanDetails
                .Find(Builders<LoanDetail>.Filter.In(ld => ld.LoanDetailId, detailIds))
                .ToList();
            // Dùng lại hàm nạp BookCopy + Book của LoanService để không viết trùng logic
            _loanService.LoadDetailRelations(details);
            var detailById = details.ToDictionary(d => d.LoanDetailId);

            var cardNumbers = cases.Select(c => c.CardNumber).Distinct().ToList();
            var cardByNumber = _context.LibraryCards
                .Find(Builders<LibraryCard>.Filter.In(c => c.CardNumber, cardNumbers))
                .ToList()
                .ToDictionary(c => c.CardNumber);

            foreach (var c in cases)
            {
                c.LoanDetail = detailById.GetValueOrDefault(c.LoanDetailId);
                c.LibraryCard = cardByNumber.GetValueOrDefault(c.CardNumber);
            }
        }
    }
}
