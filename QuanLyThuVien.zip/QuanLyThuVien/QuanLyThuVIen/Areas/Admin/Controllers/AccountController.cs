using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;

namespace QuanLyThuVIen.Areas.Admin.Controllers
{
    // Đăng nhập riêng cho khu vực quản trị: /admin/login. Chỉ tài khoản có IsAdmin = true mới vào được.
    [Area("Admin")]
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;

        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }

        [HttpGet("admin/login")]
        public async Task<IActionResult> Login(string? returnUrl = null, bool denied = false)
        {
            if (User.Identity?.IsAuthenticated == true)
            {
                var current = await _userManager.GetUserAsync(User);
                if (current is { IsAdmin: true })
                    return RedirectToAction("Index", "Dashboard");
            }

            if (denied) ViewData["Denied"] = true;
            return View(new LoginViewModel { ReturnUrl = returnUrl });
        }

        [HttpPost("admin/login")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid) return View(model);

            // Cùng một thông báo cho "không có tài khoản", "không phải admin" và "sai mật khẩu"
            // để người ngoài không dò được email nào là admin.
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null || !user.IsAdmin)
            {
                ModelState.AddModelError(string.Empty, "Email hoặc mật khẩu không đúng");
                return View(model);
            }

            var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, lockoutOnFailure: true);
            if (result.IsLockedOut)
            {
                ModelState.AddModelError(string.Empty, "Tài khoản tạm khóa do đăng nhập sai nhiều lần, vui lòng thử lại sau");
                return View(model);
            }
            if (!result.Succeeded)
            {
                ModelState.AddModelError(string.Empty, "Email hoặc mật khẩu không đúng");
                return View(model);
            }

            if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
                return Redirect(model.ReturnUrl);
            return RedirectToAction("Index", "Dashboard");
        }

        [HttpPost("admin/logout")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction(nameof(Login));
        }
    }
}
