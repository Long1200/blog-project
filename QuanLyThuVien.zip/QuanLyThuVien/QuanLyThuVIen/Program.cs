using Microsoft.AspNetCore.Authentication.Facebook;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Identity;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Đăng ký MongoDB: đọc cấu hình mục "MongoDb" (ConnectionString đặt trong User Secrets, không
// ghi vào appsettings.json để tránh lộ mật khẩu khi nộp bài/đẩy lên Git).
// Singleton vì MongoClient an toàn đa luồng và nên dùng chung cả ứng dụng.
builder.Services.Configure<MongoDbSettings>(builder.Configuration.GetSection("MongoDb"));
builder.Services.AddSingleton<MongoDbContext>();

// ---------- ASP.NET Core Identity: đăng ký / đăng nhập / trang cá nhân ----------
// Dùng AddIdentityCore (không AddIdentity) vì đồ án chưa có Role, nên không cần RoleManager/RoleStore.
// Nơi lưu tài khoản là MongoUserStore thay cho AddEntityFrameworkStores.
// RequireDigit + RequireLowercase (không RequireUppercase, không RequireNonAlphanumeric):
// bắt buộc mật khẩu có cả chữ và số, không bắt buộc ký tự đặc biệt/hoa để người dùng dễ đặt.
builder.Services.AddIdentityCore<ApplicationUser>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequiredLength = 6;

    options.User.RequireUniqueEmail = true;

    options.Lockout.MaxFailedAccessAttempts = 5;
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
})
    .AddUserStore<MongoUserStore>()
    .AddSignInManager()
    .AddDefaultTokenProviders();

// Scheme mặc định là cookie Identity; đăng nhập ngoài (Google/Facebook) dùng cookie tạm "External"
// để giữ thông tin giữa lúc chuyển sang nhà cung cấp và lúc quay về ExternalLoginCallback.
var authBuilder = builder.Services.AddAuthentication(options =>
{
    options.DefaultScheme = IdentityConstants.ApplicationScheme;
    options.DefaultSignInScheme = IdentityConstants.ExternalScheme;
});
authBuilder.AddIdentityCookies();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromDays(14);
    options.SlidingExpiration = true;
});

// ---------- Đăng nhập Google / Facebook ----------
// ClientId/ClientSecret đọc từ appsettings.json / User Secrets (mục "Authentication"). Chỉ bật provider nào
// đã điền đủ Id/Secret để tránh app báo lỗi lúc khởi động khi chưa cấu hình xong OAuth.
var googleClientId = builder.Configuration["Authentication:Google:ClientId"];
var googleClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
var facebookAppId = builder.Configuration["Authentication:Facebook:AppId"];
var facebookAppSecret = builder.Configuration["Authentication:Facebook:AppSecret"];

if (!string.IsNullOrWhiteSpace(googleClientId) && !string.IsNullOrWhiteSpace(googleClientSecret))
{
    authBuilder.AddGoogle(GoogleDefaults.AuthenticationScheme, options =>
    {
        options.ClientId = googleClientId;
        options.ClientSecret = googleClientSecret;
    });
}

if (!string.IsNullOrWhiteSpace(facebookAppId) && !string.IsNullOrWhiteSpace(facebookAppSecret))
{
    authBuilder.AddFacebook(FacebookDefaults.AuthenticationScheme, options =>
    {
        options.AppId = facebookAppId;
        options.AppSecret = facebookAppSecret;
    });
}

// Đăng ký LoanService, CompensationService (AddScoped để khớp lifetime với DbContext,
// tránh lỗi "Cannot consume scoped service from singleton" khi dùng ở Giai đoạn 4-6)
builder.Services.AddScoped<LoanService>();
builder.Services.AddScoped<CompensationService>();
builder.Services.AddScoped<ReaderService>();

// Session lưu "phiếu mượn tạm" (tối đa 3 cuốn) của độc giả trước khi bấm xác nhận mượn.
builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromHours(2);
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});

var app = builder.Build();

// Tạo index (unique BookCode + ControlNumber...) và nạp dữ liệu mẫu 15 cuốn sách kèm ảnh bìa
// nếu collection Books đang trống, để chạy app lên là có sẵn dữ liệu để demo.
// MongoDB không có migration: collection và index được tạo tự động ở lần chạy đầu tiên.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<MongoDbContext>();
    db.EnsureIndexes();
    SeedData.EnsureSeeded(db);

    // Tạo/nâng quyền tài khoản admin theo cấu hình Admin:Email + Admin:Password
    var userManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
    var logger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("AdminSeeder");
    AdminSeeder.EnsureAdminAsync(userManager, builder.Configuration, logger).GetAwaiter().GetResult();

    // Nạp dữ liệu DEMO (độc giả, thẻ, phiếu mượn, bồi thường, đánh giá sao + bình luận...) để báo cáo cho giáo viên.
    // Chỉ nạp 1 lần; bật/tắt và làm mới bằng mục "Demo" trong appsettings.json (Enabled / Reset).
    var demoLogger = scope.ServiceProvider.GetRequiredService<ILoggerFactory>().CreateLogger("DemoData");
    DemoData.EnsureDemoDataAsync(db, userManager, builder.Configuration, demoLogger).GetAwaiter().GetResult();
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
// MapStaticAssets chỉ biết các file có sẵn lúc build; cần UseStaticFiles để phục vụ ảnh đại diện người dùng tải lên khi chương trình đang chạy
app.UseStaticFiles();
app.UseRouting();

app.UseSession();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

// Khu vực quản trị: truy cập qua /admin (đăng nhập riêng tại /admin/login), tách hẳn khỏi trang độc giả "/"
app.MapAreaControllerRoute(
    name: "admin",
    areaName: "Admin",
    pattern: "admin/{controller=Dashboard}/{action=Index}/{id?}")
    .WithStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
