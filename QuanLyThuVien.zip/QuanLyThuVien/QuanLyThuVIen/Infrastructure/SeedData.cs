using MongoDB.Driver;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Infrastructure
{
    // Dữ liệu mẫu 15 mã sách kèm ảnh bìa (ImageUrl lấy từ Open Library Covers API - dịch vụ
    // ảnh bìa sách công khai, miễn phí, dùng ISBN để tra cứu: https://covers.openlibrary.org).
    // Sách chỉ được chèn khi collection Books đang trống, để không tạo trùng mỗi lần khởi động app
    // và không ghi đè dữ liệu người dùng đã tự nhập.
    // Đầu sách (BookCopy) được bổ sung riêng cho những mã sách CHƯA có đầu sách nào: nhờ vậy
    // CSDL cũ (đã seed sách nhưng chưa có đầu sách) cũng được tự sửa, mà không đụng tới
    // những mã sách người dùng đã tự thêm đầu sách.
    public static class SeedData
    {
        public static void EnsureSeeded(MongoDbContext context)
        {
            if (context.Books.CountDocuments(FilterDefinition<Book>.Empty) == 0)
            {
                SeedBooks(context);
            }

            // 30 cuốn bổ sung VH016-VH045: chèn những mã còn thiếu (chạy được cả trên CSDL cũ đã có 15 cuốn đầu)
            SeedMoreBooks.Ensure(context);

            SeedBookCopies(context);
            SeedSampleBorrowCounts(context);
            SeedSampleSummaries(context);
        }

        // Lượt mượn MẪU cho 15 cuốn sách demo (để bảng xếp hạng / sách hot có số liệu ngay khi chưa ai mượn).
        // Chỉ gán cho sách chưa có số mẫu (=0 hoặc chưa có trường) và chỉ cho đúng 15 mã sách mẫu, nên
        // sách do thủ thư tự thêm không bị gán số ảo. Muốn bỏ dữ liệu mẫu: xóa bảng này và đặt SampleBorrowCount về 0.
        private static readonly Dictionary<string, int> SampleBorrowCounts = new()
        {
            ["VH001"] = 46, ["VH002"] = 38, ["VH003"] = 49, ["VH004"] = 27, ["VH005"] = 24,
            ["VH006"] = 41, ["VH007"] = 44, ["VH008"] = 36, ["VH009"] = 33, ["VH010"] = 40,
            ["VH011"] = 19, ["VH012"] = 31, ["VH013"] = 22, ["VH014"] = 29, ["VH015"] = 26
        };

        private static void SeedSampleBorrowCounts(MongoDbContext context)
        {
            var f = Builders<Book>.Filter;
            foreach (var (code, count) in SampleBorrowCounts)
            {
                context.Books.UpdateOne(
                    f.Eq(b => b.BookCode, code) & (f.Eq(b => b.SampleBorrowCount, 0) | f.Exists(b => b.SampleBorrowCount, false)),
                    Builders<Book>.Update.Set(b => b.SampleBorrowCount, count));
            }
        }


        // Tóm tắt nội dung cho 15 sách mẫu. Chỉ gán cho sách CHƯA có tóm tắt, nên không ghi đè
        // phần tóm tắt admin đã nhập và không đụng tới sách do thủ thư tự thêm.
        private static readonly Dictionary<string, string> SampleSummaries = new()
        {
            ["VH001"] = "Trong một thế giới toàn trị do Đảng và nhân vật \"Big Brother\" cai trị, mọi suy nghĩ và hành động của người dân đều bị giám sát. Winston Smith, nhân viên chuyên sửa lại lịch sử, bí mật nảy sinh nghi ngờ và khao khát tự do. Tác phẩm là lời cảnh báo kinh điển về giám sát, tuyên truyền và sự thao túng sự thật.",
            ["VH002"] = "Câu chuyện được kể qua đôi mắt cô bé Scout Finch ở một thị trấn miền Nam nước Mỹ những năm 1930. Cha cô, luật sư Atticus Finch, nhận bào chữa cho một người da đen bị buộc tội oan. Cuốn sách nói về công lý, lòng trắc ẩn và việc đứng lên chống lại định kiến.",
            ["VH003"] = "Cậu bé mồ côi Harry Potter phát hiện mình là phù thủy và được nhận vào trường Hogwarts. Tại đây cậu có những người bạn đầu tiên, học phép thuật và dần khám phá bí mật về cái chết của cha mẹ mình. Đây là phần mở đầu của loạt truyện giả tưởng nổi tiếng toàn cầu.",
            ["VH004"] = "Mùa hè năm 1922 ở New York, Nick Carraway làm hàng xóm của triệu phú bí ẩn Jay Gatsby, người tổ chức những bữa tiệc xa hoa để tìm lại mối tình xưa. Phía sau vẻ hào nhoáng là bức tranh về giấc mơ Mỹ, sự giàu sang và nỗi cô đơn.",
            ["VH005"] = "Gia đình Bennet có năm cô con gái chưa chồng. Elizabeth thông minh, thẳng thắn và anh chàng Darcy kiêu hãnh ban đầu đầy thành kiến với nhau. Qua những hiểu lầm và chuyển biến, tác phẩm phê phán định kiến giai cấp và bàn về hôn nhân trong xã hội Anh đầu thế kỷ 19.",
            ["VH006"] = "Bilbo Baggins, một người Hobbit yêu sự yên ổn, bị cuốn vào chuyến phiêu lưu cùng pháp sư Gandalf và nhóm người lùn để giành lại kho báu bị con rồng Smaug chiếm giữ. Trên đường đi, ông tìm thấy lòng dũng cảm và một chiếc nhẫn kỳ lạ.",
            ["VH007"] = "Yuval Noah Harari kể lại lịch sử loài người từ thời săn bắt hái lượm đến kỷ nguyên công nghệ. Sách xoay quanh các cuộc cách mạng nhận thức, nông nghiệp và khoa học, đồng thời đặt câu hỏi về tôn giáo, tiền tệ, đế chế và hạnh phúc của con người.",
            ["VH008"] = "Santiago, cậu chăn cừu người Tây Ban Nha, mơ thấy kho báu ở Kim tự tháp Ai Cập và lên đường tìm kiếm. Hành trình băng qua sa mạc dạy cậu lắng nghe trái tim, nhận ra những dấu hiệu và theo đuổi \"Huyền thoại cá nhân\" của chính mình.",
            ["VH009"] = "Dale Carnegie giới thiệu những nguyên tắc ứng xử đơn giản mà hiệu quả: quan tâm chân thành đến người khác, biết lắng nghe, tránh chỉ trích và tạo thiện cảm. Cuốn sách là cẩm nang giao tiếp kinh điển cho công việc lẫn cuộc sống hằng ngày.",
            ["VH010"] = "Giáo sư biểu tượng học Robert Langdon bị cuốn vào vụ án mạng ở bảo tàng Louvre cùng nhà mật mã Sophie Neveu. Họ lần theo chuỗi mật mã, tác phẩm nghệ thuật và những bí mật lịch sử liên quan đến một hội kín cổ xưa trong một cuộc rượt đuổi nghẹt thở.",
            ["VH011"] = "Holden Caulfield, cậu thiếu niên 16 tuổi bị đuổi khỏi trường, lang thang ở New York vài ngày. Qua giọng kể thẳng thắn và hoài nghi, cuốn tiểu thuyết khắc họa sự lạc lõng, nỗi cô đơn và khát vọng giữ lại sự trong sáng của tuổi trẻ.",
            ["VH012"] = "Các con vật trong một trang trại nổi dậy đuổi ông chủ để xây dựng xã hội bình đẳng. Dần dần bầy lợn nắm quyền và biến lý tưởng ban đầu thành chế độ độc tài. Đây là truyện ngụ ngôn sắc sảo về quyền lực và sự phản bội cách mạng.",
            ["VH013"] = "Trong thế giới tương lai, con người được tạo ra theo công thức, được điều khiển bằng khoái cảm và thuốc an thần để luôn \"hạnh phúc\". Khi một người ngoại lai xuất hiện, cái giá của sự ổn định đó bị phơi bày: mất tự do, tình cảm và cá tính.",
            ["VH014"] = "Một phi công rơi máy bay giữa sa mạc Sahara gặp cậu hoàng tử bé đến từ tiểu hành tinh xa xôi. Qua những cuộc trò chuyện về bông hồng, con cáo và các hành tinh, cuốn sách nhắc người lớn về tình bạn, tình yêu và những điều quan trọng nhất vốn chỉ thấy bằng trái tim.",
            ["VH015"] = "Dựa trên nghiên cứu về nhiều người thành đạt, Napoleon Hill trình bày các nguyên tắc để đạt được thịnh vượng, như khát vọng rõ ràng, niềm tin, kiên trì và sức mạnh của nhóm cộng sự. Sách thiên về tư duy và động lực cá nhân.",
        };

        private static void SeedSampleSummaries(MongoDbContext context)
        {
            var f = Builders<Book>.Filter;
            foreach (var (code, summary) in SampleSummaries)
            {
                context.Books.UpdateOne(
                    f.Eq(b => b.BookCode, code) & (f.Eq(b => b.Summary, null) | f.Eq(b => b.Summary, "")),
                    Builders<Book>.Update.Set(b => b.Summary, summary));
            }
        }

        // Số đầu sách mẫu tạo cho mỗi mã sách chưa có đầu sách nào
        private const int SampleCopiesPerBook = 3;

        // Tạo đầu sách mẫu (001, 002, 003) ở tình trạng Available cho mã sách chưa có đầu sách.
        // Lý do: LoanService chỉ cho mượn khi có BookCopy Available, nếu chỉ seed Book thì
        // mọi mã sách đều bị báo "không còn đầu sách nào trống".
        private static void SeedBookCopies(MongoDbContext context)
        {
            // Lấy 1 lần danh sách mã sách đã có đầu sách (đưa về List trong bộ nhớ để lọc bên dưới)
            var codesWithCopies = context.BookCopies
                .Distinct(c => c.BookCode, FilterDefinition<BookCopy>.Empty)
                .ToList();

            var codesWithoutCopies = context.Books
                .Find(FilterDefinition<Book>.Empty)
                .Project(b => b.BookCode)
                .ToList()
                .Where(code => !codesWithCopies.Contains(code))
                .ToList();

            if (codesWithoutCopies.Count == 0)
            {
                return;
            }

            // Giữ chỗ trước 1 dãy Id cho toàn bộ đầu sách sẽ tạo (1 lần gọi thay vì mỗi cuốn 1 lần)
            int nextId = context.NextId(nameof(BookCopy), codesWithoutCopies.Count * SampleCopiesPerBook);

            var copies = new List<BookCopy>();
            foreach (var bookCode in codesWithoutCopies)
            {
                for (int i = 1; i <= SampleCopiesPerBook; i++)
                {
                    copies.Add(new BookCopy
                    {
                        BookCopyId = nextId++,
                        BookCode = bookCode,
                        ControlNumber = i.ToString("D3"),
                        Status = BookCopyStatus.Available
                    });
                }
            }

            context.BookCopies.InsertMany(copies);
        }

        private static void SeedBooks(MongoDbContext context)
        {
            var books = new List<Book>
            {
                new() {
                    BookCode = "VH001", Title = "1984", Author = "George Orwell",
                    Genre = "Viễn tưởng", PublicationYear = 1949, Publisher = "Secker & Warburg",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg"
                },
                new() {
                    BookCode = "VH002", Title = "To Kill a Mockingbird", Author = "Harper Lee",
                    Genre = "Văn học kinh điển", PublicationYear = 1960, Publisher = "J. B. Lippincott & Co.",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780061120084-L.jpg"
                },
                new() {
                    BookCode = "VH003", Title = "Harry Potter and the Sorcerer's Stone", Author = "J.K. Rowling",
                    Genre = "Thiếu nhi - Giả tưởng", PublicationYear = 1997, Publisher = "Bloomsbury",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780590353427-L.jpg"
                },
                new() {
                    BookCode = "VH004", Title = "The Great Gatsby", Author = "F. Scott Fitzgerald",
                    Genre = "Văn học kinh điển", PublicationYear = 1925, Publisher = "Charles Scribner's Sons",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780743273565-L.jpg"
                },
                new() {
                    BookCode = "VH005", Title = "Pride and Prejudice", Author = "Jane Austen",
                    Genre = "Văn học kinh điển", PublicationYear = 1813, Publisher = "T. Egerton",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780141439518-L.jpg"
                },
                new() {
                    BookCode = "VH006", Title = "The Hobbit", Author = "J.R.R. Tolkien",
                    Genre = "Giả tưởng", PublicationYear = 1937, Publisher = "George Allen & Unwin",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780547928227-L.jpg"
                },
                new() {
                    BookCode = "VH007", Title = "Sapiens: A Brief History of Humankind", Author = "Yuval Noah Harari",
                    Genre = "Khoa học - Lịch sử", PublicationYear = 2011, Publisher = "Harvill Secker",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg"
                },
                new() {
                    BookCode = "VH008", Title = "The Alchemist", Author = "Paulo Coelho",
                    Genre = "Tiểu thuyết", PublicationYear = 1988, Publisher = "HarperTorch",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780061122415-L.jpg"
                },
                new() {
                    BookCode = "VH009", Title = "How to Win Friends and Influence People", Author = "Dale Carnegie",
                    Genre = "Kỹ năng sống", PublicationYear = 1936, Publisher = "Simon & Schuster",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780671027032-L.jpg"
                },
                new() {
                    BookCode = "VH010", Title = "The Da Vinci Code", Author = "Dan Brown",
                    Genre = "Trinh thám", PublicationYear = 2003, Publisher = "Doubleday",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780307474278-L.jpg"
                },
                new() {
                    BookCode = "VH011", Title = "The Catcher in the Rye", Author = "J.D. Salinger",
                    Genre = "Văn học kinh điển", PublicationYear = 1951, Publisher = "Little, Brown and Company",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780316769488-L.jpg"
                },
                new() {
                    BookCode = "VH012", Title = "Animal Farm", Author = "George Orwell",
                    Genre = "Ngụ ngôn - Chính trị", PublicationYear = 1945, Publisher = "Secker & Warburg",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780451526342-L.jpg"
                },
                new() {
                    BookCode = "VH013", Title = "Brave New World", Author = "Aldous Huxley",
                    Genre = "Viễn tưởng", PublicationYear = 1932, Publisher = "Chatto & Windus",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780060850524-L.jpg"
                },
                new() {
                    BookCode = "VH014", Title = "The Little Prince", Author = "Antoine de Saint-Exupéry",
                    Genre = "Thiếu nhi", PublicationYear = 1943, Publisher = "Reynal & Hitchcock",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780156012195-L.jpg"
                },
                new() {
                    BookCode = "VH015", Title = "Think and Grow Rich", Author = "Napoleon Hill",
                    Genre = "Kỹ năng sống", PublicationYear = 1937, Publisher = "The Ralston Society",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9781585424337-L.jpg"
                },
            };

            context.Books.InsertMany(books);
        }
    }
}
