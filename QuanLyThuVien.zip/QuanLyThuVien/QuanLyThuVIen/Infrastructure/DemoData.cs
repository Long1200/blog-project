using System.Globalization;
using System.Text;
using Microsoft.AspNetCore.Identity;
using MongoDB.Driver;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;

namespace QuanLyThuVIen.Infrastructure
{
    // Dữ liệu DEMO đầy đủ cho buổi báo cáo: độc giả, thẻ thư viện, phiếu mượn (đang mượn / sắp đến hạn / quá hạn /
    // đã trả), sách mất - hỏng, bồi thường, thanh toán, đánh giá sao + bình luận, thích / không thích.
    //
    // Cách hoạt động:
    //  - Chạy 1 lần lúc khởi động (Program.cs). Nếu tài khoản docgia01 đã có thì bỏ qua -> không bị nhân đôi.
    //  - Mọi ngày tháng tính theo "hôm nay" lúc nạp dữ liệu, nên phiếu "sắp đến hạn" / "quá hạn" luôn đúng.
    //    Muốn làm mới ngay trước buổi demo: đặt Demo:Reset = true trong appsettings.json rồi chạy lại app.
    //  - Chỉ đụng tới dữ liệu demo (thẻ TVD001-TVD012, 15 tài khoản docgia01-15@thuvien.local và những gì gắn với chúng),
    //    không xóa sách / thẻ / tài khoản do bạn tự nhập.
    //  - Tắt hẳn bằng Demo:Enabled = false.
    public static class DemoData
    {
        public const string DemoPassword = "Demo123";

        private static readonly string[] BookCodes =
            Enumerable.Range(1, 15).Select(i => $"VH{i:000}").ToArray();

        // ----------------------------------------------------------------------------------------------
        // 1) Độc giả (tài khoản). 10 người đầu đã liên kết thẻ TVD001-TVD010; 11-15 chưa liên kết thẻ
        //    (docgia11 dùng để demo chức năng "Liên kết thẻ" với thẻ TVD011 - họ tên: Lý Phương Thảo).
        // ----------------------------------------------------------------------------------------------
        private sealed record Reader(string Email, string Name, DateTime Dob, string Address, string? Card);

        private static DateTime Dob(int y, int m, int d) => DateTime.SpecifyKind(new DateTime(y, m, d), DateTimeKind.Utc);

        private static readonly Reader[] Readers =
        {
            new("docgia01@thuvien.local", "Nguyễn Minh Anh",   Dob(2003, 4, 12),  "12 Nguyễn Huệ, Quận 1, TP.HCM", "TVD001"),
            new("docgia02@thuvien.local", "Trần Quốc Bảo",     Dob(2002, 9, 23),  "45 Lê Lợi, Quận 3, TP.HCM", "TVD002"),
            new("docgia03@thuvien.local", "Lê Thị Cẩm Tú",     Dob(2004, 1, 30),  "78 Cách Mạng Tháng Tám, Quận 10, TP.HCM", "TVD003"),
            new("docgia04@thuvien.local", "Phạm Gia Huy",      Dob(2001, 11, 5),  "9 Võ Văn Ngân, TP. Thủ Đức, TP.HCM", "TVD004"),
            new("docgia05@thuvien.local", "Võ Thanh Hằng",     Dob(2003, 7, 18),  "102 Phan Văn Trị, Quận Gò Vấp, TP.HCM", "TVD005"),
            new("docgia06@thuvien.local", "Đặng Hoàng Long",   Dob(2002, 3, 9),   "33 Nguyễn Thị Minh Khai, Quận 1, TP.HCM", "TVD006"),
            new("docgia07@thuvien.local", "Bùi Ngọc Mai",      Dob(2000, 12, 25), "5 Hoàng Diệu, Quận 4, TP.HCM", "TVD007"),
            new("docgia08@thuvien.local", "Hoàng Đức Thịnh",   Dob(2003, 6, 14),  "61 Lý Thường Kiệt, Quận 11, TP.HCM", "TVD008"),
            new("docgia09@thuvien.local", "Ngô Khánh Linh",    Dob(2004, 8, 2),   "27 Trường Chinh, Quận Tân Bình, TP.HCM", "TVD009"),
            new("docgia10@thuvien.local", "Đỗ Anh Tuấn",       Dob(2002, 2, 20),  "88 Điện Biên Phủ, Quận Bình Thạnh, TP.HCM", "TVD010"),
            new("docgia11@thuvien.local", "Lý Phương Thảo",    Dob(2003, 10, 11), "14 Huỳnh Tấn Phát, Quận 7, TP.HCM", null),
            new("docgia12@thuvien.local", "Dương Quang Vinh",  Dob(2001, 5, 28),  "3 Nguyễn Văn Linh, Quận 7, TP.HCM", null),
            new("docgia13@thuvien.local", "Mai Thùy Dung",     Dob(2004, 3, 16),  "56 Lạc Long Quân, Quận 11, TP.HCM", null),
            new("docgia14@thuvien.local", "Huỳnh Thanh Phong", Dob(2002, 7, 7),   "21 Tô Hiến Thành, Quận 10, TP.HCM", null),
            new("docgia15@thuvien.local", "Phan Bảo Ngọc",     Dob(2003, 9, 9),   "70 Nguyễn Trãi, Quận 5, TP.HCM", null),
        };

        // ----------------------------------------------------------------------------------------------
        // 2) Thẻ thư viện: đủ các tình trạng để demo (còn hạn, sắp hết hạn, đã hết hạn, bị khóa do bồi thường)
        // ----------------------------------------------------------------------------------------------
        private sealed record CardSpec(string Number, string Name, int ExpiryDays, LibraryCardStatus Status);

        private static readonly CardSpec[] CardSpecs =
        {
            new("TVD001", "Nguyễn Minh Anh",  300, LibraryCardStatus.Active),    // thẻ "sạch", có lịch sử mượn - trả
            new("TVD002", "Trần Quốc Bảo",    200, LibraryCardStatus.Active),    // đang mượn 3 cuốn, còn 10 ngày
            new("TVD003", "Lê Thị Cẩm Tú",     25, LibraryCardStatus.Active),    // đang mượn 2 cuốn, SẮP ĐẾN HẠN; thẻ sắp hết hạn
            new("TVD004", "Phạm Gia Huy",     120, LibraryCardStatus.Active),    // đang mượn 1 cuốn, QUÁ HẠN 6 ngày
            new("TVD005", "Võ Thanh Hằng",    150, LibraryCardStatus.Inactive),  // bị khóa: làm MẤT 1 cuốn, chưa bồi thường
            new("TVD006", "Đặng Hoàng Long",   90, LibraryCardStatus.Inactive),  // bị khóa: 1 cuốn hỏng + 1 cuốn mất, chưa bồi thường
            new("TVD007", "Bùi Ngọc Mai",     -20, LibraryCardStatus.Inactive),  // thẻ ĐÃ HẾT HẠN (demo gia hạn thẻ)
            new("TVD008", "Hoàng Đức Thịnh",  250, LibraryCardStatus.Active),    // từng làm hỏng sách, ĐÃ bồi thường xong
            new("TVD009", "Ngô Khánh Linh",   330, LibraryCardStatus.Active),    // vừa mượn 3 cuốn hôm nay
            new("TVD010", "Đỗ Anh Tuấn",      180, LibraryCardStatus.Active),    // không có phiếu dở -> mượn mới để demo
            new("TVD011", "Lý Phương Thảo",   365, LibraryCardStatus.Active),    // chưa liên kết tài khoản (demo liên kết thẻ)
            new("TVD012", "Trịnh Văn Khoa",    12, LibraryCardStatus.Active),    // chưa có tài khoản, thủ thư lập phiếu mượn giúp
        };

        // ----------------------------------------------------------------------------------------------
        // 3) Phiếu mượn. DaysAgo = mượn cách đây bao nhiêu ngày; hạn trả luôn = ngày mượn + 15 ngày.
        // ----------------------------------------------------------------------------------------------
        private sealed record Item(string Book, LoanDetailStatus Status, int ReturnAfter, int CaseDaysAgo, int? ResolvedDaysAgo, string? Method);
        private sealed record LoanSpec(string Card, int DaysAgo, Item[] Items);

        private static Item Ret(string book, int returnAfterDays) => new(book, LoanDetailStatus.Returned, returnAfterDays, 0, null, null);
        private static Item Out(string book) => new(book, LoanDetailStatus.Borrowed, 0, 0, null, null);
        private static Item Lost(string book, int caseDaysAgo, int? resolvedDaysAgo = null, string? method = null) =>
            new(book, LoanDetailStatus.Lost, 0, caseDaysAgo, resolvedDaysAgo, method);
        private static Item Dmg(string book, int caseDaysAgo, int? resolvedDaysAgo = null, string? method = null) =>
            new(book, LoanDetailStatus.Damaged, 0, caseDaysAgo, resolvedDaysAgo, method);
        private static LoanSpec Mk(string card, int daysAgo, params Item[] items) => new(card, daysAgo, items);

        private static readonly LoanSpec[] LoanSpecs =
        {
            // TVD001 - lịch sử đầy đủ, hiện không mượn gì
            Mk("TVD001", 58, Ret("VH001", 12), Ret("VH012", 12)),
            Mk("TVD001", 40, Ret("VH007", 14), Ret("VH009", 14), Ret("VH015", 14)),
            Mk("TVD001", 22, Ret("VH014", 10), Ret("VH006", 10)),
            Mk("TVD001", 8,  Ret("VH010", 5)),

            // TVD002 - đang mượn 3 cuốn (còn 10 ngày)
            Mk("TVD002", 50, Ret("VH002", 15), Ret("VH005", 15)),
            Mk("TVD002", 25, Ret("VH008", 9)),
            Mk("TVD002", 5,  Out("VH003"), Out("VH007"), Out("VH010")),

            // TVD003 - đang mượn 2 cuốn, còn 2 ngày là đến hạn (huy hiệu vàng)
            Mk("TVD003", 70, Ret("VH003", 14), Ret("VH006", 14), Ret("VH008", 14)),
            Mk("TVD003", 45, Ret("VH011", 7)),
            Mk("TVD003", 30, Ret("VH013", 13), Ret("VH001", 13)),
            Mk("TVD003", 13, Out("VH003"), Out("VH006")),

            // TVD004 - đang mượn 1 cuốn, quá hạn 6 ngày (huy hiệu đỏ); lần trước cũng trả trễ
            Mk("TVD004", 60, Ret("VH010", 20), Ret("VH009", 20)),
            Mk("TVD004", 38, Ret("VH004", 11)),
            Mk("TVD004", 21, Out("VH001")),

            // TVD005 - làm MẤT 1 cuốn (chưa bồi thường 150.000 ₫) -> thẻ bị khóa
            Mk("TVD005", 80, Ret("VH014", 11), Ret("VH001", 11)),
            Mk("TVD005", 40, Ret("VH012", 12), Lost("VH013", 22), Ret("VH015", 12)),

            // TVD006 - 1 cuốn hỏng + 1 cuốn mất (chưa bồi thường 50.000 + 150.000 ₫) -> thẻ bị khóa
            Mk("TVD006", 65, Ret("VH006", 9)),
            Mk("TVD006", 30, Dmg("VH002", 12), Lost("VH004", 12), Ret("VH005", 16)),

            // TVD007 - thẻ đã hết hạn; có 1 case mất sách từ NĂM TRƯỚC đã bồi thường (để báo cáo theo năm có >1 năm)
            Mk("TVD007", 400, Lost("VH005", 390, 380, "Chuyển khoản ngân hàng"), Ret("VH002", 10)),
            Mk("TVD007", 120, Ret("VH014", 13), Ret("VH008", 13)),

            // TVD008 - từng làm hỏng sách, đã bồi thường xong, thẻ đã mở lại
            Mk("TVD008", 75, Dmg("VH009", 60, 55, "Ví MoMo"), Ret("VH011", 13)),
            Mk("TVD008", 33, Ret("VH007", 10), Ret("VH003", 10)),
            Mk("TVD008", 12, Ret("VH012", 6), Ret("VH006", 6), Ret("VH010", 6)),

            // TVD009 - vừa mượn 3 cuốn hôm nay (Harry Potter được mượn hết bản -> "hết sách" ở trang chi tiết)
            Mk("TVD009", 55, Ret("VH001", 14)),
            Mk("TVD009", 28, Ret("VH015", 12), Ret("VH004", 12)),
            Mk("TVD009", 0,  Out("VH003"), Out("VH008"), Out("VH014")),

            // TVD010 - không có phiếu dở dang: dùng để demo mượn sách mới
            Mk("TVD010", 20, Ret("VH008", 9), Ret("VH014", 9), Ret("VH007", 9)),
            Mk("TVD010", 6,  Ret("VH003", 3)),
        };

        // Thanh toán gia hạn thẻ (khoản bồi thường được tạo tự động từ các case đã xử lý ở trên)
        private sealed record RenewalSpec(string Card, string Method, int DaysAgo);

        private static readonly RenewalSpec[] Renewals =
        {
            new("TVD001", "ZaloPay", 120),
            new("TVD003", "Ví MoMo", 200),
            new("TVD009", "Thẻ ATM / Visa", 20),
            new("TVD010", "Chuyển khoản ngân hàng", 45),
        };

        // ----------------------------------------------------------------------------------------------
        // 4) Đánh giá sao + bình luận: Rv(số thứ tự độc giả 1-15, số sao, cách đây bao nhiêu ngày, bình luận, [sửa cách đây])
        //    Mỗi độc giả chỉ đánh giá 1 lần cho mỗi sách (khớp unique index). Comment = null -> chỉ chấm sao.
        // ----------------------------------------------------------------------------------------------
        private sealed record Rv(int User, int Rating, int DaysAgo, string? Comment, int? EditedDaysAgo);

        private static Rv V(int user, int rating, int daysAgo, string? comment = null, int? editedDaysAgo = null) =>
            new(user, rating, daysAgo, comment, editedDaysAgo);

        private static readonly Dictionary<string, Rv[]> Reviews = new()
        {
            ["VH001"] = new[]
            {
                V(1, 5, 50, "Đọc xong mà rùng mình, nhiều chi tiết về giám sát và tuyên truyền giống đời thực đến lạ. Rất đáng đọc."),
                V(3, 5, 41, "Bản dịch mượt, càng đọc càng cuốn. Cái kết khiến mình ngồi thừ ra một lúc lâu."),
                V(4, 4, 33, "Nội dung nặng và hơi u ám nhưng rất sâu sắc. Phù hợp để đọc chậm và suy ngẫm."),
                V(7, 5, 27, "Sách kinh điển của thể loại phản địa đàng. Thư viện nên nhập thêm bản để mọi người đỡ phải chờ."),
                V(9, 4, 15, "Đoạn đầu hơi chậm nhưng từ giữa sách trở đi thì không rời tay được."),
                V(12, 5, 6),
            },
            ["VH002"] = new[]
            {
                V(2, 5, 48, "Atticus là hình mẫu người cha và người luật sư mà ai cũng ngưỡng mộ. Câu chuyện nhẹ nhàng nhưng rất thấm."),
                V(5, 4, 36, "Góc nhìn của cô bé Scout làm câu chuyện vừa ngây thơ vừa đau lòng. Mình đọc một mạch hết sách."),
                V(6, 5, 29, "Bài học về công bằng và sự thấu cảm. Sách nên đọc ít nhất một lần."),
                V(10, 4, 18, "Phần đầu hơi dài dòng, nhưng phiên tòa ở cuối thì xuất sắc."),
                V(13, 4, 9),
                V(14, 3, 4, "Hay nhưng nhịp truyện khá chậm so với kỳ vọng của mình."),
            },
            ["VH003"] = new[]
            {
                V(1, 5, 55, "Tuổi thơ quay trở lại! Đọc lại lần thứ ba vẫn thấy háo hức khi bước vào Hogwarts."),
                V(2, 5, 44, "Thế giới phép thuật được xây dựng cực kỳ cuốn hút. Phù hợp cho cả người lớn lẫn trẻ em."),
                V(3, 5, 32, "Sách hay nhưng hay bị hết, mong thư viện nhập thêm nhiều bản hơn.", 20),
                V(8, 4, 21, "Mở đầu của một series tuyệt vời, nhịp truyện nhanh và dễ đọc."),
                V(9, 5, 10, "Mượn về đọc cùng em gái, hai chị em đều mê."),
                V(10, 5, 5),
                V(15, 4, 2, "Chỉ tiếc là bìa sách hơi cũ, nội dung thì không có gì để chê."),
            },
            ["VH004"] = new[]
            {
                V(6, 4, 52, "Văn phong đẹp, đặc biệt là những đoạn miêu tả các bữa tiệc xa hoa. Cái kết buồn nhưng đáng nhớ."),
                V(9, 3, 40, "Mình thấy hơi khó vào lúc đầu, phải đọc lại vài chương mới hiểu hết ý tác giả."),
                V(4, 4, 31, "Bức tranh giấc mơ Mỹ được khắc họa rất tinh tế qua nhân vật Gatsby."),
                V(11, 5, 19, "Quyển sách ngắn nhưng nhiều tầng ý nghĩa. Rất đáng đọc."),
                V(13, 3, 8),
                V(15, 4, 3, "Đọc xong muốn xem lại bản phim luôn."),
            },
            ["VH005"] = new[]
            {
                V(3, 5, 49, "Elizabeth và Darcy là cặp đôi kinh điển. Đối thoại dí dỏm, đọc rất vui."),
                V(7, 4, 38, "Đôi chỗ lời văn cổ điển hơi khó đọc nhưng nội dung rất duyên dáng."),
                V(11, 5, 26, "Câu chuyện tình yêu và định kiến xã hội được kể thật tinh tế."),
                V(13, 5, 14, "Yêu quá đi! Đọc xong là muốn đọc luôn các tác phẩm khác của Jane Austen."),
                V(2, 4, 7),
            },
            ["VH006"] = new[]
            {
                V(1, 5, 47, "Chuyến phiêu lưu của Bilbo đáng yêu và đầy bất ngờ. Đọc xong muốn đọc tiếp Chúa tể những chiếc nhẫn."),
                V(3, 5, 35, "Văn phong kể chuyện như người kể cho trẻ nhỏ nghe, rất dễ chịu."),
                V(8, 4, 23, "Cuộc đối đầu với rồng Smaug là đoạn mình thích nhất."),
                V(12, 5, 12, "Sách giả tưởng hay nhất mình từng đọc, bản sao còn mới và sạch."),
                V(14, 4, 5),
            },
            ["VH007"] = new[]
            {
                V(1, 5, 53, "Mở mang đầu óc, cách tác giả nhìn lịch sử loài người rất mới mẻ và dễ hiểu."),
                V(2, 5, 42, "Đọc xong nhìn tiền, tôn giáo và quốc gia theo cách hoàn toàn khác. Rất đáng mượn."),
                V(8, 5, 30, "Dày nhưng không hề khô khan. Mình mượn hết 15 ngày vẫn chưa muốn trả."),
                V(10, 4, 17, "Một số nhận định gây tranh cãi nhưng đọc rất cuốn."),
                V(12, 5, 9, "Kiến thức tổng hợp rất tốt cho sinh viên mọi ngành."),
                V(14, 4, 3),
            },
            ["VH008"] = new[]
            {
                V(2, 4, 51, "Câu chuyện nhẹ nhàng, nhiều câu nói đáng suy ngẫm về việc theo đuổi ước mơ."),
                V(3, 4, 39, "Ngắn gọn, dễ đọc, phù hợp đọc trong một buổi chiều."),
                V(9, 3, 24, "Ý nghĩa tốt nhưng mình thấy hơi sáo và dễ đoán.", 10),
                V(10, 5, 13, "Sách truyền cảm hứng, đọc đúng lúc mình đang phân vân về hướng đi của bản thân."),
                V(15, 4, 4),
            },
            ["VH009"] = new[]
            {
                V(4, 4, 46, "Những nguyên tắc rất thực tế, áp dụng được ngay vào việc làm việc nhóm ở trường."),
                V(8, 5, 37, "Sách giao tiếp kinh điển, mỗi chương đều có ví dụ dễ nhớ."),
                V(1, 4, 28, "Hơi nhiều ví dụ cũ nhưng bài học vẫn còn nguyên giá trị."),
                V(11, 5, 16, "Nên đọc trước khi đi phỏng vấn xin việc."),
                V(14, 4, 6),
            },
            ["VH010"] = new[]
            {
                V(1, 5, 45, "Cuốn hút từ trang đầu đến trang cuối, đọc một mạch không dừng được."),
                V(2, 4, 34, "Cốt truyện kịch tính, nhiều chi tiết nghệ thuật và lịch sử thú vị."),
                V(5, 4, 25, "Một số tình tiết hơi quá khoa trương nhưng vẫn rất giải trí."),
                V(8, 5, 11, "Mượn cuối tuần là xong, nhịp truyện nhanh."),
                V(12, 3, 5, "Hay, nhưng đã xem phim trước nên bớt bất ngờ."),
                V(13, 4, 2),
            },
            ["VH011"] = new[]
            {
                V(4, 3, 43, "Giọng văn của Holden khá khó chịu nhưng chính vì vậy mà chân thật."),
                V(6, 4, 32, "Hợp với tâm trạng lạc lõng của tuổi trẻ, đọc thấy đồng cảm."),
                V(9, 3, 20, "Không có cốt truyện rõ ràng nên mình đọc hơi mệt."),
                V(13, 4, 10, "Càng đọc càng hiểu nhân vật hơn. Một cuốn sách lạ nhưng đáng nhớ."),
                V(15, 3, 3),
            },
            ["VH012"] = new[]
            {
                V(1, 5, 44, "Ngắn gọn mà sâu cay, ẩn dụ về quyền lực rất sắc sảo."),
                V(5, 4, 31, "Đọc trong một buổi tối nhưng nghĩ ngợi cả tuần."),
                V(8, 5, 22, "Cuốn nên có trong danh sách đọc của mọi sinh viên."),
                V(12, 5, 8, "Kết thúc thật sự ám ảnh."),
                V(14, 4, 2),
            },
            ["VH013"] = new[]
            {
                V(3, 4, 40, "Viễn cảnh tương lai rất đáng sợ vì nó nghe quen thuộc. Tác phẩm đi trước thời đại."),
                V(5, 4, 28, "Ý tưởng độc đáo, nhưng một số chương hơi nặng về lý thuyết."),
                V(7, 5, 18, "Hay hơn mình tưởng, nên đọc song song với 1984 để so sánh."),
                V(10, 3, 7, "Đọc bản dịch thấy hơi khó theo dõi ở vài đoạn.", 3),
                V(15, 4, 3),
            },
            ["VH014"] = new[]
            {
                V(1, 5, 56, "Sách nhỏ mà chứa cả một bầu trời ý nghĩa. Đọc ở tuổi nào cũng có cảm nhận khác nhau."),
                V(2, 5, 47, "Câu nói về điều quan trọng chỉ thấy bằng trái tim làm mình xúc động."),
                V(3, 5, 35, "Tranh minh họa đáng yêu, nội dung ấm áp."),
                V(9, 5, 22, "Đọc lại lần nữa vẫn thấy mới, rất hợp để tặng bạn bè."),
                V(10, 5, 12, "Mượn cho em họ đọc, em rất thích."),
                V(11, 4, 5),
                V(14, 5, 2, "Cuốn sách chữa lành tuyệt vời."),
            },
            ["VH015"] = new[]
            {
                V(4, 3, 39, "Nhiều ý tưởng tạo động lực nhưng thiếu tính thực tiễn, một số phần lặp lại."),
                V(6, 4, 30, "Tư duy mục tiêu rõ ràng, đọc thấy có động lực làm việc hơn."),
                V(8, 4, 19, "Phù hợp cho bạn nào mới bắt đầu tìm hiểu về phát triển bản thân."),
                V(11, 3, 9, "Mình thấy hơi cũ so với thời nay."),
                V(13, 4, 4),
            },
        };

        // ==============================================================================================
        // Điểm vào: gọi từ Program.cs sau khi đã seed sách + tạo admin
        // ==============================================================================================
        public static async Task EnsureDemoDataAsync(MongoDbContext db, UserManager<ApplicationUser> userManager,
            IConfiguration config, ILogger logger)
        {
            if (!config.GetValue("Demo:Enabled", true))
            {
                return;
            }

            if (config.GetValue("Demo:Reset", false))
            {
                ResetDemoData(db, logger);
            }

            // Đã nạp rồi thì thôi (không nhân đôi dữ liệu mỗi lần chạy app)
            if (await userManager.FindByEmailAsync(Readers[0].Email) != null)
            {
                return;
            }

            // Dữ liệu demo dựa trên 15 cuốn mẫu VH001-VH015: thiếu cuốn nào thì không nạp để khỏi lỗi tham chiếu
            var existingBooks = db.Books.Find(Builders<Book>.Filter.In(b => b.BookCode, BookCodes))
                .Project(b => new { b.BookCode, b.Title }).ToList();
            if (existingBooks.Count != BookCodes.Length)
            {
                logger.LogWarning("Không nạp dữ liệu demo: thiếu một số mã sách mẫu VH001-VH015 trong collection Books.");
                return;
            }
            var titles = existingBooks.ToDictionary(b => b.BookCode, b => b.Title);

            var today = DateTime.Today;
            EnsureExtraCopies(db);

            // ----- Tài khoản độc giả -----
            var userIds = new string[Readers.Length];
            for (int i = 0; i < Readers.Length; i++)
            {
                var r = Readers[i];
                var user = new ApplicationUser
                {
                    UserName = r.Email,
                    Email = r.Email,
                    EmailConfirmed = true,
                    FullName = r.Name,
                    DateOfBirth = r.Dob,
                    Address = r.Address,
                    AvatarUrl = "https://ui-avatars.com/api/?size=200&background=random&color=fff&name=" + Uri.EscapeDataString(Ascii(r.Name)),
                    LibraryCardNumber = r.Card,
                    CreatedDate = DateTime.UtcNow.AddDays(-(100 - i * 5))
                };
                var created = await userManager.CreateAsync(user, DemoPassword);
                if (!created.Succeeded)
                {
                    logger.LogWarning("Không tạo được tài khoản demo {Email}: {Errors}", r.Email,
                        string.Join("; ", created.Errors.Select(e => e.Description)));
                    return;
                }
                userIds[i] = user.Id;
            }

            // ----- Thẻ thư viện -----
            db.LibraryCards.InsertMany(CardSpecs.Select(c => new LibraryCard
            {
                CardNumber = c.Number,
                StudentName = c.Name,
                ExpiryDate = today.AddDays(c.ExpiryDays),
                Status = c.Status
            }));

            // ----- Phiếu mượn, dòng mượn, đầu sách mất/hỏng, case bồi thường -----
            SeedLoans(db, today, titles, userIds);

            // ----- Đánh giá + bình luận + thích/không thích -----
            SeedFeedback(db, userIds);

            // ----- Thanh toán gia hạn thẻ -----
            SeedRenewalPayments(db, today, userIds);

            logger.LogInformation("Đã nạp dữ liệu demo: {Users} độc giả, {Cards} thẻ, {Loans} phiếu mượn. Mật khẩu chung: {Password}",
                Readers.Length, CardSpecs.Length, LoanSpecs.Length, DemoPassword);
        }

        // ----------------------------------------------------------------------------------------------
        // Mỗi sách mẫu (trừ Harry Potter) có thêm đầu sách 004 để có đủ bản cho cả sách đang mượn lẫn sách mất/hỏng.
        // Harry Potter giữ đúng 3 bản và bị mượn hết -> demo trạng thái "hết sách".
        // ----------------------------------------------------------------------------------------------
        private static void EnsureExtraCopies(MongoDbContext db)
        {
            var have = db.BookCopies.Find(Builders<BookCopy>.Filter.In(c => c.BookCode, BookCodes))
                .Project(c => new { c.BookCode, c.ControlNumber }).ToList()
                .Select(c => c.BookCode + "|" + c.ControlNumber).ToHashSet();

            var toAdd = new List<BookCopy>();
            foreach (var code in BookCodes)
            {
                if (code == "VH003") continue;
                foreach (var no in new[] { "001", "002", "003", "004" })
                {
                    if (!have.Contains(code + "|" + no))
                    {
                        toAdd.Add(new BookCopy { BookCode = code, ControlNumber = no, Status = BookCopyStatus.Available });
                    }
                }
            }

            if (toAdd.Count == 0) return;
            int id = db.NextId(nameof(BookCopy), toAdd.Count);
            foreach (var c in toAdd) c.BookCopyId = id++;
            db.BookCopies.InsertMany(toAdd);
        }

        private static void SeedLoans(MongoDbContext db, DateTime today, Dictionary<string, string> titles, string[] userIds)
        {
            var copiesByBook = db.BookCopies.Find(Builders<BookCopy>.Filter.In(c => c.BookCode, BookCodes)).ToList()
                .GroupBy(c => c.BookCode)
                .ToDictionary(g => g.Key, g => g.OrderBy(c => c.ControlNumber).ToList());

            var cardUser = new Dictionary<string, string>();
            for (int i = 0; i < Readers.Length; i++)
            {
                if (Readers[i].Card != null) cardUser[Readers[i].Card!] = userIds[i];
            }

            int detailTotal = LoanSpecs.Sum(l => l.Items.Length);
            int caseTotal = LoanSpecs.Sum(l => l.Items.Count(x => x.Status == LoanDetailStatus.Lost || x.Status == LoanDetailStatus.Damaged));
            int loanId = db.NextId(nameof(Loan), LoanSpecs.Length);
            int detailId = db.NextId(nameof(LoanDetail), detailTotal);
            int caseId = db.NextId(nameof(CompensationCase), caseTotal);
            int paymentCount = LoanSpecs.Sum(l => l.Items.Count(x => x.Method != null));
            int paymentId = paymentCount > 0 ? db.NextId(nameof(Payment), paymentCount) : 0;

            var loans = new List<Loan>();
            var details = new List<LoanDetail>();
            var cases = new List<CompensationCase>();
            var payments = new List<Payment>();
            var copyStatusUpdates = new List<(int CopyId, BookCopyStatus Status)>();

            var rotate = new Dictionary<string, int>();    // đầu sách dùng cho các lượt mượn ĐÃ TRẢ (xoay vòng)
            var reserved = new Dictionary<string, int>();  // đầu sách đang mượn / mất / hỏng (mỗi cuốn một bản riêng)

            foreach (var spec in LoanSpecs)
            {
                var loanDate = today.AddDays(-spec.DaysAgo);
                var loan = new Loan
                {
                    LoanId = loanId++,
                    CardNumber = spec.Card,
                    LoanDate = loanDate,
                    DueDate = loanDate.AddDays(15)
                };
                loans.Add(loan);

                foreach (var item in spec.Items)
                {
                    var copies = copiesByBook[item.Book];
                    BookCopy copy;
                    if (item.Status == LoanDetailStatus.Returned)
                    {
                        int k = rotate.GetValueOrDefault(item.Book);
                        rotate[item.Book] = k + 1;
                        // Lấy từ bản cuối trở lên: bản đầu (001, 002...) dành cho sách đang mượn / mất / hỏng
                        copy = copies[copies.Count - 1 - (k % copies.Count)];
                    }
                    else
                    {
                        int k = reserved.GetValueOrDefault(item.Book);
                        reserved[item.Book] = k + 1;
                        copy = copies[Math.Min(k, copies.Count - 1)];

                        var copyStatus = item.Status switch
                        {
                            LoanDetailStatus.Lost => BookCopyStatus.Lost,
                            LoanDetailStatus.Damaged => BookCopyStatus.Damaged,
                            _ => BookCopyStatus.Borrowed
                        };
                        copyStatusUpdates.Add((copy.BookCopyId, copyStatus));
                    }

                    var detail = new LoanDetail
                    {
                        LoanDetailId = detailId++,
                        LoanId = loan.LoanId,
                        BookCopyId = copy.BookCopyId,
                        Status = item.Status,
                        ReturnDate = item.Status == LoanDetailStatus.Returned ? loanDate.AddDays(item.ReturnAfter) : null
                    };
                    details.Add(detail);

                    if (item.Status == LoanDetailStatus.Lost || item.Status == LoanDetailStatus.Damaged)
                    {
                        var reason = item.Status == LoanDetailStatus.Lost ? CompensationReason.Lost : CompensationReason.Damaged;
                        cases.Add(new CompensationCase
                        {
                            CompensationCaseId = caseId++,
                            LoanDetailId = detail.LoanDetailId,
                            CardNumber = spec.Card,
                            Reason = reason,
                            CreatedDate = today.AddDays(-item.CaseDaysAgo),
                            IsResolved = item.ResolvedDaysAgo.HasValue,
                            ResolvedDate = item.ResolvedDaysAgo.HasValue ? today.AddDays(-item.ResolvedDaysAgo.Value) : null
                        });

                        // Case đã bồi thường xong thì có kèm 1 dòng lịch sử thanh toán
                        if (item.Method != null && item.ResolvedDaysAgo.HasValue)
                        {
                            payments.Add(new Payment
                            {
                                PaymentId = paymentId++,
                                UserId = cardUser.GetValueOrDefault(spec.Card, string.Empty),
                                CardNumber = spec.Card,
                                Type = PaymentType.Compensation,
                                Amount = LibraryFees.ForReason(reason),
                                Method = item.Method,
                                Description = "Bồi thường: " + titles[item.Book],
                                CreatedAtUtc = DateTime.UtcNow.AddDays(-item.ResolvedDaysAgo.Value)
                            });
                        }
                    }
                }
            }

            db.Loans.InsertMany(loans);
            db.LoanDetails.InsertMany(details);
            if (cases.Count > 0) db.CompensationCases.InsertMany(cases);
            if (payments.Count > 0) db.Payments.InsertMany(payments);

            // Cập nhật tình trạng đầu sách (Borrowed / Lost / Damaged) cho khớp với phiếu mượn
            foreach (var group in copyStatusUpdates.GroupBy(x => x.Status))
            {
                db.BookCopies.UpdateMany(
                    Builders<BookCopy>.Filter.In(c => c.BookCopyId, group.Select(x => x.CopyId)),
                    Builders<BookCopy>.Update.Set(c => c.Status, group.Key));
            }
        }

        private static void SeedFeedback(MongoDbContext db, string[] userIds)
        {
            var rnd = new Random(2026); // cố định hạt giống -> lần nào nạp cũng ra cùng một bộ dữ liệu

            var reviews = new List<BookReview>();
            var reactions = new List<BookReaction>();

            foreach (var (bookCode, list) in Reviews)
            {
                var reviewed = new HashSet<int>();

                foreach (var rv in list)
                {
                    reviewed.Add(rv.User);
                    var created = DateTime.UtcNow.AddDays(-rv.DaysAgo).AddHours(-rnd.Next(0, 12));
                    reviews.Add(new BookReview
                    {
                        BookCode = bookCode,
                        UserId = userIds[rv.User - 1],
                        UserName = Readers[rv.User - 1].Name,
                        Rating = rv.Rating,
                        Comment = rv.Comment,
                        CreatedAt = created,
                        UpdatedAt = rv.EditedDaysAgo.HasValue ? DateTime.UtcNow.AddDays(-rv.EditedDaysAgo.Value) : null
                    });

                    // Người chấm cao thường bấm Thích, người chấm thấp thường bấm Không thích
                    ReactionType? type = null;
                    if (rv.Rating >= 4) { if (rnd.NextDouble() < 0.9) type = ReactionType.Like; }
                    else if (rv.Rating == 3) { if (rnd.NextDouble() < 0.35) type = ReactionType.Dislike; }
                    else type = ReactionType.Dislike;

                    if (type.HasValue)
                    {
                        reactions.Add(new BookReaction
                        {
                            BookCode = bookCode,
                            UserId = userIds[rv.User - 1],
                            Type = type.Value,
                            CreatedAt = created.AddMinutes(rnd.Next(1, 30))
                        });
                    }
                }

                // Một số độc giả khác chỉ bấm Thích / Không thích mà không viết đánh giá
                for (int u = 1; u <= Readers.Length; u++)
                {
                    if (reviewed.Contains(u)) continue;
                    double p = rnd.NextDouble();
                    if (p >= 0.40) continue;
                    reactions.Add(new BookReaction
                    {
                        BookCode = bookCode,
                        UserId = userIds[u - 1],
                        Type = p < 0.36 ? ReactionType.Like : ReactionType.Dislike,
                        CreatedAt = DateTime.UtcNow.AddDays(-rnd.Next(0, 60)).AddHours(-rnd.Next(0, 24))
                    });
                }
            }

            int reviewId = db.NextId(nameof(BookReview), reviews.Count);
            foreach (var r in reviews) r.ReviewId = reviewId++;
            db.BookReviews.InsertMany(reviews);

            int reactionId = db.NextId(nameof(BookReaction), reactions.Count);
            foreach (var r in reactions) r.ReactionId = reactionId++;
            db.BookReactions.InsertMany(reactions);
        }

        private static void SeedRenewalPayments(MongoDbContext db, DateTime today, string[] userIds)
        {
            var cardUser = new Dictionary<string, string>();
            for (int i = 0; i < Readers.Length; i++)
            {
                if (Readers[i].Card != null) cardUser[Readers[i].Card!] = userIds[i];
            }

            int id = db.NextId(nameof(Payment), Renewals.Length);
            var payments = Renewals.Select(r =>
            {
                var expiry = today.AddDays(CardSpecs.First(c => c.Number == r.Card).ExpiryDays);
                return new Payment
                {
                    PaymentId = id++,
                    UserId = cardUser[r.Card],
                    CardNumber = r.Card,
                    Type = PaymentType.CardRenewal,
                    Amount = LibraryFees.RenewCard,
                    Method = r.Method,
                    Description = $"Gia hạn thẻ {r.Card} đến {expiry:dd/MM/yyyy}",
                    CreatedAtUtc = DateTime.UtcNow.AddDays(-r.DaysAgo)
                };
            }).ToList();

            db.Payments.InsertMany(payments);
        }

        // ----------------------------------------------------------------------------------------------
        // Xóa riêng dữ liệu demo để nạp lại từ đầu (chỉ đụng tới thẻ TVD001-012 + 15 tài khoản docgia + dữ liệu gắn với chúng)
        // ----------------------------------------------------------------------------------------------
        private static void ResetDemoData(MongoDbContext db, ILogger logger)
        {
            var cards = CardSpecs.Select(c => c.Number).ToList();
            var emails = Readers.Select(r => r.Email).ToList();

            var userIds = db.Users.Find(Builders<ApplicationUser>.Filter.In(u => u.Email, emails))
                .Project(u => u.Id).ToList();

            var loanIds = db.Loans.Find(Builders<Loan>.Filter.In(l => l.CardNumber, cards))
                .Project(l => l.LoanId).ToList();

            var copyIds = db.LoanDetails.Find(Builders<LoanDetail>.Filter.In(d => d.LoanId, loanIds))
                .Project(d => d.BookCopyId).ToList().Distinct().ToList();

            // Trả các đầu sách từng dính tới phiếu demo về trạng thái Available
            if (copyIds.Count > 0)
            {
                db.BookCopies.UpdateMany(
                    Builders<BookCopy>.Filter.In(c => c.BookCopyId, copyIds),
                    Builders<BookCopy>.Update.Set(c => c.Status, BookCopyStatus.Available));
            }

            db.CompensationCases.DeleteMany(Builders<CompensationCase>.Filter.In(c => c.CardNumber, cards));
            db.Payments.DeleteMany(Builders<Payment>.Filter.In(p => p.CardNumber, cards));
            db.LoanDetails.DeleteMany(Builders<LoanDetail>.Filter.In(d => d.LoanId, loanIds));
            db.Loans.DeleteMany(Builders<Loan>.Filter.In(l => l.LoanId, loanIds));
            db.LibraryCards.DeleteMany(Builders<LibraryCard>.Filter.In(c => c.CardNumber, cards));
            db.BookReviews.DeleteMany(Builders<BookReview>.Filter.In(r => r.UserId, userIds));
            db.BookReactions.DeleteMany(Builders<BookReaction>.Filter.In(r => r.UserId, userIds));
            db.Users.DeleteMany(Builders<ApplicationUser>.Filter.In(u => u.Id, userIds));

            logger.LogInformation("Đã xóa dữ liệu demo cũ để nạp lại.");
        }

        // Bỏ dấu tiếng Việt để làm tham số tên cho ảnh đại diện (ui-avatars chỉ cần chữ cái đầu)
        private static string Ascii(string text)
        {
            var normalized = text.Replace('đ', 'd').Replace('Đ', 'D').Normalize(NormalizationForm.FormD);
            var sb = new StringBuilder();
            foreach (var ch in normalized)
            {
                if (CharUnicodeInfo.GetUnicodeCategory(ch) != UnicodeCategory.NonSpacingMark) sb.Append(ch);
            }
            return sb.ToString().Normalize(NormalizationForm.FormC);
        }
    }
}
