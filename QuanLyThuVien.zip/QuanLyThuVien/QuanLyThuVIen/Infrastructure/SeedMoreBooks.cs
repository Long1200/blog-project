using MongoDB.Driver;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Infrastructure
{
    // Bổ sung 30 mã sách mẫu VH016 - VH045 (ngoài 15 cuốn VH001 - VH015 trong SeedData).
    // Khác với SeedData.SeedBooks (chỉ chạy khi collection Books đang trống), lớp này chạy ở MỖI lần khởi động
    // nhưng chỉ chèn những mã sách CHƯA tồn tại -> CSDL cũ (đã có 15 cuốn) cũng được thêm đủ 30 cuốn mới,
    // chạy lại không bị nhân đôi, và không ghi đè sách/tóm tắt do thủ thư tự nhập.
    // Đầu sách (001, 002, 003) cho các mã mới sẽ được SeedData.SeedBookCopies tự tạo ngay sau đó.
    // Ảnh bìa lấy từ Open Library Covers API theo ISBN; nếu ảnh nào không tải được, View tự hiện icon sách mặc định.
    public static class SeedMoreBooks
    {
        public static void Ensure(MongoDbContext context)
        {
            var codes = Samples.Select(b => b.BookCode).ToList();

            var existing = context.Books
                .Find(Builders<Book>.Filter.In(b => b.BookCode, codes))
                .Project(b => b.BookCode)
                .ToList();

            var missing = Samples.Where(b => !existing.Contains(b.BookCode)).ToList();
            if (missing.Count > 0)
            {
                context.Books.InsertMany(missing);
            }
        }

        private static string Cover(string isbn) => $"https://covers.openlibrary.org/b/isbn/{isbn}-L.jpg";

        private static readonly List<Book> Samples = new()
        {
            new() {
                BookCode = "VH016", Title = "The Fellowship of the Ring", Author = "J.R.R. Tolkien",
                Genre = "Giả tưởng", PublicationYear = 1954, Publisher = "George Allen & Unwin",
                ImageUrl = Cover("9780547928210"), SampleBorrowCount = 42,
                Summary = "Phần đầu của bộ ba Chúa tể những chiếc nhẫn. Frodo Baggins thừa kế chiếc nhẫn quyền năng của chúa tể bóng tối Sauron và cùng một nhóm bạn đồng hành lên đường tiêu hủy nó tại Núi Lửa. Hành trình đầy hiểm nguy thử thách tình bạn, lòng dũng cảm và sức cám dỗ của quyền lực."
            },
            new() {
                BookCode = "VH017", Title = "Dune", Author = "Frank Herbert",
                Genre = "Viễn tưởng", PublicationYear = 1965, Publisher = "Chilton Books",
                ImageUrl = Cover("9780441172719"), SampleBorrowCount = 35,
                Summary = "Trên hành tinh sa mạc Arrakis, nơi duy nhất sản xuất hương liệu quý giá nhất vũ trụ, gia tộc Atreides bị phản bội và sụp đổ. Chàng trai trẻ Paul Atreides cùng người Fremen vùng lên giành lại vận mệnh. Tác phẩm đan xen chính trị, tôn giáo, sinh thái và quyền lực trong một sử thi khoa học viễn tưởng."
            },
            new() {
                BookCode = "VH018", Title = "Fahrenheit 451", Author = "Ray Bradbury",
                Genre = "Viễn tưởng", PublicationYear = 1953, Publisher = "Ballantine Books",
                ImageUrl = Cover("9781451673319"), SampleBorrowCount = 28,
                Summary = "Trong một xã hội tương lai, sách bị cấm và lính cứu hỏa có nhiệm vụ đốt chúng. Guy Montag dần nghi ngờ công việc của mình sau khi gặp cô gái trẻ Clarisse và chứng kiến một người phụ nữ chọn chết cùng những cuốn sách. Đây là lời cảnh báo về sự kiểm duyệt và lối sống chạy theo giải trí hời hợt."
            },
            new() {
                BookCode = "VH019", Title = "Jane Eyre", Author = "Charlotte Brontë",
                Genre = "Văn học kinh điển", PublicationYear = 1847, Publisher = "Smith, Elder & Co.",
                ImageUrl = Cover("9780141441146"), SampleBorrowCount = 25,
                Summary = "Cô gái mồ côi Jane Eyre lớn lên trong nghịch cảnh, rồi nhận việc gia sư tại lâu đài Thornfield và nảy sinh tình cảm với ông chủ Rochester bí ẩn. Với lòng tự trọng và ý chí độc lập, Jane phải lựa chọn giữa tình yêu và phẩm giá của chính mình."
            },
            new() {
                BookCode = "VH020", Title = "Wuthering Heights", Author = "Emily Brontë",
                Genre = "Văn học kinh điển", PublicationYear = 1847, Publisher = "Thomas Cautley Newby",
                ImageUrl = Cover("9780141439556"), SampleBorrowCount = 18,
                Summary = "Trên vùng đồng hoang nước Anh, Heathcliff, cậu bé được nhận nuôi, yêu say đắm Catherine nhưng bị chia cắt bởi địa vị xã hội. Nỗi đau và lòng thù hận ám ảnh hai gia đình qua nhiều thế hệ trong một câu chuyện tình bi kịch dữ dội."
            },
            new() {
                BookCode = "VH021", Title = "Crime and Punishment", Author = "Fyodor Dostoevsky",
                Genre = "Văn học kinh điển", PublicationYear = 1866, Publisher = "The Russian Messenger",
                ImageUrl = Cover("9780143107637"), SampleBorrowCount = 21,
                Summary = "Raskolnikov, sinh viên nghèo ở Saint Petersburg, giết một bà chủ tiệm cầm đồ với niềm tin rằng mình có quyền vượt qua đạo đức thông thường. Sau tội ác, anh bị giày vò bởi mặc cảm tội lỗi và cuộc đấu trí với viên thẩm phán. Tác phẩm là cuộc khám phá sâu sắc về lương tâm và sự chuộc lỗi."
            },
            new() {
                BookCode = "VH022", Title = "The Picture of Dorian Gray", Author = "Oscar Wilde",
                Genre = "Văn học kinh điển", PublicationYear = 1890, Publisher = "Lippincott's Monthly Magazine",
                ImageUrl = Cover("9780141439570"), SampleBorrowCount = 23,
                Summary = "Chàng trai trẻ đẹp Dorian Gray ước rằng bức chân dung của mình sẽ già đi thay cho mình. Điều ước thành hiện thực: anh sống buông thả mà vẻ ngoài vẫn nguyên vẹn, còn bức tranh ngày càng biến dạng theo từng tội lỗi. Cuốn tiểu thuyết bàn về cái đẹp, sự phù phiếm và cái giá của đạo đức."
            },
            new() {
                BookCode = "VH023", Title = "Moby-Dick", Author = "Herman Melville",
                Genre = "Văn học kinh điển", PublicationYear = 1851, Publisher = "Harper & Brothers",
                ImageUrl = Cover("9780142437247"), SampleBorrowCount = 12,
                Summary = "Thuyền trưởng Ahab quyết săn đuổi con cá voi trắng khổng lồ đã cắt mất chân ông, kéo cả thủy thủ đoàn tàu Pequod vào cuộc truy đuổi định mệnh. Người kể chuyện Ishmael dẫn dắt độc giả qua biển cả, ám ảnh, và những suy ngẫm về thiên nhiên và sự điên cuồng của con người."
            },
            new() {
                BookCode = "VH024", Title = "Frankenstein", Author = "Mary Shelley",
                Genre = "Kinh dị", PublicationYear = 1818, Publisher = "Lackington, Hughes, Harding, Mavor & Jones",
                ImageUrl = Cover("9780486282114"), SampleBorrowCount = 26,
                Summary = "Nhà khoa học trẻ Victor Frankenstein tạo ra một sinh vật từ xác chết rồi hoảng sợ bỏ rơi nó. Bị xã hội ruồng bỏ, sinh vật ấy quay lại tìm người tạo ra mình để đòi công bằng. Đây là tác phẩm kinh điển về trách nhiệm của khoa học và nỗi cô đơn."
            },
            new() {
                BookCode = "VH025", Title = "Dracula", Author = "Bram Stoker",
                Genre = "Kinh dị", PublicationYear = 1897, Publisher = "Archibald Constable and Company",
                ImageUrl = Cover("9780141439846"), SampleBorrowCount = 30,
                Summary = "Luật sư Jonathan Harker đến lâu đài của bá tước Dracula ở Transylvania và phát hiện bí mật rợn người của vị chủ nhà. Khi Dracula tìm đến nước Anh, một nhóm người quyết tâm hợp sức ngăn chặn hắn. Tác phẩm được viết dưới dạng nhật ký và thư từ, là nền tảng của văn học ma cà rồng."
            },
            new() {
                BookCode = "VH026", Title = "The Adventures of Sherlock Holmes", Author = "Arthur Conan Doyle",
                Genre = "Trinh thám", PublicationYear = 1892, Publisher = "George Newnes",
                ImageUrl = Cover("9780140439076"), SampleBorrowCount = 39,
                Summary = "Tập gồm mười hai truyện ngắn về thám tử Sherlock Holmes và bác sĩ Watson ở London thời Victoria. Bằng khả năng quan sát và suy luận sắc bén, Holmes giải những vụ án từ hội Tóc Đỏ đến dải băng lốm đốm. Đây là khuôn mẫu của truyện trinh thám hiện đại."
            },
            new() {
                BookCode = "VH027", Title = "And Then There Were None", Author = "Agatha Christie",
                Genre = "Trinh thám", PublicationYear = 1939, Publisher = "Collins Crime Club",
                ImageUrl = Cover("9780062073488"), SampleBorrowCount = 37,
                Summary = "Mười người xa lạ được mời đến một hòn đảo biệt lập, nơi từng người lần lượt bị sát hại theo lời một bài đồng dao. Bị cô lập, ai cũng nghi ngờ nhau và mỗi người đều mang một bí mật tội lỗi. Đây là một trong những tiểu thuyết trinh thám bán chạy nhất mọi thời đại."
            },
            new() {
                BookCode = "VH028", Title = "Murder on the Orient Express", Author = "Agatha Christie",
                Genre = "Trinh thám", PublicationYear = 1934, Publisher = "Collins Crime Club",
                ImageUrl = Cover("9780062693662"), SampleBorrowCount = 34,
                Summary = "Chuyến tàu Orient Express bị kẹt trong tuyết, và một hành khách giàu có bị đâm chết trong khoang riêng. Thám tử Hercule Poirot phải tìm ra hung thủ giữa những người đi cùng toa, ai cũng có lời khai và động cơ riêng. Kết thúc bất ngờ của vụ án là một trong những cái kết nổi tiếng nhất của thể loại."
            },
            new() {
                BookCode = "VH029", Title = "The Hunger Games", Author = "Suzanne Collins",
                Genre = "Viễn tưởng", PublicationYear = 2008, Publisher = "Scholastic Press",
                ImageUrl = Cover("9780439023481"), SampleBorrowCount = 45,
                Summary = "Ở quốc gia Panem, mỗi năm mỗi quận phải gửi hai thiếu niên tham gia một cuộc đấu sinh tử trên truyền hình. Katniss Everdeen xung phong thay em gái và phải chiến đấu để sống sót. Tác phẩm mang đến câu chuyện hồi hộp về sự sinh tồn, hy sinh và sự thao túng của truyền thông."
            },
            new() {
                BookCode = "VH030", Title = "The Giver", Author = "Lois Lowry",
                Genre = "Thiếu nhi - Giả tưởng", PublicationYear = 1993, Publisher = "Houghton Mifflin",
                ImageUrl = Cover("9780544336261"), SampleBorrowCount = 22,
                Summary = "Trong một cộng đồng hoàn hảo, nơi không có đau khổ, không có lựa chọn và mọi thứ đều đồng nhất, cậu bé Jonas được giao nhiệm vụ lưu giữ ký ức của cả xã hội. Khi hiểu ra cái giá của sự yên bình, cậu đối mặt với quyết định thay đổi tất cả."
            },
            new() {
                BookCode = "VH031", Title = "Charlie and the Chocolate Factory", Author = "Roald Dahl",
                Genre = "Thiếu nhi", PublicationYear = 1964, Publisher = "Alfred A. Knopf",
                ImageUrl = Cover("9780142410318"), SampleBorrowCount = 33,
                Summary = "Charlie Bucket, cậu bé nghèo, may mắn tìm được tấm vé vàng vào tham quan nhà máy sô cô la kỳ bí của ông Willy Wonka. Trong chuyến đi, những đứa trẻ hư hỏng lần lượt nhận bài học của mình. Một câu chuyện hài hước và nhân văn về sự tử tế và trí tưởng tượng."
            },
            new() {
                BookCode = "VH032", Title = "Matilda", Author = "Roald Dahl",
                Genre = "Thiếu nhi", PublicationYear = 1988, Publisher = "Jonathan Cape",
                ImageUrl = Cover("9780142410370"), SampleBorrowCount = 29,
                Summary = "Matilda là cô bé thần đồng yêu sách nhưng bị gia đình thờ ơ và bị hiệu trưởng Trunchbull độc ác bắt nạt. Khi phát hiện mình có năng lực đặc biệt, em cùng cô giáo Honey đứng lên chống lại bất công. Cuốn sách tôn vinh sức mạnh của tri thức và lòng dũng cảm."
            },
            new() {
                BookCode = "VH033", Title = "The Lion, the Witch and the Wardrobe", Author = "C.S. Lewis",
                Genre = "Thiếu nhi - Giả tưởng", PublicationYear = 1950, Publisher = "Geoffrey Bles",
                ImageUrl = Cover("9780064471046"), SampleBorrowCount = 31,
                Summary = "Bốn anh chị em nhà Pevensie bước qua tủ quần áo cũ và lạc vào xứ Narnia, nơi mùa đông bất tận do Phù thủy Trắng cai trị. Cùng sư tử Aslan, các em tham gia cuộc chiến giải phóng Narnia. Truyện mở đầu cho bộ Biên niên sử Narnia."
            },
            new() {
                BookCode = "VH034", Title = "Alice's Adventures in Wonderland", Author = "Lewis Carroll",
                Genre = "Thiếu nhi - Giả tưởng", PublicationYear = 1865, Publisher = "Macmillan",
                ImageUrl = Cover("9780141439761"), SampleBorrowCount = 24,
                Summary = "Cô bé Alice đuổi theo một chú thỏ trắng và rơi xuống hang thỏ, bước vào xứ sở kỳ lạ đầy những nhân vật khó tin như Mũ Điên, Nữ hoàng Cơ và mèo Cheshire. Câu chuyện giàu trí tưởng tượng và chơi chữ, đã trở thành kinh điển của văn học thiếu nhi."
            },
            new() {
                BookCode = "VH035", Title = "Atomic Habits", Author = "James Clear",
                Genre = "Kỹ năng sống", PublicationYear = 2018, Publisher = "Avery",
                ImageUrl = Cover("9780735211292"), SampleBorrowCount = 43,
                Summary = "James Clear trình bày cách xây dựng thói quen tốt và loại bỏ thói quen xấu bằng những thay đổi rất nhỏ nhưng đều đặn. Sách giới thiệu bốn quy tắc: làm cho thói quen rõ ràng, hấp dẫn, dễ dàng và thỏa mãn, kèm nhiều ví dụ thực tế dễ áp dụng."
            },
            new() {
                BookCode = "VH036", Title = "Rich Dad Poor Dad", Author = "Robert T. Kiyosaki",
                Genre = "Kinh tế - Tài chính", PublicationYear = 1997, Publisher = "Plata Publishing",
                ImageUrl = Cover("9781612680194"), SampleBorrowCount = 38,
                Summary = "Tác giả kể về hai người cha có hai cách nhìn khác nhau về tiền bạc: cha ruột là người làm công ăn lương, còn cha của người bạn là doanh nhân. Qua đó sách bàn về tài sản và nợ, tư duy tài chính và việc để tiền làm việc cho mình."
            },
            new() {
                BookCode = "VH037", Title = "The 7 Habits of Highly Effective People", Author = "Stephen R. Covey",
                Genre = "Kỹ năng sống", PublicationYear = 1989, Publisher = "Free Press",
                ImageUrl = Cover("9780743269513"), SampleBorrowCount = 32,
                Summary = "Stephen Covey đề xuất bảy thói quen giúp phát triển bản thân và hiệu quả trong công việc, như chủ động, bắt đầu với mục tiêu trong đầu, ưu tiên việc quan trọng và tìm sự cộng hưởng. Cuốn sách đi từ tự chủ cá nhân đến hợp tác với người khác."
            },
            new() {
                BookCode = "VH038", Title = "Thinking, Fast and Slow", Author = "Daniel Kahneman",
                Genre = "Khoa học - Tâm lý", PublicationYear = 2011, Publisher = "Farrar, Straus and Giroux",
                ImageUrl = Cover("9780374533557"), SampleBorrowCount = 20,
                Summary = "Nhà tâm lý học đoạt giải Nobel Daniel Kahneman mô tả hai hệ thống tư duy: nhanh, trực giác và chậm, có suy xét. Sách giải thích vì sao con người mắc những thiên kiến khi đánh giá và ra quyết định, và cách nhận diện chúng."
            },
            new() {
                BookCode = "VH039", Title = "A Brief History of Time", Author = "Stephen Hawking",
                Genre = "Khoa học - Lịch sử", PublicationYear = 1988, Publisher = "Bantam Books",
                ImageUrl = Cover("9780553380163"), SampleBorrowCount = 27,
                Summary = "Stephen Hawking giải thích cho độc giả phổ thông những khái niệm lớn của vật lý vũ trụ: Vụ Nổ Lớn, hố đen, thời gian và nỗ lực thống nhất các lý thuyết vật lý. Sách trình bày với ngôn ngữ dễ hiểu, hạn chế tối đa công thức toán."
            },
            new() {
                BookCode = "VH040", Title = "Cosmos", Author = "Carl Sagan",
                Genre = "Khoa học - Lịch sử", PublicationYear = 1980, Publisher = "Random House",
                ImageUrl = Cover("9780345539434"), SampleBorrowCount = 17,
                Summary = "Carl Sagan dẫn dắt người đọc qua hành trình khám phá vũ trụ, từ nguồn gốc các vì sao, sự sống trên Trái Đất đến vị trí nhỏ bé của loài người giữa thiên hà. Cuốn sách kết hợp khoa học, lịch sử và triết học bằng giọng văn đầy cảm hứng."
            },
            new() {
                BookCode = "VH041", Title = "The Selfish Gene", Author = "Richard Dawkins",
                Genre = "Khoa học", PublicationYear = 1976, Publisher = "Oxford University Press",
                ImageUrl = Cover("9780198788607"), SampleBorrowCount = 14,
                Summary = "Richard Dawkins đưa ra góc nhìn lấy gen làm trung tâm của tiến hóa: cơ thể sống là phương tiện để gen tự nhân bản. Sách giải thích hành vi vị tha, cạnh tranh và hợp tác trong tự nhiên, đồng thời giới thiệu khái niệm \"meme\"."
            },
            new() {
                BookCode = "VH042", Title = "Educated", Author = "Tara Westover",
                Genre = "Tự truyện - Hồi ký", PublicationYear = 2018, Publisher = "Random House",
                ImageUrl = Cover("9780399590504"), SampleBorrowCount = 19,
                Summary = "Tara Westover lớn lên trong một gia đình sống biệt lập ở vùng núi Idaho, không đến trường cho đến năm 17 tuổi. Bằng sự tự học, cô bước vào giảng đường đại học và cuối cùng nhận học vị tiến sĩ. Hồi ký kể về giá trị của giáo dục và cái giá của việc tự định nghĩa bản thân."
            },
            new() {
                BookCode = "VH043", Title = "Man's Search for Meaning", Author = "Viktor E. Frankl",
                Genre = "Tự truyện - Hồi ký", PublicationYear = 1946, Publisher = "Beacon Press",
                ImageUrl = Cover("9780807014295"), SampleBorrowCount = 16,
                Summary = "Bác sĩ tâm thần Viktor Frankl kể lại những năm tháng bị giam trong trại tập trung của Đức Quốc xã và rút ra kết luận rằng con người có thể chịu đựng gần như mọi hoàn cảnh nếu tìm được ý nghĩa. Từ đó ông giới thiệu liệu pháp ý nghĩa (logotherapy)."
            },
            new() {
                BookCode = "VH044", Title = "The Kite Runner", Author = "Khaled Hosseini",
                Genre = "Tiểu thuyết", PublicationYear = 2003, Publisher = "Riverhead Books",
                ImageUrl = Cover("9781594631931"), SampleBorrowCount = 28,
                Summary = "Amir lớn lên ở Kabul cùng người bạn trung thành Hassan. Một biến cố tuổi thơ khiến Amir mang mặc cảm tội lỗi suốt nhiều năm, cho đến khi anh trở về quê hương để chuộc lỗi. Câu chuyện chạm đến tình bạn, sự phản bội và khả năng được tha thứ giữa bối cảnh chiến tranh Afghanistan."
            },
            new() {
                BookCode = "VH045", Title = "Life of Pi", Author = "Yann Martel",
                Genre = "Tiểu thuyết", PublicationYear = 2001, Publisher = "Knopf Canada",
                ImageUrl = Cover("9780156027328"), SampleBorrowCount = 25,
                Summary = "Sau vụ đắm tàu, cậu bé Ấn Độ Pi Patel trôi dạt 227 ngày trên Thái Bình Dương trong chiếc xuồng cứu sinh cùng một con hổ Bengal. Cuộc sinh tồn kỳ lạ này là câu chuyện về đức tin, trí tưởng tượng và sức mạnh của hy vọng."
            },
        };
    }
}
