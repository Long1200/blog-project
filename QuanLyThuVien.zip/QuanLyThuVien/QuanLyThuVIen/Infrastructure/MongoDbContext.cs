using Microsoft.Extensions.Options;
using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Driver;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Infrastructure
{
    // Cấu hình kết nối, đọc từ mục "MongoDb" trong appsettings.json / User Secrets
    public class MongoDbSettings
    {
        public string ConnectionString { get; set; } = string.Empty;
        public string DatabaseName { get; set; } = "QuanLyThuVienDb";
    }

    // Document đếm để sinh Id số nguyên tự tăng (MongoDB không tự sinh int như IDENTITY của SQL Server).
    // _id = tên bộ đếm (ví dụ "Loan"), Seq = giá trị đã cấp gần nhất.
    internal class MongoCounter
    {
        [BsonId]
        public string Id { get; set; } = string.Empty;
        public int Seq { get; set; }
    }

    // Thay thế LibraryDbContext (EF Core). Mỗi "DbSet" cũ tương ứng 1 collection MongoDB.
    // Đăng ký Singleton: MongoClient an toàn đa luồng và được thiết kế để dùng chung cả ứng dụng.
    public class MongoDbContext
    {
        private readonly IMongoCollection<MongoCounter> _counters;

        // Expose Client để Service mở session/transaction (MongoDB chỉ hỗ trợ transaction
        // trên replica set; cluster Atlas mặc định đã là replica set nên dùng được).
        public IMongoClient Client { get; }
        public IMongoDatabase Database { get; }

        public IMongoCollection<Book> Books { get; }
        public IMongoCollection<BookCopy> BookCopies { get; }
        public IMongoCollection<LibraryCard> LibraryCards { get; }
        public IMongoCollection<Loan> Loans { get; }
        public IMongoCollection<LoanDetail> LoanDetails { get; }
        public IMongoCollection<CompensationCase> CompensationCases { get; }

        // Đánh giá sao + bình luận, và thích/không thích của độc giả cho từng cuốn sách
        public IMongoCollection<BookReview> BookReviews { get; }
        public IMongoCollection<BookReaction> BookReactions { get; }

        // Lịch sử thanh toán (gia hạn thẻ, bồi thường sách)
        public IMongoCollection<Payment> Payments { get; }

        // Tài khoản đăng nhập (ASP.NET Core Identity), được MongoUserStore sử dụng
        public IMongoCollection<ApplicationUser> Users { get; }

        public MongoDbContext(IOptions<MongoDbSettings> options)
        {
            var settings = options.Value;

            // Báo lỗi sớm, rõ ràng thay vì để driver ném lỗi khó hiểu khi chưa cấu hình chuỗi kết nối
            if (string.IsNullOrWhiteSpace(settings.ConnectionString))
            {
                throw new InvalidOperationException(
                    "Chưa cấu hình MongoDb:ConnectionString. Hãy đặt bằng User Secrets: " +
                    "dotnet user-secrets set \"MongoDb:ConnectionString\" \"<chuỗi kết nối Atlas>\"");
            }

            Client = new MongoClient(settings.ConnectionString);
            Database = Client.GetDatabase(settings.DatabaseName);

            Books = Database.GetCollection<Book>("Books");
            BookCopies = Database.GetCollection<BookCopy>("BookCopies");
            LibraryCards = Database.GetCollection<LibraryCard>("LibraryCards");
            Loans = Database.GetCollection<Loan>("Loans");
            LoanDetails = Database.GetCollection<LoanDetail>("LoanDetails");
            CompensationCases = Database.GetCollection<CompensationCase>("CompensationCases");
            BookReviews = Database.GetCollection<BookReview>("BookReviews");
            BookReactions = Database.GetCollection<BookReaction>("BookReactions");
            Payments = Database.GetCollection<Payment>("Payments");
            Users = Database.GetCollection<ApplicationUser>("Users");
            _counters = Database.GetCollection<MongoCounter>("Counters");
        }

        // Tạo index cần thiết; gọi 1 lần lúc khởi động. CreateOne với index đã tồn tại là thao tác
        // an toàn (không tạo lại), nên không cần kiểm tra trước.
        public void EnsureIndexes()
        {
            // BookCopy: 1 mã sách không được trùng Số kiểm soát (thay cho HasIndex(...).IsUnique() của EF)
            BookCopies.Indexes.CreateOne(new CreateIndexModel<BookCopy>(
                Builders<BookCopy>.IndexKeys.Ascending(bc => bc.BookCode).Ascending(bc => bc.ControlNumber),
                new CreateIndexOptions { Unique = true, Name = "UX_BookCopies_BookCode_ControlNumber" }));

            // Các index thường để tra cứu theo "khóa ngoại" (không còn JOIN nên truy vấn theo trường này rất nhiều)
            Loans.Indexes.CreateOne(new CreateIndexModel<Loan>(
                Builders<Loan>.IndexKeys.Ascending(l => l.CardNumber),
                new CreateIndexOptions { Name = "IX_Loans_CardNumber" }));

            LoanDetails.Indexes.CreateOne(new CreateIndexModel<LoanDetail>(
                Builders<LoanDetail>.IndexKeys.Ascending(ld => ld.LoanId),
                new CreateIndexOptions { Name = "IX_LoanDetails_LoanId" }));

            CompensationCases.Indexes.CreateOne(new CreateIndexModel<CompensationCase>(
                Builders<CompensationCase>.IndexKeys.Ascending(cc => cc.CardNumber).Ascending(cc => cc.IsResolved),
                new CreateIndexOptions { Name = "IX_CompensationCases_CardNumber_IsResolved" }));

            // Mỗi tài khoản chỉ có 1 đánh giá và 1 phản ứng (thích/không thích) cho mỗi mã sách
            BookReviews.Indexes.CreateOne(new CreateIndexModel<BookReview>(
                Builders<BookReview>.IndexKeys.Ascending(r => r.BookCode).Ascending(r => r.UserId),
                new CreateIndexOptions { Unique = true, Name = "UX_BookReviews_BookCode_UserId" }));

            BookReactions.Indexes.CreateOne(new CreateIndexModel<BookReaction>(
                Builders<BookReaction>.IndexKeys.Ascending(r => r.BookCode).Ascending(r => r.UserId),
                new CreateIndexOptions { Unique = true, Name = "UX_BookReactions_BookCode_UserId" }));

            // Users: UserName luôn bằng Email nên unique NormalizedUserName cũng chặn trùng email,
            // kể cả khi 2 người đăng ký cùng lúc (lớp kiểm tra cuối cùng ở tầng CSDL).
            Users.Indexes.CreateOne(new CreateIndexModel<ApplicationUser>(
                Builders<ApplicationUser>.IndexKeys.Ascending(u => u.NormalizedUserName),
                new CreateIndexOptions { Unique = true, Name = "UX_Users_NormalizedUserName" }));

            Users.Indexes.CreateOne(new CreateIndexModel<ApplicationUser>(
                Builders<ApplicationUser>.IndexKeys.Ascending(u => u.NormalizedEmail),
                new CreateIndexOptions { Name = "IX_Users_NormalizedEmail" }));

            Payments.Indexes.CreateOne(new CreateIndexModel<Payment>(
                Builders<Payment>.IndexKeys.Ascending(p => p.CardNumber),
                new CreateIndexOptions { Name = "IX_Payments_CardNumber" }));

            // Mỗi thẻ chỉ được liên kết với 1 tài khoản (unique, bỏ qua user chưa liên kết thẻ)
            Users.Indexes.CreateOne(new CreateIndexModel<ApplicationUser>(
                Builders<ApplicationUser>.IndexKeys.Ascending(u => u.LibraryCardNumber),
                new CreateIndexOptions<ApplicationUser>
                {
                    Unique = true,
                    Name = "UX_Users_LibraryCardNumber",
                    PartialFilterExpression = Builders<ApplicationUser>.Filter.Type(u => u.LibraryCardNumber, MongoDB.Bson.BsonType.String)
                }));

            // Tra cứu user theo tài khoản Google/Facebook khi đăng nhập ngoài
            Users.Indexes.CreateOne(new CreateIndexModel<ApplicationUser>(
                Builders<ApplicationUser>.IndexKeys.Ascending("Logins.LoginProvider").Ascending("Logins.ProviderKey"),
                new CreateIndexOptions { Name = "IX_Users_Logins" }));
        }

        // Khóa theo tên (ví dụ "Card:TV0001") dùng trong transaction để thay cho Serializable của SQL Server.
        // Snapshot isolation của MongoDB chỉ báo xung đột khi 2 transaction cùng GHI 1 document; còn 2 request
        // cùng kiểm tra "thẻ chưa có phiếu dở" rồi mỗi bên chèn 1 Loan khác nhau thì không đụng nhau.
        // Ghi vào cùng 1 document bộ đếm (nằm TRONG session) ép 2 transaction cùng thẻ phải xếp hàng:
        // bên sau bị báo xung đột tạm thời và driver tự chạy lại callback sau khi bên trước commit.
        public void AcquireLock(IClientSessionHandle session, string lockName)
        {
            _counters.UpdateOne(
                session,
                Builders<MongoCounter>.Filter.Eq(c => c.Id, "Lock:" + lockName),
                Builders<MongoCounter>.Update.Inc(c => c.Seq, 1),
                new UpdateOptions { IsUpsert = true });
        }

        // Cấp Id số nguyên tự tăng cho collection có khóa int (BookCopy, Loan, LoanDetail, CompensationCase).
        // Dùng $inc + upsert trong 1 lệnh nguyên tử nên 2 request đồng thời không bao giờ nhận trùng Id.
        // count > 1: giữ chỗ 1 dãy Id liên tiếp một lần (dùng khi thêm hàng loạt, đỡ gọi nhiều lần);
        // hàm trả về Id ĐẦU TIÊN của dãy, các Id còn lại là start+1, start+2...
        // Lưu ý: Id đã cấp không được hoàn lại khi transaction rollback -> có thể có "lỗ hổng" trong
        // dãy số, điều này chấp nhận được vì Id chỉ cần duy nhất, không cần liên tục.
        public int NextId(string counterName, int count = 1)
        {
            if (count < 1) throw new ArgumentOutOfRangeException(nameof(count));

            var counter = _counters.FindOneAndUpdate(
                Builders<MongoCounter>.Filter.Eq(c => c.Id, counterName),
                Builders<MongoCounter>.Update.Inc(c => c.Seq, count),
                new FindOneAndUpdateOptions<MongoCounter>
                {
                    IsUpsert = true,
                    ReturnDocument = ReturnDocument.After
                });

            // Seq hiện là Id cuối của dãy vừa giữ chỗ -> Id đầu = Seq - count + 1
            return counter.Seq - count + 1;
        }
    }
}
