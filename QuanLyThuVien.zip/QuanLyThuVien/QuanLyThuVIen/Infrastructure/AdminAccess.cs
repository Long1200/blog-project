using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Infrastructure
{
    // Chặn mọi action trong khu vực /admin: chưa đăng nhập hoặc không phải admin thì chuyển về /admin/login.
    // Dùng bộ lọc riêng (thay vì Role của Identity) vì MongoUserStore không có bảng Role.
    public class AdminOnlyAttribute : Attribute, IAsyncAuthorizationFilter
    {
        public async Task OnAuthorizationAsync(AuthorizationFilterContext context)
        {
            var http = context.HttpContext;
            var returnUrl = http.Request.Path + http.Request.QueryString;

            if (http.User.Identity?.IsAuthenticated != true)
            {
                context.Result = new RedirectToActionResult("Login", "Account", new { area = "Admin", returnUrl });
                return;
            }

            var userManager = http.RequestServices.GetRequiredService<UserManager<ApplicationUser>>();
            var user = await userManager.GetUserAsync(http.User);
            if (user == null || !user.IsAdmin)
            {
                context.Result = new RedirectToActionResult("Login", "Account", new { area = "Admin", denied = true });
            }
        }
    }

    // Tạo (hoặc nâng quyền) tài khoản admin khi khởi động, theo cấu hình Admin:Email / Admin:Password.
    public static class AdminSeeder
    {
        public static async Task EnsureAdminAsync(UserManager<ApplicationUser> userManager, IConfiguration config, ILogger logger)
        {
            var email = config["Admin:Email"];
            var password = config["Admin:Password"];
            if (string.IsNullOrWhiteSpace(email)) return;

            var user = await userManager.FindByEmailAsync(email);
            if (user == null)
            {
                if (string.IsNullOrWhiteSpace(password))
                {
                    logger.LogWarning("Chưa có tài khoản admin {Email} và chưa cấu hình Admin:Password nên không tạo được.", email);
                    return;
                }

                user = new ApplicationUser
                {
                    UserName = email,
                    Email = email,
                    EmailConfirmed = true,
                    FullName = "Quản trị viên",
                    IsAdmin = true,
                    CreatedDate = DateTime.UtcNow
                };
                var created = await userManager.CreateAsync(user, password);
                if (!created.Succeeded)
                    logger.LogWarning("Không tạo được admin: {Errors}", string.Join("; ", created.Errors.Select(e => e.Description)));
            }
            else if (!user.IsAdmin)
            {
                user.IsAdmin = true;
                await userManager.UpdateAsync(user);
            }
        }
    }
}
