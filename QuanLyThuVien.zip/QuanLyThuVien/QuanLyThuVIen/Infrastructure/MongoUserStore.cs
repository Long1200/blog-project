using Microsoft.AspNetCore.Identity;
using MongoDB.Driver;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Infrastructure
{
    // Nơi lưu tài khoản của ASP.NET Core Identity trên MongoDB, thay cho AddEntityFrameworkStores.
    // Tự viết (không cài thêm package bên thứ ba) vì quy tắc dự án không cho thêm thư viện ngoài thỏa thuận.
    // Chỉ cài các interface mà luồng hiện tại thực sự dùng: mật khẩu, email, đăng nhập ngoài (Google/Facebook),
    // khóa tài khoản khi nhập sai, và SecurityStamp (để cookie cũ mất hiệu lực sau khi đổi mật khẩu).
    // Không có Role/2FA/Claim vì đồ án chưa dùng.
    public class MongoUserStore :
        IUserStore<ApplicationUser>,
        IUserPasswordStore<ApplicationUser>,
        IUserEmailStore<ApplicationUser>,
        IUserLoginStore<ApplicationUser>,
        IUserLockoutStore<ApplicationUser>,
        IUserSecurityStampStore<ApplicationUser>
    {
        private readonly IMongoCollection<ApplicationUser> _users;

        public MongoUserStore(MongoDbContext db)
        {
            _users = db.Users;
        }

        // ---------- IUserStore ----------
        public Task<string> GetUserIdAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.Id);

        public Task<string?> GetUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.UserName);

        public Task SetUserNameAsync(ApplicationUser user, string? userName, CancellationToken cancellationToken)
        {
            user.UserName = userName;
            return Task.CompletedTask;
        }

        public Task<string?> GetNormalizedUserNameAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.NormalizedUserName);

        public Task SetNormalizedUserNameAsync(ApplicationUser user, string? normalizedName, CancellationToken cancellationToken)
        {
            user.NormalizedUserName = normalizedName;
            return Task.CompletedTask;
        }

        public async Task<IdentityResult> CreateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            try
            {
                await _users.InsertOneAsync(user, cancellationToken: cancellationToken);
                return IdentityResult.Success;
            }
            catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
            {
                // Unique index NormalizedUserName chặn trường hợp 2 người đăng ký cùng email gần như đồng thời
                // (kiểm tra "email đã tồn tại" ở Controller không đủ để loại bỏ race condition này).
                return IdentityResult.Failed(new IdentityError
                {
                    Code = "DuplicateUserName",
                    Description = "Email này đã được đăng ký"
                });
            }
        }

        public async Task<IdentityResult> UpdateAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            // Khóa lạc quan bằng ConcurrencyStamp: chỉ ghi nếu bản trong DB chưa bị ai sửa kể từ lúc nạp,
            // tránh 2 request đồng thời ghi đè dữ liệu của nhau.
            var oldStamp = user.ConcurrencyStamp;
            user.ConcurrencyStamp = Guid.NewGuid().ToString();

            var filter = Builders<ApplicationUser>.Filter.And(
                Builders<ApplicationUser>.Filter.Eq(u => u.Id, user.Id),
                Builders<ApplicationUser>.Filter.Eq(u => u.ConcurrencyStamp, oldStamp));

            try
            {
                var result = await _users.ReplaceOneAsync(filter, user, new ReplaceOptions(), cancellationToken);
                if (result.MatchedCount == 0)
                {
                    user.ConcurrencyStamp = oldStamp;
                    return IdentityResult.Failed(new IdentityError
                    {
                        Code = "ConcurrencyFailure",
                        Description = "Dữ liệu tài khoản vừa bị thay đổi bởi thao tác khác, vui lòng thử lại"
                    });
                }
                return IdentityResult.Success;
            }
            catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
            {
                user.ConcurrencyStamp = oldStamp;
                return IdentityResult.Failed(new IdentityError
                {
                    Code = "DuplicateUserName",
                    Description = "Email này đã được đăng ký"
                });
            }
        }

        public async Task<IdentityResult> DeleteAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            await _users.DeleteOneAsync(Builders<ApplicationUser>.Filter.Eq(u => u.Id, user.Id), cancellationToken);
            return IdentityResult.Success;
        }

        public async Task<ApplicationUser?> FindByIdAsync(string userId, CancellationToken cancellationToken)
        {
            return await _users.Find(Builders<ApplicationUser>.Filter.Eq(u => u.Id, userId))
                .FirstOrDefaultAsync(cancellationToken);
        }

        public async Task<ApplicationUser?> FindByNameAsync(string normalizedUserName, CancellationToken cancellationToken)
        {
            return await _users.Find(Builders<ApplicationUser>.Filter.Eq(u => u.NormalizedUserName, normalizedUserName))
                .FirstOrDefaultAsync(cancellationToken);
        }

        // ---------- IUserPasswordStore ----------
        public Task SetPasswordHashAsync(ApplicationUser user, string? passwordHash, CancellationToken cancellationToken)
        {
            user.PasswordHash = passwordHash;
            return Task.CompletedTask;
        }

        public Task<string?> GetPasswordHashAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.PasswordHash);

        // Tài khoản chỉ đăng nhập Google/Facebook sẽ không có mật khẩu -> trang Profile dựa vào đây để ẩn nút đổi mật khẩu
        public Task<bool> HasPasswordAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(!string.IsNullOrEmpty(user.PasswordHash));

        // ---------- IUserEmailStore ----------
        public Task SetEmailAsync(ApplicationUser user, string? email, CancellationToken cancellationToken)
        {
            user.Email = email;
            return Task.CompletedTask;
        }

        public Task<string?> GetEmailAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.Email);

        public Task<bool> GetEmailConfirmedAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.EmailConfirmed);

        public Task SetEmailConfirmedAsync(ApplicationUser user, bool confirmed, CancellationToken cancellationToken)
        {
            user.EmailConfirmed = confirmed;
            return Task.CompletedTask;
        }

        public async Task<ApplicationUser?> FindByEmailAsync(string normalizedEmail, CancellationToken cancellationToken)
        {
            return await _users.Find(Builders<ApplicationUser>.Filter.Eq(u => u.NormalizedEmail, normalizedEmail))
                .FirstOrDefaultAsync(cancellationToken);
        }

        public Task<string?> GetNormalizedEmailAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.NormalizedEmail);

        public Task SetNormalizedEmailAsync(ApplicationUser user, string? normalizedEmail, CancellationToken cancellationToken)
        {
            user.NormalizedEmail = normalizedEmail;
            return Task.CompletedTask;
        }

        // ---------- IUserLoginStore (Google / Facebook) ----------
        // Danh sách liên kết nằm trong chính document user (user.Logins) nên Add/Remove chỉ sửa trong bộ nhớ;
        // UserManager sẽ tự gọi UpdateAsync ngay sau đó để ghi xuống MongoDB (giống cách store EF hoạt động).
        public Task AddLoginAsync(ApplicationUser user, UserLoginInfo login, CancellationToken cancellationToken)
        {
            user.Logins.Add(new ApplicationUserLogin
            {
                LoginProvider = login.LoginProvider,
                ProviderKey = login.ProviderKey,
                ProviderDisplayName = login.ProviderDisplayName
            });
            return Task.CompletedTask;
        }

        public Task RemoveLoginAsync(ApplicationUser user, string loginProvider, string providerKey, CancellationToken cancellationToken)
        {
            user.Logins.RemoveAll(l => l.LoginProvider == loginProvider && l.ProviderKey == providerKey);
            return Task.CompletedTask;
        }

        public Task<IList<UserLoginInfo>> GetLoginsAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            IList<UserLoginInfo> logins = user.Logins
                .Select(l => new UserLoginInfo(l.LoginProvider, l.ProviderKey, l.ProviderDisplayName))
                .ToList();
            return Task.FromResult(logins);
        }

        public async Task<ApplicationUser?> FindByLoginAsync(string loginProvider, string providerKey, CancellationToken cancellationToken)
        {
            var filter = Builders<ApplicationUser>.Filter.ElemMatch(
                u => u.Logins,
                l => l.LoginProvider == loginProvider && l.ProviderKey == providerKey);

            return await _users.Find(filter).FirstOrDefaultAsync(cancellationToken);
        }

        // ---------- IUserLockoutStore ----------
        // Các hàm Set/Increment/Reset chỉ sửa đối tượng trong bộ nhớ; UserManager gọi UpdateAsync sau đó để lưu.
        public Task<DateTimeOffset?> GetLockoutEndDateAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.LockoutEnd);

        public Task SetLockoutEndDateAsync(ApplicationUser user, DateTimeOffset? lockoutEnd, CancellationToken cancellationToken)
        {
            user.LockoutEnd = lockoutEnd;
            return Task.CompletedTask;
        }

        public Task<int> IncrementAccessFailedCountAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            user.AccessFailedCount++;
            return Task.FromResult(user.AccessFailedCount);
        }

        public Task ResetAccessFailedCountAsync(ApplicationUser user, CancellationToken cancellationToken)
        {
            user.AccessFailedCount = 0;
            return Task.CompletedTask;
        }

        public Task<int> GetAccessFailedCountAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.AccessFailedCount);

        public Task<bool> GetLockoutEnabledAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.LockoutEnabled);

        public Task SetLockoutEnabledAsync(ApplicationUser user, bool enabled, CancellationToken cancellationToken)
        {
            user.LockoutEnabled = enabled;
            return Task.CompletedTask;
        }

        // ---------- IUserSecurityStampStore ----------
        public Task SetSecurityStampAsync(ApplicationUser user, string stamp, CancellationToken cancellationToken)
        {
            user.SecurityStamp = stamp;
            return Task.CompletedTask;
        }

        public Task<string?> GetSecurityStampAsync(ApplicationUser user, CancellationToken cancellationToken)
            => Task.FromResult(user.SecurityStamp);

        public void Dispose()
        {
            // Không giữ tài nguyên riêng: MongoClient do MongoDbContext (Singleton) quản lý
        }
    }
}
