using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;

namespace QuanLyThuVIen.Controllers
{
    // Tra cứu sách dành cho độc giả (chỉ xem). Việc thêm/sửa/xóa sách nằm ở khu vực /admin.
    public class CatalogController : Controller
    {
        private readonly MongoDbContext _context;
        private const int PageSize = 8;

        private readonly UserManager<ApplicationUser> _userManager;

        public CatalogController(MongoDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        public IActionResult Index(string? searchString, int page = 1)
        {
            ViewData["CurrentFilter"] = searchString;

            var filter = FilterDefinition<Book>.Empty;
            if (!string.IsNullOrWhiteSpace(searchString))
            {
                var pattern = new BsonRegularExpression(Regex.Escape(searchString.Trim()), "i");
                var f = Builders<Book>.Filter;
                filter = f.Or(
                    f.Regex(b => b.BookCode, pattern),
                    f.Regex(b => b.Title, pattern),
                    f.Regex(b => b.Author, pattern),
                    f.Regex(b => b.Genre, pattern),
                    f.Regex(b => b.Publisher, pattern));
            }

            var totalCount = (int)_context.Books.CountDocuments(filter);
            var totalPages = totalCount == 0 ? 1 : (int)Math.Ceiling(totalCount / (double)PageSize);
            if (page < 1) page = 1;
            if (page > totalPages) page = totalPages;

            var books = _context.Books.Find(filter).SortBy(b => b.Title)
                .Skip((page - 1) * PageSize).Limit(PageSize).ToList();

            // Số bản còn cho mượn của từng sách trong trang hiện tại
            var codes = books.Select(b => b.BookCode).ToList();
            var available = _context.BookCopies
                .Find(Builders<BookCopy>.Filter.In(c => c.BookCode, codes) & Builders<BookCopy>.Filter.Eq(c => c.Status, BookCopyStatus.Available))
                .ToList().GroupBy(c => c.BookCode).ToDictionary(g => g.Key, g => g.Count());

            ViewData["CurrentPage"] = page;
            ViewData["TotalPages"] = totalPages;
            ViewData["TotalCount"] = totalCount;
            ViewData["Available"] = available;
            return View(books);
        }

        public async Task<IActionResult> Details(string id)
        {
            if (string.IsNullOrEmpty(id)) return NotFound();

            var book = _context.Books.Find(b => b.BookCode == id).FirstOrDefault();
            if (book == null) return NotFound();

            var copies = _context.BookCopies.Find(c => c.BookCode == id).ToList();
            ViewData["TotalCopies"] = copies.Count;
            ViewData["AvailableCopies"] = copies.Count(c => c.Status == BookCopyStatus.Available);

            // Đánh giá sao, bình luận, thích/không thích
            var reviews = _context.BookReviews.Find(r => r.BookCode == id)
                .SortByDescending(r => r.CreatedAt).ToList();
            var reactions = _context.BookReactions.Find(r => r.BookCode == id).ToList();
            var feedback = new BookFeedbackViewModel
            {
                Reviews = reviews,
                RatingCount = reviews.Count,
                AverageRating = reviews.Count == 0 ? 0 : reviews.Average(r => r.Rating),
                LikeCount = reactions.Count(r => r.Type == ReactionType.Like),
                DislikeCount = reactions.Count(r => r.Type == ReactionType.Dislike)
            };

            if (User.Identity?.IsAuthenticated == true)
            {
                var user = await _userManager.GetUserAsync(User);
                if (user != null)
                {
                    feedback.IsSignedIn = true;
                    feedback.IsAdmin = user.IsAdmin;
                    feedback.CurrentUserId = user.Id;
                    feedback.MyReaction = reactions.FirstOrDefault(r => r.UserId == user.Id)?.Type;
                    feedback.MyReview = reviews.FirstOrDefault(r => r.UserId == user.Id);
                    ViewData["InCart"] = QuanLyThuVIen.Services.BorrowCart
                        .Get(HttpContext.Session, user.Id).Contains(id);
                }
            }

            ViewData["Feedback"] = feedback;
            return View(book);
        }
    }
}
