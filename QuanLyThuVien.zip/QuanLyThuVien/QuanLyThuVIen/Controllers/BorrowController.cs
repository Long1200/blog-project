using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;
using QuanLyThuVIen.Services;

namespace QuanLyThuVIen.Controllers
{
    // Độc giả tự mượn sách: chọn tối đa 3 cuốn vào "phiếu mượn tạm" (Session) rồi xác nhận.
    // Việc kiểm tra luật mượn (thẻ hợp lệ, chưa có phiếu dở dang, còn đầu sách trống, hạn trả 15 ngày)
    // và ghi CSDL đều do LoanService.CreateLoan xử lý - cùng 1 nơi với phía admin để 2 bên không lệch luật.
    [Authorize]
    public class BorrowController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly MongoDbContext _context;
        private readonly LoanService _loanService;

        public BorrowController(UserManager<ApplicationUser> userManager, MongoDbContext context, LoanService loanService)
        {
            _userManager = userManager;
            _context = context;
            _loanService = loanService;
        }

        // Xem phiếu mượn tạm + nút xác nhận
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            return View(BuildModel(user));
        }

        // Thêm 1 cuốn vào phiếu mượn tạm rồi chuyển tới trang phiếu
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Add(string? bookCode)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            if (string.IsNullOrWhiteSpace(bookCode) || _context.Books.CountDocuments(b => b.BookCode == bookCode) == 0)
            {
                TempData["ErrorMessage"] = "Không tìm thấy sách này.";
                return RedirectToAction(nameof(Index));
            }

            var cart = BorrowCart.Get(HttpContext.Session, user.Id);
            if (cart.Contains(bookCode))
            {
                TempData["ErrorMessage"] = "Cuốn này đã có trong phiếu mượn của bạn.";
                return RedirectToAction(nameof(Index));
            }
            if (cart.Count >= BorrowCart.MaxBooks)
            {
                TempData["ErrorMessage"] = $"Mỗi lần chỉ mượn tối đa {BorrowCart.MaxBooks} cuốn. Hãy bỏ bớt một cuốn trước khi thêm.";
                return RedirectToAction(nameof(Index));
            }

            var available = _context.BookCopies.CountDocuments(c => c.BookCode == bookCode && c.Status == BookCopyStatus.Available);
            if (available == 0)
            {
                TempData["ErrorMessage"] = "Sách này hiện đã hết bản, chưa thể mượn.";
                return RedirectToAction("Details", "Catalog", new { id = bookCode });
            }

            cart.Add(bookCode);
            BorrowCart.Save(HttpContext.Session, user.Id, cart);
            TempData["SuccessMessage"] = "Đã thêm sách vào phiếu mượn.";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Remove(string? bookCode)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            var cart = BorrowCart.Get(HttpContext.Session, user.Id);
            if (bookCode != null && cart.Remove(bookCode))
            {
                BorrowCart.Save(HttpContext.Session, user.Id, cart);
            }
            return RedirectToAction(nameof(Index));
        }

        // Xác nhận mượn: giao hết cho LoanService.CreateLoan (có transaction + khóa theo thẻ)
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> Confirm()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            if (string.IsNullOrEmpty(user.LibraryCardNumber))
            {
                TempData["ErrorMessage"] = "Bạn cần liên kết thẻ thư viện trước khi mượn sách.";
                return RedirectToAction("Index", "MyLibrary");
            }

            var cart = BorrowCart.Get(HttpContext.Session, user.Id);
            if (cart.Count == 0)
            {
                TempData["ErrorMessage"] = "Phiếu mượn đang trống.";
                return RedirectToAction(nameof(Index));
            }

            var result = _loanService.CreateLoan(user.LibraryCardNumber, cart, DateTime.Today);
            if (!result.Success)
            {
                TempData["ErrorMessage"] = result.ErrorMessage;
                return RedirectToAction(nameof(Index));
            }

            BorrowCart.Clear(HttpContext.Session, user.Id);
            TempData["SuccessMessage"] =
                $"Mượn thành công {result.Loan!.LoanDetails.Count} cuốn. Hạn trả: {result.Loan.DueDate:dd/MM/yyyy}. " +
                "Vui lòng đến quầy thủ thư để nhận sách.";
            return RedirectToAction("Index", "MyLibrary");
        }

        // Dựng dữ liệu hiển thị. Các điều kiện ở đây CHỈ để báo trước cho người dùng;
        // quyết định cuối cùng vẫn nằm ở LoanService.CreateLoan khi bấm Xác nhận.
        private BorrowCartViewModel BuildModel(ApplicationUser user)
        {
            var vm = new BorrowCartViewModel { MaxBooks = BorrowCart.MaxBooks, LoanDate = DateTime.Today };

            var codes = BorrowCart.Get(HttpContext.Session, user.Id);
            var kept = new List<string>();
            foreach (var code in codes)
            {
                var book = _context.Books.Find(b => b.BookCode == code).FirstOrDefault();
                if (book == null) continue; // sách đã bị xóa khỏi hệ thống -> bỏ khỏi phiếu
                kept.Add(code);
                vm.Items.Add(new BorrowCartItem
                {
                    Book = book,
                    AvailableCopies = (int)_context.BookCopies.CountDocuments(
                        c => c.BookCode == code && c.Status == BookCopyStatus.Available)
                });
            }
            if (kept.Count != codes.Count) BorrowCart.Save(HttpContext.Session, user.Id, kept);

            if (string.IsNullOrEmpty(user.LibraryCardNumber))
            {
                vm.Problems.Add("Bạn chưa liên kết thẻ thư viện. Hãy liên kết thẻ ở Trang cá nhân để mượn sách.");
                return vm;
            }

            vm.Card = _context.LibraryCards.Find(c => c.CardNumber == user.LibraryCardNumber).FirstOrDefault();
            if (vm.Card == null)
            {
                vm.Problems.Add("Không tìm thấy thẻ thư viện đã liên kết với tài khoản.");
                return vm;
            }

            if (vm.Card.ExpiryDate.Date < vm.LoanDate)
                vm.Problems.Add("Thẻ thư viện đã hết hạn. Hãy gia hạn thẻ trước khi mượn.");
            else if (vm.Card.Status != LibraryCardStatus.Active)
                vm.Problems.Add("Thẻ thư viện đang bị khóa (có thể do khoản bồi thường chưa thanh toán).");

            if (_loanService.GetActiveLoans(vm.Card.CardNumber).Count > 0)
                vm.Problems.Add("Thẻ đang có phiếu mượn chưa trả hết, cần trả sách trước khi mượn tiếp.");

            return vm;
        }
    }
}
