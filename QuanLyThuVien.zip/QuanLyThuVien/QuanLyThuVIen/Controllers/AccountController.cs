using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;

namespace QuanLyThuVIen.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly SignInManager<ApplicationUser> _signInManager;
        private readonly IWebHostEnvironment _env;

        // Ảnh đại diện người dùng tải lên được lưu ở wwwroot/uploads/avatars, trong DB chỉ lưu đường dẫn
        private const string AvatarUrlPrefix = "/uploads/avatars/";
        private const long MaxAvatarBytes = 2 * 1024 * 1024; // 2 MB

        public AccountController(UserManager<ApplicationUser> userManager, SignInManager<ApplicationUser> signInManager, IWebHostEnvironment env)
        {
            _userManager = userManager;
            _signInManager = signInManager;
            _env = env;
        }

        // ---------- Đăng ký ----------
        [HttpGet]
        public async Task<IActionResult> Register(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            ViewBag.ExternalSchemes = (await _signInManager.GetExternalAuthenticationSchemesAsync()).ToList();
            return View(new RegisterViewModel());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Register(RegisterViewModel model, string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            ViewBag.ExternalSchemes = (await _signInManager.GetExternalAuthenticationSchemesAsync()).ToList();

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            // Email dùng làm cả UserName lẫn Email để đăng nhập bằng email cho đơn giản.
            var existing = await _userManager.FindByEmailAsync(model.Email);
            if (existing != null)
            {
                ModelState.AddModelError(nameof(model.Email), "Email này đã được đăng ký");
                return View(model);
            }

            var user = new ApplicationUser
            {
                UserName = model.Email,
                Email = model.Email,
                FullName = model.FullName,
                CreatedDate = DateTime.UtcNow
            };

            // UserManager.CreateAsync sẽ tự kiểm tra lại chính sách mật khẩu (Program.cs) trước khi băm/lưu,
            // nên dù ai đó bỏ qua validate ở Client thì Server vẫn chặn được mật khẩu yếu.
            var result = await _userManager.CreateAsync(user, model.Password);

            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return View(model);
            }

            await _signInManager.SignInAsync(user, isPersistent: false);

            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        // ---------- Đăng nhập ----------
        [HttpGet]
        public async Task<IActionResult> Login(string? returnUrl = null)
        {
            ViewData["ReturnUrl"] = returnUrl;
            ViewBag.ExternalSchemes = (await _signInManager.GetExternalAuthenticationSchemesAsync()).ToList();
            return View(new LoginViewModel { ReturnUrl = returnUrl });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            ViewData["ReturnUrl"] = model.ReturnUrl;
            ViewBag.ExternalSchemes = (await _signInManager.GetExternalAuthenticationSchemesAsync()).ToList();

            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "Email hoặc mật khẩu không đúng");
                return View(model);
            }

            var result = await _signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, lockoutOnFailure: true);

            if (result.IsLockedOut)
            {
                ModelState.AddModelError(string.Empty, "Tài khoản tạm khóa do đăng nhập sai nhiều lần, vui lòng thử lại sau");
                return View(model);
            }

            if (!result.Succeeded)
            {
                ModelState.AddModelError(string.Empty, "Email hoặc mật khẩu không đúng");
                return View(model);
            }

            if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            {
                return Redirect(model.ReturnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        // ---------- Đăng nhập bằng Google / Facebook ----------
        // Gọi từ nút "Đăng nhập với Google/Facebook" trên trang Login: chuyển hướng người dùng
        // sang trang xác thực của Google/Facebook, xong quay lại action ExternalLoginCallback bên dưới.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ExternalLogin(string provider, string? returnUrl = null)
        {
            var redirectUrl = Url.Action(nameof(ExternalLoginCallback), "Account", new { returnUrl });
            var properties = _signInManager.ConfigureExternalAuthenticationProperties(provider, redirectUrl);
            return Challenge(properties, provider);
        }

        [HttpGet]
        public async Task<IActionResult> ExternalLoginCallback(string? returnUrl = null, string? remoteError = null)
        {
            if (remoteError != null)
            {
                TempData["ErrorMessage"] = $"Lỗi từ nhà cung cấp đăng nhập ngoài: {remoteError}";
                return RedirectToAction(nameof(Login));
            }

            var info = await _signInManager.GetExternalLoginInfoAsync();
            if (info == null)
            {
                TempData["ErrorMessage"] = "Không lấy được thông tin đăng nhập từ Google/Facebook";
                return RedirectToAction(nameof(Login));
            }

            // Nếu tài khoản ngoài này đã từng liên kết với 1 user -> đăng nhập luôn
            var signInResult = await _signInManager.ExternalLoginSignInAsync(info.LoginProvider, info.ProviderKey, isPersistent: false);
            if (signInResult.Succeeded)
            {
                return LocalRedirectOrHome(returnUrl);
            }

            // Chưa từng đăng nhập bằng nhà cung cấp này -> tạo tài khoản mới (hoặc liên kết vào tài khoản
            // đã có cùng email) dựa trên email do Google/Facebook trả về.
            var email = info.Principal.FindFirstValue(ClaimTypes.Email);
            var name = info.Principal.FindFirstValue(ClaimTypes.Name) ?? email ?? "Người dùng";

            if (string.IsNullOrEmpty(email))
            {
                TempData["ErrorMessage"] = "Không lấy được email từ tài khoản Google/Facebook, vui lòng đăng ký thủ công";
                return RedirectToAction(nameof(Login));
            }

            var user = await _userManager.FindByEmailAsync(email);
            if (user == null)
            {
                user = new ApplicationUser
                {
                    UserName = email,
                    Email = email,
                    EmailConfirmed = true,
                    FullName = name,
                    CreatedDate = DateTime.UtcNow
                };

                var createResult = await _userManager.CreateAsync(user);
                if (!createResult.Succeeded)
                {
                    TempData["ErrorMessage"] = string.Join("; ", createResult.Errors.Select(e => e.Description));
                    return RedirectToAction(nameof(Login));
                }
            }

            var addLoginResult = await _userManager.AddLoginAsync(user, info);
            if (!addLoginResult.Succeeded)
            {
                TempData["ErrorMessage"] = string.Join("; ", addLoginResult.Errors.Select(e => e.Description));
                return RedirectToAction(nameof(Login));
            }

            await _signInManager.SignInAsync(user, isPersistent: false);
            return LocalRedirectOrHome(returnUrl);
        }

        private IActionResult LocalRedirectOrHome(string? returnUrl)
        {
            if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        // ---------- Đăng xuất ----------
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Logout()
        {
            await _signInManager.SignOutAsync();
            return RedirectToAction("Index", "Home");
        }

        [HttpGet]
        public IActionResult AccessDenied()
        {
            return View();
        }

        // ---------- Trang cá nhân ----------
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Profile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            // Danh sách nhà cung cấp đăng nhập ngoài đã liên kết (để View hiển thị "Đã liên kết Google/Facebook")
            var logins = await _userManager.GetLoginsAsync(user);
            ViewBag.HasPassword = await _userManager.HasPasswordAsync(user);
            ViewBag.ExternalLogins = logins;

            return View(user);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> EditProfile()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            var model = new EditProfileViewModel
            {
                FullName = user.FullName,
                DateOfBirth = user.DateOfBirth,
                PhoneNumber = user.PhoneNumber,
                Address = user.Address,
                AvatarUrl = user.AvatarUrl
            };

            return View(model);
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> EditProfile(EditProfileViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            // Ô "Ảnh đại diện (URL)": chỉ nhận link http/https, hoặc giữ nguyên ảnh đã tải lên (đường dẫn /uploads/avatars/...).
            // Không cho tự gõ đường dẫn nội bộ khác để tránh trỏ sang ảnh của người khác.
            var newAvatar = string.IsNullOrWhiteSpace(model.AvatarUrl) ? null : model.AvatarUrl.Trim();
            var oldAvatar = user.AvatarUrl;
            if (newAvatar != null && newAvatar != oldAvatar
                && !(Uri.TryCreate(newAvatar, UriKind.Absolute, out var uri) && (uri.Scheme == Uri.UriSchemeHttp || uri.Scheme == Uri.UriSchemeHttps)))
            {
                ModelState.AddModelError(nameof(model.AvatarUrl), "Đường dẫn ảnh không hợp lệ (cần bắt đầu bằng http:// hoặc https://)");
                return View(model);
            }

            user.FullName = model.FullName;
            user.DateOfBirth = model.DateOfBirth;
            user.PhoneNumber = model.PhoneNumber;
            user.Address = model.Address;
            user.AvatarUrl = newAvatar;

            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return View(model);
            }

            if (newAvatar != oldAvatar) DeleteLocalAvatar(oldAvatar); // đổi sang link khác / xóa link -> dọn file cũ đã tải lên
            TempData["SuccessMessage"] = "Cập nhật thông tin cá nhân thành công";
            return RedirectToAction(nameof(Profile));
        }

        // ---------- Đổi / xóa ảnh đại diện (tải ảnh từ máy lên) ----------
        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequestSizeLimit(3 * 1024 * 1024)]
        public async Task<IActionResult> UploadAvatar(IFormFile? avatar)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            if (avatar == null || avatar.Length == 0)
            {
                TempData["ErrorMessage"] = "Vui lòng chọn một ảnh.";
                return RedirectToAction(nameof(Profile));
            }
            if (avatar.Length > MaxAvatarBytes)
            {
                TempData["ErrorMessage"] = "Ảnh quá lớn, tối đa 2 MB.";
                return RedirectToAction(nameof(Profile));
            }

            // Xác định loại ảnh từ vài byte đầu của file, không tin vào tên file hay Content-Type do trình duyệt gửi
            var header = new byte[12];
            await using (var input = avatar.OpenReadStream())
            {
                await input.ReadAtLeastAsync(header, header.Length, throwOnEndOfStream: false);
            }
            var ext = DetectImageExtension(header);
            if (ext == null)
            {
                TempData["ErrorMessage"] = "Tệp không phải ảnh hợp lệ. Chỉ nhận JPG, PNG, GIF hoặc WEBP.";
                return RedirectToAction(nameof(Profile));
            }

            // Tên file do server tự sinh (GUID) nên không thể bị ghi đè hay chèn đường dẫn lạ
            var dir = Path.Combine(_env.WebRootPath, "uploads", "avatars");
            Directory.CreateDirectory(dir);
            var fileName = Guid.NewGuid().ToString("N") + ext;
            await using (var fs = new FileStream(Path.Combine(dir, fileName), FileMode.CreateNew))
            {
                await avatar.CopyToAsync(fs);
            }

            var oldAvatar = user.AvatarUrl;
            user.AvatarUrl = AvatarUrlPrefix + fileName;
            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
            {
                DeleteLocalAvatar(user.AvatarUrl);
                TempData["ErrorMessage"] = string.Join(" ", result.Errors.Select(e => e.Description));
                return RedirectToAction(nameof(Profile));
            }

            DeleteLocalAvatar(oldAvatar);
            TempData["SuccessMessage"] = "Đã cập nhật ảnh đại diện";
            return RedirectToAction(nameof(Profile));
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveAvatar()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            var oldAvatar = user.AvatarUrl;
            user.AvatarUrl = null;
            var result = await _userManager.UpdateAsync(user);
            if (!result.Succeeded)
            {
                TempData["ErrorMessage"] = string.Join(" ", result.Errors.Select(e => e.Description));
                return RedirectToAction(nameof(Profile));
            }

            DeleteLocalAvatar(oldAvatar);
            TempData["SuccessMessage"] = "Đã xóa ảnh đại diện";
            return RedirectToAction(nameof(Profile));
        }

        // Nhận diện JPG/PNG/GIF/WEBP theo "chữ ký" ở đầu file; trả về null nếu không phải ảnh được hỗ trợ
        private static string? DetectImageExtension(byte[] h)
        {
            if (h[0] == 0xFF && h[1] == 0xD8 && h[2] == 0xFF) return ".jpg";
            if (h[0] == 0x89 && h[1] == 0x50 && h[2] == 0x4E && h[3] == 0x47 && h[4] == 0x0D && h[5] == 0x0A && h[6] == 0x1A && h[7] == 0x0A) return ".png";
            if (h[0] == 'G' && h[1] == 'I' && h[2] == 'F' && h[3] == '8' && (h[4] == '7' || h[4] == '9') && h[5] == 'a') return ".gif";
            if (h[0] == 'R' && h[1] == 'I' && h[2] == 'F' && h[3] == 'F' && h[8] == 'W' && h[9] == 'E' && h[10] == 'B' && h[11] == 'P') return ".webp";
            return null;
        }

        // Chỉ xóa file nằm trong wwwroot/uploads/avatars; link ngoài (http/https) thì bỏ qua
        private void DeleteLocalAvatar(string? avatarUrl)
        {
            if (string.IsNullOrEmpty(avatarUrl) || !avatarUrl.StartsWith(AvatarUrlPrefix, StringComparison.OrdinalIgnoreCase)) return;
            var path = Path.Combine(_env.WebRootPath, "uploads", "avatars", Path.GetFileName(avatarUrl)); // GetFileName chặn "../"
            try
            {
                if (System.IO.File.Exists(path)) System.IO.File.Delete(path);
            }
            catch (IOException) { /* file đang bị khóa: bỏ qua, không ảnh hưởng người dùng */ }
        }

        // ---------- Đổi mật khẩu (chỉ áp dụng cho tài khoản đăng ký bằng email, không áp dụng
        // cho tài khoản chỉ đăng nhập qua Google/Facebook và chưa từng đặt mật khẩu) ----------
        [Authorize]
        [HttpGet]
        public async Task<IActionResult> ChangePassword()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            if (!await _userManager.HasPasswordAsync(user))
            {
                TempData["ErrorMessage"] = "Tài khoản này đăng nhập qua Google/Facebook, chưa có mật khẩu để đổi";
                return RedirectToAction(nameof(Profile));
            }

            return View(new ChangePasswordViewModel());
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            var user = await _userManager.GetUserAsync(User);
            if (user == null)
            {
                return NotFound();
            }

            var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
            if (!result.Succeeded)
            {
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
                return View(model);
            }

            await _signInManager.RefreshSignInAsync(user);
            TempData["SuccessMessage"] = "Đổi mật khẩu thành công";
            return RedirectToAction(nameof(Profile));
        }
    }
}
