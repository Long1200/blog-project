using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Bson;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;
using QuanLyThuVIen.Services;

namespace QuanLyThuVIen.Controllers
{
    // Trang cá nhân phía độc giả: thẻ, sách đang mượn + hạn trả, gia hạn thẻ, thanh toán bồi thường.
    // Thanh toán hiện là MÔ PHỎNG (bấm "Thanh toán" là coi như thành công); muốn thật thì nối VNPay/MoMo sandbox
    // ở 2 action POST RenewCard và PayCompensation.
    [Authorize]
    public class MyLibraryController : Controller
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly MongoDbContext _context;
        private readonly ReaderService _reader;
        private readonly CompensationService _compensationService;

        public MyLibraryController(UserManager<ApplicationUser> userManager, MongoDbContext context,
            ReaderService reader, CompensationService compensationService)
        {
            _userManager = userManager;
            _context = context;
            _reader = reader;
            _compensationService = compensationService;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            return View(new MyLibraryViewModel { User = user, Summary = _reader.GetSummary(user.LibraryCardNumber) });
        }

        // Liên kết tài khoản với thẻ thư viện: phải nhập đúng số thẻ + họ tên đã đăng ký trên thẻ,
        // và thẻ chưa gắn với tài khoản khác.
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> LinkCard(string? cardNumber, string? studentName)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            if (string.IsNullOrWhiteSpace(cardNumber) || string.IsNullOrWhiteSpace(studentName))
            {
                TempData["ErrorMessage"] = "Vui lòng nhập số thẻ và họ tên trên thẻ.";
                return RedirectToAction(nameof(Index));
            }

            var pattern = new BsonRegularExpression("^" + Regex.Escape(cardNumber.Trim()) + "$", "i");
            var card = _context.LibraryCards.Find(Builders<LibraryCard>.Filter.Regex(c => c.CardNumber, pattern)).FirstOrDefault();

            if (card == null || !string.Equals(card.StudentName.Trim(), studentName.Trim(), StringComparison.OrdinalIgnoreCase))
            {
                TempData["ErrorMessage"] = "Số thẻ hoặc họ tên không khớp với thẻ nào trong hệ thống.";
                return RedirectToAction(nameof(Index));
            }

            // Tìm tài khoản khác đang giữ thẻ (nếu có) để báo cho người dùng biết là email nào, tránh nhầm tài khoản
            var holder = _context.Users.Find(u => u.LibraryCardNumber == card.CardNumber && u.Id != user.Id).FirstOrDefault();
            if (holder != null)
            {
                TempData["ErrorMessage"] = $"Thẻ này đã được liên kết với tài khoản {MaskEmail(holder.Email)}. " +
                    "Hãy đăng nhập đúng tài khoản đó, hoặc hủy liên kết thẻ ở tài khoản đó trước rồi liên kết lại ở đây.";
                return RedirectToAction(nameof(Index));
            }

            user.LibraryCardNumber = card.CardNumber;
            var result = await _userManager.UpdateAsync(user);
            TempData[result.Succeeded ? "SuccessMessage" : "ErrorMessage"] =
                result.Succeeded ? $"Đã liên kết thẻ {card.CardNumber}." : "Không liên kết được thẻ, vui lòng thử lại.";
            return RedirectToAction(nameof(Index));
        }

        // Hủy liên kết thẻ khỏi tài khoản hiện tại để có thể liên kết lại (vào tài khoản khác hoặc nhập lại thẻ).
        // Không cho hủy khi còn sách đang mượn hoặc khoản bồi thường chưa thanh toán, vì lúc đó
        // trang cá nhân mất đường theo dõi/thanh toán các khoản này.
        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> UnlinkCard()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return NotFound();

            if (string.IsNullOrEmpty(user.LibraryCardNumber))
            {
                TempData["ErrorMessage"] = "Tài khoản này chưa liên kết thẻ nào.";
                return RedirectToAction(nameof(Index));
            }

            var summary = _reader.GetSummary(user.LibraryCardNumber);
            if (summary.Borrowed.Count > 0)
            {
                TempData["ErrorMessage"] = "Bạn còn sách đang mượn, hãy trả hết sách trước khi hủy liên kết thẻ.";
                return RedirectToAction(nameof(Index));
            }
            if (summary.Cases.Count > 0)
            {
                TempData["ErrorMessage"] = "Bạn còn khoản bồi thường chưa thanh toán, hãy thanh toán trước khi hủy liên kết thẻ.";
                return RedirectToAction(nameof(Index));
            }

            var oldCard = user.LibraryCardNumber;
            user.LibraryCardNumber = null;
            var result = await _userManager.UpdateAsync(user);
            TempData[result.Succeeded ? "SuccessMessage" : "ErrorMessage"] =
                result.Succeeded ? $"Đã hủy liên kết thẻ {oldCard}." : "Không hủy liên kết được, vui lòng thử lại.";
            return RedirectToAction(nameof(Index));
        }

        // Che bớt email khi hiển thị: longnguyen@gmail.com -> lo***@gmail.com
        private static string MaskEmail(string? email)
        {
            if (string.IsNullOrWhiteSpace(email)) return "(không rõ email)";
            var at = email.IndexOf('@');
            if (at <= 0) return "***";
            var name = email[..at];
            var visible = name.Length <= 2 ? name[..1] : name[..2];
            return visible + "***" + email[at..];
        }

        // ---------- Gia hạn thẻ ----------
        [HttpGet]
        public async Task<IActionResult> RenewCard()
        {
            var card = await GetMyCardAsync();
            if (card == null) return RedirectToAction(nameof(Index));

            return View(BuildRenewModel(card));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> RenewCard(string? method)
        {
            var user = await _userManager.GetUserAsync(User);
            var card = await GetMyCardAsync();
            if (user == null || card == null) return RedirectToAction(nameof(Index));

            if (method == null || !LibraryFees.PaymentMethods.Contains(method))
            {
                TempData["ErrorMessage"] = "Vui lòng chọn phương thức thanh toán.";
                return RedirectToAction(nameof(RenewCard));
            }

            var today = DateTime.Today;
            var oldExpiry = card.ExpiryDate.Date;
            var wasExpired = oldExpiry < today;
            var newExpiry = (wasExpired ? today : oldExpiry).AddMonths(LibraryFees.RenewMonths);

            // Điều kiện ExpiryDate == hạn cũ: bấm 2 lần / 2 tab cùng lúc thì chỉ có 1 lần được gia hạn
            var updated = _context.LibraryCards.UpdateOne(
                Builders<LibraryCard>.Filter.Eq(c => c.CardNumber, card.CardNumber)
                    & Builders<LibraryCard>.Filter.Eq(c => c.ExpiryDate, oldExpiry),
                Builders<LibraryCard>.Update.Set(c => c.ExpiryDate, newExpiry));

            if (updated.ModifiedCount != 1)
            {
                TempData["ErrorMessage"] = "Thẻ vừa được gia hạn hoặc thay đổi, vui lòng kiểm tra lại.";
                return RedirectToAction(nameof(Index));
            }

            SavePayment(user.Id, card.CardNumber, PaymentType.CardRenewal, LibraryFees.RenewCard, method,
                $"Gia hạn thẻ {card.CardNumber} đến {newExpiry:dd/MM/yyyy}");

            // Thẻ chỉ bị khóa vì hết hạn thì mở lại; còn khoản bồi thường chưa trả thì vẫn khóa
            var message = $"Gia hạn thành công, thẻ có hiệu lực đến {newExpiry:dd/MM/yyyy}.";
            if (card.Status == LibraryCardStatus.Inactive && wasExpired)
            {
                if (_compensationService.TryReactivateCard(card.CardNumber))
                    message += " Thẻ đã được mở lại.";
                else
                    message += " Thẻ vẫn bị khóa vì còn khoản bồi thường chưa thanh toán.";
            }
            TempData["SuccessMessage"] = message;
            return RedirectToAction(nameof(Index));
        }

        // ---------- Thanh toán bồi thường sách mất/hỏng ----------
        [HttpGet]
        public async Task<IActionResult> PayCompensation()
        {
            var card = await GetMyCardAsync();
            if (card == null) return RedirectToAction(nameof(Index));

            return View(_reader.GetSummary(card.CardNumber));
        }

        [HttpPost, ValidateAntiForgeryToken]
        public async Task<IActionResult> PayCompensation(int[]? caseIds, string? method)
        {
            var user = await _userManager.GetUserAsync(User);
            var card = await GetMyCardAsync();
            if (user == null || card == null) return RedirectToAction(nameof(Index));

            if (caseIds == null || caseIds.Length == 0)
            {
                TempData["ErrorMessage"] = "Vui lòng chọn ít nhất một khoản cần thanh toán.";
                return RedirectToAction(nameof(PayCompensation));
            }
            if (method == null || !LibraryFees.PaymentMethods.Contains(method))
            {
                TempData["ErrorMessage"] = "Vui lòng chọn phương thức thanh toán.";
                return RedirectToAction(nameof(PayCompensation));
            }

            // Chỉ cho thanh toán các khoản thuộc thẻ của chính mình (không tin id từ form)
            var mine = _reader.GetSummary(card.CardNumber).Cases.Where(c => caseIds.Contains(c.CaseId)).ToList();
            var paid = new List<CompensationItem>();
            foreach (var item in mine)
            {
                var result = _compensationService.Resolve(item.CaseId, DateTime.Today);
                if (result.Success) paid.Add(item);
            }

            if (paid.Count == 0)
            {
                TempData["ErrorMessage"] = "Không có khoản nào được thanh toán (có thể đã được xử lý trước đó).";
                return RedirectToAction(nameof(Index));
            }

            var total = paid.Sum(p => p.Amount);
            SavePayment(user.Id, card.CardNumber, PaymentType.Compensation, total, method,
                "Bồi thường: " + string.Join(", ", paid.Select(p => p.Title)));

            TempData["SuccessMessage"] = $"Đã thanh toán {LibraryFees.Vnd(total)} cho {paid.Count} khoản bồi thường.";
            return RedirectToAction(nameof(Index));
        }

        // ---------- Hỗ trợ ----------
        private async Task<LibraryCard?> GetMyCardAsync()
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null || string.IsNullOrEmpty(user.LibraryCardNumber)) return null;
            return _context.LibraryCards.Find(c => c.CardNumber == user.LibraryCardNumber).FirstOrDefault();
        }

        private RenewCardViewModel BuildRenewModel(LibraryCard card)
        {
            var today = DateTime.Today;
            var baseDate = card.ExpiryDate.Date < today ? today : card.ExpiryDate.Date;
            return new RenewCardViewModel
            {
                Card = card,
                NewExpiry = baseDate.AddMonths(LibraryFees.RenewMonths),
                HasUnresolvedCases = _context.CompensationCases.CountDocuments(c => c.CardNumber == card.CardNumber && !c.IsResolved) > 0
            };
        }

        private void SavePayment(string userId, string cardNumber, PaymentType type, long amount, string method, string description)
        {
            _context.Payments.InsertOne(new Payment
            {
                PaymentId = _context.NextId("Payment"),
                UserId = userId,
                CardNumber = cardNumber,
                Type = type,
                Amount = amount,
                Method = method,
                Description = description,
                CreatedAtUtc = DateTime.UtcNow
            });
        }
    }
}
