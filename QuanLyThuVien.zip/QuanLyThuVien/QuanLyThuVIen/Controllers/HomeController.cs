using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;
using QuanLyThuVIen.Services;
using System.Diagnostics;

namespace QuanLyThuVIen.Controllers
{
    public class HomeController : Controller
    {
        private readonly MongoDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly ReaderService _reader;

        public HomeController(MongoDbContext context, UserManager<ApplicationUser> userManager, ReaderService reader)
        {
            _context = context;
            _userManager = userManager;
            _reader = reader;
        }

        // Trang chủ dành cho độc giả: tìm sách, sách mới, thể loại; nếu đã đăng nhập + có thẻ thì
        // hiện thêm tóm tắt sách đang mượn / sắp đến hạn.
        public async Task<IActionResult> Index()
        {
            var allBooks = _context.Books.Find(FilterDefinition<Book>.Empty).ToList();
            var bookByCode = allBooks.ToDictionary(b => b.BookCode);

            var copies = _context.BookCopies.Find(FilterDefinition<BookCopy>.Empty)
                .Project(c => new { c.BookCopyId, c.BookCode, c.Status }).ToList();
            var copyToBook = copies.ToDictionary(c => c.BookCopyId, c => c.BookCode);

            var newBooks = allBooks.OrderByDescending(b => b.PublicationYear).Take(8).ToList();

            // ----- Lượt mượn: mỗi LoanDetail là 1 lượt mượn của 1 đầu sách -> quy về mã sách -----
            var loanDetails = _context.LoanDetails.Find(FilterDefinition<LoanDetail>.Empty)
                .Project(ld => new { ld.LoanId, ld.BookCopyId }).ToList();

            var since = DateTime.Today.AddDays(-30);
            var recentLoanIds = _context.Loans.Find(l => l.LoanDate >= since)
                .Project(l => l.LoanId).ToList().ToHashSet();

            var totalByBook = new Dictionary<string, int>();
            var recentByBook = new Dictionary<string, int>();
            foreach (var ld in loanDetails)
            {
                if (!copyToBook.TryGetValue(ld.BookCopyId, out var code)) continue;
                totalByBook[code] = totalByBook.GetValueOrDefault(code) + 1;
                if (recentLoanIds.Contains(ld.LoanId))
                    recentByBook[code] = recentByBook.GetValueOrDefault(code) + 1;
            }

            BookStat ToStat(Book b) => new()
            {
                Book = b,
                // Lượt mượn thật + lượt mượn mẫu (demo)
                BorrowCount = totalByBook.GetValueOrDefault(b.BookCode) + b.SampleBorrowCount,
                RecentCount = recentByBook.GetValueOrDefault(b.BookCode)
            };

            // Xếp hạng: nhiều lượt mượn nhất lên đầu, bằng nhau thì xếp theo tên
            var ranked = allBooks.Select(ToStat).Where(s => s.BorrowCount > 0)
                .OrderByDescending(s => s.BorrowCount).ThenBy(s => s.Book.Title).Take(5).ToList();

            // Sách mới nhập: BookCopyId tự tăng nên đầu sách có Id lớn nhất = vừa nhập gần nhất
            var newlyStocked = copies.GroupBy(c => c.BookCode)
                .Select(g => new { Code = g.Key, LastId = g.Max(c => c.BookCopyId) })
                .OrderByDescending(x => x.LastId)
                .Where(x => bookByCode.ContainsKey(x.Code))
                .Select(x => ToStat(bookByCode[x.Code])).Take(4).ToList();

            // Sách hot: ưu tiên mượn nhiều trong 30 ngày gần đây; thiếu thì bù bằng sách mượn nhiều
            // nhất từ trước đến nay, cuối cùng bù bằng sách mới nhập để slide luôn có đủ sách
            var hot = allBooks.Select(ToStat).Where(s => s.RecentCount > 0)
                .OrderByDescending(s => s.RecentCount).ThenByDescending(s => s.BorrowCount).Take(5).ToList();
            foreach (var item in ranked.Concat(newlyStocked))
            {
                if (hot.Count >= 5) break;
                if (hot.All(h => h.Book.BookCode != item.Book.BookCode)) hot.Add(item);
            }

            var availableCopies = copies.Where(c => c.Status == BookCopyStatus.Available).ToList();

            var model = new HomeViewModel
            {
                TotalBooks = allBooks.Count,
                AvailableCopies = availableCopies.Count,
                NewBooks = newBooks,
                HotBooks = hot,
                RankedBooks = ranked,
                NewlyStocked = newlyStocked,
                AvailableByBook = availableCopies.GroupBy(bc => bc.BookCode).ToDictionary(g => g.Key, g => g.Count()),
                Genres = allBooks.Select(b => b.Genre).Where(g => !string.IsNullOrWhiteSpace(g))
                    .Select(g => g!).Distinct().OrderBy(g => g).ToList()
            };

            if (User.Identity?.IsAuthenticated == true)
            {
                var user = await _userManager.GetUserAsync(User);
                if (user != null)
                {
                    model.UserName = string.IsNullOrWhiteSpace(user.FullName) ? user.Email : user.FullName;
                    model.Reader = _reader.GetSummary(user.LibraryCardNumber);
                }
            }

            return View(model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
