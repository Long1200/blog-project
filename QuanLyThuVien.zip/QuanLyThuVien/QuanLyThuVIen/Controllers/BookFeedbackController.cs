using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Controllers
{
    // Thích/không thích, đánh giá sao và bình luận cho từng cuốn sách. Phải đăng nhập mới dùng được.
    [Authorize]
    public class BookFeedbackController : Controller
    {
        private const int MaxCommentLength = 1000;

        private readonly MongoDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public BookFeedbackController(MongoDbContext context, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _userManager = userManager;
        }

        // Bấm Thích/Không thích: bấm lại đúng nút đang chọn thì bỏ chọn, bấm nút còn lại thì đổi sang nút đó
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> React(string id, ReactionType type)
        {
            if (!BookExists(id)) return NotFound();
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            var existing = _context.BookReactions.Find(r => r.BookCode == id && r.UserId == user.Id).FirstOrDefault();
            if (existing == null)
            {
                try
                {
                    _context.BookReactions.InsertOne(new BookReaction
                    {
                        ReactionId = _context.NextId(nameof(BookReaction)),
                        BookCode = id,
                        UserId = user.Id,
                        Type = type
                    });
                }
                catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
                {
                    // Bấm 2 lần quá nhanh: bản ghi đã được tạo bởi request trước, bỏ qua
                }
            }
            else if (existing.Type == type)
            {
                _context.BookReactions.DeleteOne(r => r.ReactionId == existing.ReactionId);
            }
            else
            {
                _context.BookReactions.UpdateOne(r => r.ReactionId == existing.ReactionId,
                    Builders<BookReaction>.Update.Set(r => r.Type, type));
            }

            return BackToBook(id);
        }

        // Gửi đánh giá sao + bình luận (đã có thì cập nhật)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Review(string id, int rating, string? comment)
        {
            if (!BookExists(id)) return NotFound();
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            if (rating < 1 || rating > 5)
            {
                TempData["FeedbackError"] = "Vui lòng chọn số sao từ 1 đến 5.";
                return BackToBook(id);
            }

            comment = string.IsNullOrWhiteSpace(comment) ? null : comment.Trim();
            if (comment != null && comment.Length > MaxCommentLength)
            {
                TempData["FeedbackError"] = $"Bình luận tối đa {MaxCommentLength} ký tự.";
                return BackToBook(id);
            }

            var existing = _context.BookReviews.Find(r => r.BookCode == id && r.UserId == user.Id).FirstOrDefault();
            if (existing == null)
            {
                try
                {
                    _context.BookReviews.InsertOne(new BookReview
                    {
                        ReviewId = _context.NextId(nameof(BookReview)),
                        BookCode = id,
                        UserId = user.Id,
                        UserName = DisplayName(user),
                        Rating = rating,
                        Comment = comment
                    });
                    TempData["FeedbackOk"] = "Đã gửi đánh giá của bạn.";
                    return BackToBook(id);
                }
                catch (MongoWriteException ex) when (ex.WriteError.Category == ServerErrorCategory.DuplicateKey)
                {
                    // Gửi 2 lần quá nhanh: đánh giá đã có, rơi xuống nhánh cập nhật bên dưới
                }
            }

            _context.BookReviews.UpdateOne(r => r.BookCode == id && r.UserId == user.Id,
                Builders<BookReview>.Update
                    .Set(r => r.Rating, rating)
                    .Set(r => r.Comment, comment)
                    .Set(r => r.UserName, DisplayName(user))
                    .Set(r => r.UpdatedAt, DateTime.UtcNow));
            TempData["FeedbackOk"] = "Đã cập nhật đánh giá của bạn.";
            return BackToBook(id);
        }

        // Xóa đánh giá: chủ đánh giá hoặc admin mới được xóa
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteReview(int reviewId)
        {
            var user = await _userManager.GetUserAsync(User);
            if (user == null) return Challenge();

            var review = _context.BookReviews.Find(r => r.ReviewId == reviewId).FirstOrDefault();
            if (review == null) return NotFound();
            if (review.UserId != user.Id && !user.IsAdmin) return Forbid();

            _context.BookReviews.DeleteOne(r => r.ReviewId == reviewId);
            TempData["FeedbackOk"] = "Đã xóa đánh giá.";
            return BackToBook(review.BookCode);
        }

        private bool BookExists(string id) =>
            !string.IsNullOrEmpty(id) && _context.Books.CountDocuments(b => b.BookCode == id) > 0;

        private IActionResult BackToBook(string id) =>
            RedirectToAction("Details", "Catalog", new { id }, "feedback");

        // Tên hiển thị công khai: ưu tiên họ tên, nếu trống thì lấy phần trước @ của email (không lộ cả email)
        private static string DisplayName(ApplicationUser user)
        {
            if (!string.IsNullOrWhiteSpace(user.FullName)) return user.FullName.Trim();
            var email = user.Email ?? user.UserName ?? "Độc giả";
            var at = email.IndexOf('@');
            return at > 0 ? email[..at] : email;
        }
    }
}
