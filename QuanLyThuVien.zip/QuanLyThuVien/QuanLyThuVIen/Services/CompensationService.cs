using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Services
{
    // Service xử lý nghiệp vụ bồi thường: đánh dấu case đã bồi thường,
    // kiểm tra và mở lại thẻ khi thẻ đã hết case chưa xử lý.
    public class CompensationService
    {
        private readonly MongoDbContext _context;
        private readonly LoanService _loanService;

        // Cùng cấu hình transaction với LoanService (snapshot + majority)
        private static readonly TransactionOptions TxOptions = new(
            ReadConcern.Snapshot, ReadPreference.Primary, WriteConcern.WMajority);

        // Dùng lại LoanService.LoadDetailRelations để nạp BookCopy/Book, tránh viết trùng logic nạp dữ liệu
        public CompensationService(MongoDbContext context, LoanService loanService)
        {
            _context = context;
            _loanService = loanService;
        }

        // Lấy danh sách case bồi thường chưa xử lý (IsResolved = false) của 1 thẻ,
        // kèm LoanDetail -> BookCopy -> Book để View hiển thị được tên sách.
        // Chỉ đọc dữ liệu nên không cần transaction.
        public List<CompensationCase> GetUnresolvedCases(string cardNumber)
        {
            var cases = _context.CompensationCases
                .Find(c => c.CardNumber == cardNumber && !c.IsResolved)
                .SortBy(c => c.CreatedDate)
                .ToList();

            if (cases.Count == 0)
            {
                return cases;
            }

            var detailIds = cases.Select(c => c.LoanDetailId).Distinct().ToList();
            var details = _context.LoanDetails
                .Find(Builders<LoanDetail>.Filter.In(ld => ld.LoanDetailId, detailIds))
                .ToList();
            _loanService.LoadDetailRelations(details);

            var detailsById = details.ToDictionary(d => d.LoanDetailId);
            foreach (var c in cases)
            {
                c.LoanDetail = detailsById.GetValueOrDefault(c.LoanDetailId);
            }

            return cases;
        }

        // Đánh dấu 1 case đã bồi thường xong (IsResolved = true, ResolvedDate = resolvedDate),
        // sau đó mở lại thẻ nếu không còn case nào chưa xử lý.
        public (bool Success, string ErrorMessage) Resolve(int compensationCaseId, DateTime resolvedDate)
        {
            var resolvedDay = resolvedDate.Date;

            using var session = _context.Client.StartSession();
            return session.WithTransaction<(bool Success, string ErrorMessage)>((s, ct) =>
            {
                var compensationCase = _context.CompensationCases
                    .Find(s, c => c.CompensationCaseId == compensationCaseId).FirstOrDefault();
                if (compensationCase == null)
                {
                    return (false, "Không tìm thấy case bồi thường.");
                }

                if (compensationCase.IsResolved)
                {
                    return (false, "Case này đã được bồi thường trước đó.");
                }

                // Khóa theo thẻ: 2 request xử lý 2 case khác nhau của cùng 1 thẻ phải xếp hàng,
                // nếu không cả hai đều có thể thấy "còn 1 case chưa xử lý" và thẻ không bao giờ được mở lại
                _context.AcquireLock(s, "Card:" + compensationCase.CardNumber);

                var changed = _context.CompensationCases.UpdateOne(
                    s,
                    Builders<CompensationCase>.Filter.Eq(c => c.CompensationCaseId, compensationCaseId)
                        & Builders<CompensationCase>.Filter.Eq(c => c.IsResolved, false),
                    Builders<CompensationCase>.Update
                        .Set(c => c.IsResolved, true)
                        .Set(c => c.ResolvedDate, resolvedDay));

                if (changed.ModifiedCount != 1)
                {
                    return (false, "Case này đã được bồi thường trước đó.");
                }

                // Chạy cùng session để việc mở thẻ và việc đánh dấu bồi thường được commit/hủy cùng nhau
                ReactivateCardIfNoUnresolvedCase(s, compensationCase.CardNumber);

                return (true, string.Empty);
            }, TxOptions);
        }

        // Kiểm tra 1 thẻ còn CompensationCase nào chưa xử lý không; nếu hết thì mở lại thẻ
        // (LibraryCard.Status = Active) và trả về true. Gọi độc lập sẽ tự mở transaction riêng.
        public bool TryReactivateCard(string cardNumber)
        {
            using var session = _context.Client.StartSession();
            return session.WithTransaction<bool>((s, ct) =>
            {
                _context.AcquireLock(s, "Card:" + cardNumber);
                return ReactivateCardIfNoUnresolvedCase(s, cardNumber);
            }, TxOptions);
        }

        private bool ReactivateCardIfNoUnresolvedCase(IClientSessionHandle session, string cardNumber)
        {
            // Đọc trong cùng session sẽ thấy cả thay đổi vừa ghi của Resolve (chưa commit)
            bool hasUnresolvedCase = _context.CompensationCases.CountDocuments(
                session,
                c => c.CardNumber == cardNumber && !c.IsResolved,
                new CountOptions { Limit = 1 }) > 0;

            if (hasUnresolvedCase)
            {
                return false;
            }

            var result = _context.LibraryCards.UpdateOne(
                session,
                Builders<LibraryCard>.Filter.Eq(c => c.CardNumber, cardNumber),
                Builders<LibraryCard>.Update.Set(c => c.Status, LibraryCardStatus.Active));

            // MatchedCount thay vì ModifiedCount: thẻ đã Active sẵn vẫn là "tìm thấy thẻ"
            return result.MatchedCount > 0;
        }
    }
}
