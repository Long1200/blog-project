using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Models.ViewModels;

namespace QuanLyThuVIen.Services
{
    // Gom dữ liệu phía độc giả: thẻ, sách đang mượn + hạn trả, khoản bồi thường chưa trả, lịch sử thanh toán.
    // Chỉ đọc dữ liệu (tái sử dụng LoanService/CompensationService), nên không cần transaction.
    public class ReaderService
    {
        private readonly MongoDbContext _context;
        private readonly LoanService _loanService;
        private readonly CompensationService _compensationService;

        public ReaderService(MongoDbContext context, LoanService loanService, CompensationService compensationService)
        {
            _context = context;
            _loanService = loanService;
            _compensationService = compensationService;
        }

        public ReaderSummary GetSummary(string? cardNumber)
        {
            var summary = new ReaderSummary();
            if (string.IsNullOrEmpty(cardNumber)) return summary;

            summary.Card = _context.LibraryCards.Find(c => c.CardNumber == cardNumber).FirstOrDefault();
            if (summary.Card == null) return summary;

            var today = DateTime.Today;
            foreach (var loan in _loanService.GetActiveLoans(cardNumber))
            {
                foreach (var d in loan.LoanDetails.Where(d => d.Status == LoanDetailStatus.Borrowed))
                {
                    summary.Borrowed.Add(new BorrowedItem
                    {
                        BookCode = d.BookCopy?.BookCode ?? "",
                        Title = d.BookCopy?.Book?.Title ?? "(không rõ)",
                        Author = d.BookCopy?.Book?.Author ?? "",
                        ImageUrl = d.BookCopy?.Book?.ImageUrl,
                        ControlNumber = d.BookCopy?.ControlNumber ?? "",
                        LoanId = loan.LoanId,
                        LoanDate = loan.LoanDate,
                        DueDate = loan.DueDate,
                        DaysLeft = (loan.DueDate.Date - today).Days
                    });
                }
            }
            summary.Borrowed = summary.Borrowed.OrderBy(b => b.DueDate).ToList();

            summary.Cases = _compensationService.GetUnresolvedCases(cardNumber)
                .Select(c => new CompensationItem
                {
                    CaseId = c.CompensationCaseId,
                    Title = c.LoanDetail?.BookCopy?.Book?.Title ?? "(không rõ)",
                    ControlNumber = c.LoanDetail?.BookCopy?.ControlNumber ?? "",
                    Reason = c.Reason,
                    CreatedDate = c.CreatedDate,
                    Amount = LibraryFees.ForReason(c.Reason)
                }).ToList();

            summary.Payments = _context.Payments.Find(p => p.CardNumber == cardNumber)
                .SortByDescending(p => p.CreatedAtUtc).Limit(10).ToList();

            return summary;
        }
    }
}
