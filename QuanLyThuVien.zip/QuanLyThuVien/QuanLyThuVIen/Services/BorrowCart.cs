using System.Text.Json;
using Microsoft.AspNetCore.Http;

namespace QuanLyThuVIen.Services
{
    // "Phiếu mượn tạm" của độc giả: danh sách mã sách đã chọn nhưng CHƯA xác nhận mượn.
    // Lưu trong Session, tách riêng theo từng tài khoản (key có UserId) để 2 người dùng chung
    // 1 trình duyệt không thấy giỏ của nhau. Chỉ khi bấm "Xác nhận mượn" mới ghi vào CSDL
    // (qua LoanService.CreateLoan, nơi kiểm tra đầy đủ luật mượn).
    public static class BorrowCart
    {
        // Khớp luật của LoanService: mỗi lần mượn tối đa 3 mã sách
        public const int MaxBooks = 3;

        private static string Key(string userId) => "BorrowCart:" + userId;

        public static List<string> Get(ISession session, string userId)
        {
            var json = session.GetString(Key(userId));
            if (string.IsNullOrEmpty(json)) return new List<string>();
            try
            {
                return JsonSerializer.Deserialize<List<string>>(json) ?? new List<string>();
            }
            catch (JsonException)
            {
                return new List<string>();
            }
        }

        public static void Save(ISession session, string userId, List<string> bookCodes)
        {
            session.SetString(Key(userId), JsonSerializer.Serialize(bookCodes));
        }

        public static void Clear(ISession session, string userId) => session.Remove(Key(userId));
    }
}
