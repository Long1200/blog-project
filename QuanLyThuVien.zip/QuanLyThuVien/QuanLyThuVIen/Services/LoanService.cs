using MongoDB.Driver;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Services
{
    // Service xử lý toàn bộ nghiệp vụ liên quan tới phiếu mượn (Loan/LoanDetail):
    // tạo phiếu mượn, trả sách, báo mất/báo hỏng.
    public class LoanService
    {
        private readonly MongoDbContext _context;

        // Transaction đọc snapshot + ghi majority: thay cho IsolationLevel.Serializable của SQL Server.
        // session.WithTransaction tự chạy lại callback khi gặp lỗi tạm thời (xung đột ghi...),
        // nên không cần viết thêm cơ chế thử lại riêng.
        private static readonly TransactionOptions TxOptions = new(
            ReadConcern.Snapshot, ReadPreference.Primary, WriteConcern.WMajority);

        // Ném khi một bước ghi không còn khớp điều kiện (có người vừa đổi dữ liệu) -> hủy cả transaction
        private sealed class ConflictException : Exception
        {
            public ConflictException(string message) : base(message) { }
        }

        public LoanService(MongoDbContext context)
        {
            _context = context;
        }

        // Tạo phiếu mượn mới cho 1 thẻ với danh sách mã sách được chọn (tối đa 3 mã).
        // Trả về Success=false kèm ErrorMessage nếu không tạo được, ngược lại trả về Loan vừa tạo.
        public (bool Success, string ErrorMessage, Loan? Loan) CreateLoan(string cardNumber, List<string> bookCodes, DateTime loanDate)
        {
            // ----- Validate định dạng cơ bản (không cần đọc DB) làm trước, ngoài transaction -----
            if (bookCodes == null || bookCodes.Count == 0)
            {
                return (false, "Phải chọn ít nhất 1 mã sách để mượn.", null);
            }
            if (bookCodes.Count > 3)
            {
                return (false, "Mỗi lần mượn tối đa 3 mã sách.", null);
            }
            if (bookCodes.Distinct().Count() != bookCodes.Count)
            {
                return (false, "Danh sách mã sách bị trùng lặp, mỗi mã chỉ được chọn 1 lần.", null);
            }

            // Các trường DateOnly trong Model không được chứa giờ, nên cắt về đầu ngày trước khi lưu
            var loanDay = loanDate.Date;

            using var session = _context.Client.StartSession();
            try
            {
                return session.WithTransaction<(bool Success, string ErrorMessage, Loan? Loan)>((s, ct) =>
                {
                    // Khóa theo thẻ TRƯỚC khi đọc: 2 request cùng 1 thẻ phải xếp hàng, bên sau sẽ
                    // thấy phiếu của bên trước và bị chặn ở bước kiểm tra "đang có phiếu dở dang"
                    _context.AcquireLock(s, "Card:" + cardNumber);

                    // ----- 1) Thẻ phải tồn tại -----
                    var card = _context.LibraryCards.Find(s, c => c.CardNumber == cardNumber).FirstOrDefault();
                    if (card == null)
                    {
                        return (false, "Không tìm thấy thẻ thư viện.", null);
                    }

                    // ----- 2) Thẻ phải đang Active -----
                    if (card.Status != LibraryCardStatus.Active)
                    {
                        return (false, "Thẻ thư viện đang bị khóa, không thể mượn sách.", null);
                    }

                    // ----- 3) Thẻ chưa hết hạn tính theo ngày mượn -----
                    if (card.ExpiryDate.Date < loanDay)
                    {
                        return (false, "Thẻ thư viện đã hết hạn, không thể mượn sách.", null);
                    }

                    // ----- 4) Thẻ không được có phiếu mượn đang dở dang -----
                    // Không có JOIN: lấy Id các phiếu của thẻ trước, rồi xem còn dòng nào đang Borrowed không
                    var cardLoanIds = _context.Loans.Find(s, l => l.CardNumber == cardNumber)
                        .Project(l => l.LoanId).ToList();

                    var activeFilter = Builders<LoanDetail>.Filter.In(ld => ld.LoanId, cardLoanIds)
                        & Builders<LoanDetail>.Filter.Eq(ld => ld.Status, LoanDetailStatus.Borrowed);
                    if (_context.LoanDetails.CountDocuments(s, activeFilter, new CountOptions { Limit = 1 }) > 0)
                    {
                        return (false, "Thẻ đang có phiếu mượn chưa trả hết, không thể mượn tiếp.", null);
                    }

                    // ----- 5) Từng mã sách phải tồn tại trong hệ thống -----
                    foreach (var bookCode in bookCodes)
                    {
                        if (_context.Books.CountDocuments(s, b => b.BookCode == bookCode) == 0)
                        {
                            return (false, $"Mã sách '{bookCode}' không tồn tại.", null);
                        }
                    }

                    // ----- 6) Chọn 1 BookCopy đang Available cho từng mã sách -----
                    // Chọn hết trước khi ghi bất cứ thứ gì: thiếu 1 mã là dừng, không để phiếu dở dang
                    var chosenCopies = new List<BookCopy>();
                    foreach (var bookCode in bookCodes)
                    {
                        var copy = _context.BookCopies
                            .Find(s, c => c.BookCode == bookCode && c.Status == BookCopyStatus.Available)
                            .SortBy(c => c.ControlNumber)
                            .FirstOrDefault();

                        if (copy == null)
                        {
                            return (false, $"Mã sách '{bookCode}' hiện không còn đầu sách nào trống để cho mượn.", null);
                        }
                        chosenCopies.Add(copy);
                    }

                    // ----- 7) Ghi dữ liệu: Loan + LoanDetail + đổi tình trạng đầu sách -----
                    var loan = new Loan
                    {
                        LoanId = _context.NextId(nameof(Loan)),
                        CardNumber = cardNumber,
                        LoanDate = loanDay,
                        // Hạn trả = ngày mượn + tối đa 15 ngày theo quy định của thư viện
                        DueDate = loanDay.AddDays(15)
                    };

                    // Giữ chỗ 1 dãy Id cho các dòng chi tiết bằng 1 lần gọi
                    int nextDetailId = _context.NextId(nameof(LoanDetail), chosenCopies.Count);
                    var details = chosenCopies.Select(copy => new LoanDetail
                    {
                        LoanDetailId = nextDetailId++,
                        LoanId = loan.LoanId,
                        BookCopyId = copy.BookCopyId,
                        Status = LoanDetailStatus.Borrowed
                    }).ToList();

                    _context.Loans.InsertOne(s, loan);
                    _context.LoanDetails.InsertMany(s, details);

                    // Điều kiện Status = Available nằm trong filter: nếu có request khác vừa lấy mất
                    // đầu sách thì số bản ghi đổi được sẽ thiếu -> hủy cả transaction
                    var claimResult = _context.BookCopies.UpdateMany(
                        s,
                        Builders<BookCopy>.Filter.In(c => c.BookCopyId, chosenCopies.Select(c => c.BookCopyId))
                            & Builders<BookCopy>.Filter.Eq(c => c.Status, BookCopyStatus.Available),
                        Builders<BookCopy>.Update.Set(c => c.Status, BookCopyStatus.Borrowed));

                    if (claimResult.ModifiedCount != chosenCopies.Count)
                    {
                        throw new ConflictException("Đầu sách vừa được người khác mượn, vui lòng thử lại.");
                    }

                    loan.LoanDetails = details;
                    return (true, string.Empty, loan);
                }, TxOptions);
            }
            catch (ConflictException ex)
            {
                return (false, ex.Message, null);
            }
        }

        // Lấy danh sách phiếu mượn đang hoạt động của 1 thẻ, tính RUNTIME dựa vào
        // LoanDetail còn dòng nào Status = Borrowed (không lưu cột Status riêng ở Loan).
        // Chỉ đọc dữ liệu nên không cần transaction.
        public List<Loan> GetActiveLoans(string cardNumber)
        {
            var cardLoanIds = _context.Loans.Find(l => l.CardNumber == cardNumber)
                .Project(l => l.LoanId).ToList();

            var activeLoanIds = _context.LoanDetails
                .Find(Builders<LoanDetail>.Filter.In(ld => ld.LoanId, cardLoanIds)
                    & Builders<LoanDetail>.Filter.Eq(ld => ld.Status, LoanDetailStatus.Borrowed))
                .Project(ld => ld.LoanId)
                .ToList()
                .Distinct()
                .ToList();

            var loans = _context.Loans
                .Find(Builders<Loan>.Filter.In(l => l.LoanId, activeLoanIds))
                .SortByDescending(l => l.LoanDate)
                .ThenByDescending(l => l.LoanId)
                .ToList();

            LoadRelations(loans);
            return loans;
        }

        // Thay cho Include()/ThenInclude() của EF: nạp thẻ + các dòng mượn + đầu sách + sách cho danh sách
        // phiếu mượn, mỗi loại dữ liệu chỉ 1 truy vấn (không truy vấn lặp theo từng phiếu).
        public void LoadRelations(IReadOnlyCollection<Loan> loans)
        {
            if (loans.Count == 0)
            {
                return;
            }

            var loanIds = loans.Select(l => l.LoanId).ToList();
            var details = _context.LoanDetails
                .Find(Builders<LoanDetail>.Filter.In(ld => ld.LoanId, loanIds))
                .ToList();
            LoadDetailRelations(details);

            var cardNumbers = loans.Select(l => l.CardNumber).Distinct().ToList();
            var cards = _context.LibraryCards
                .Find(Builders<LibraryCard>.Filter.In(c => c.CardNumber, cardNumbers))
                .ToList()
                .ToDictionary(c => c.CardNumber);

            var detailsByLoan = details.ToLookup(d => d.LoanId);
            foreach (var loan in loans)
            {
                loan.LibraryCard = cards.GetValueOrDefault(loan.CardNumber);
                loan.LoanDetails = detailsByLoan[loan.LoanId].OrderBy(d => d.LoanDetailId).ToList();
                foreach (var detail in loan.LoanDetails)
                {
                    detail.Loan = loan;
                }
            }
        }

        // Nạp BookCopy + Book cho danh sách dòng mượn (cũng được CompensationService dùng lại)
        public void LoadDetailRelations(IReadOnlyCollection<LoanDetail> details)
        {
            if (details.Count == 0)
            {
                return;
            }

            var copyIds = details.Select(d => d.BookCopyId).Distinct().ToList();
            var copies = _context.BookCopies
                .Find(Builders<BookCopy>.Filter.In(c => c.BookCopyId, copyIds))
                .ToList();

            var bookCodes = copies.Select(c => c.BookCode).Distinct().ToList();
            var books = _context.Books
                .Find(Builders<Book>.Filter.In(b => b.BookCode, bookCodes))
                .ToList()
                .ToDictionary(b => b.BookCode);

            foreach (var copy in copies)
            {
                copy.Book = books.GetValueOrDefault(copy.BookCode);
            }

            var copiesById = copies.ToDictionary(c => c.BookCopyId);
            foreach (var detail in details)
            {
                detail.BookCopy = copiesById.GetValueOrDefault(detail.BookCopyId);
            }
        }

        // Trả sách cho 1 dòng mượn cụ thể: cập nhật LoanDetail (ReturnDate, Status = Returned),
        // cập nhật BookCopy tương ứng về Status = Available.
        public (bool Success, string ErrorMessage) Return(int loanDetailId, DateTime returnDate)
        {
            var returnDay = returnDate.Date;

            using var session = _context.Client.StartSession();
            return session.WithTransaction<(bool Success, string ErrorMessage)>((s, ct) =>
            {
                // Đổi trạng thái bằng 1 lệnh nguyên tử có điều kiện Status = Borrowed: 2 request cùng trả
                // 1 dòng thì chỉ 1 request đổi được, request còn lại nhận null và báo lỗi
                var detail = _context.LoanDetails.FindOneAndUpdate(
                    s,
                    Builders<LoanDetail>.Filter.Eq(ld => ld.LoanDetailId, loanDetailId)
                        & Builders<LoanDetail>.Filter.Eq(ld => ld.Status, LoanDetailStatus.Borrowed),
                    Builders<LoanDetail>.Update
                        .Set(ld => ld.Status, LoanDetailStatus.Returned)
                        .Set(ld => ld.ReturnDate, returnDay),
                    new FindOneAndUpdateOptions<LoanDetail> { ReturnDocument = ReturnDocument.After });

                if (detail == null)
                {
                    // Phân biệt 2 nguyên nhân để báo lỗi đúng
                    bool exists = _context.LoanDetails.CountDocuments(s, ld => ld.LoanDetailId == loanDetailId) > 0;
                    return exists
                        ? (false, "Dòng mượn này không ở trạng thái đang mượn, không thể trả.")
                        : (false, "Không tìm thấy dòng mượn.");
                }

                _context.BookCopies.UpdateOne(
                    s,
                    Builders<BookCopy>.Filter.Eq(c => c.BookCopyId, detail.BookCopyId),
                    Builders<BookCopy>.Update.Set(c => c.Status, BookCopyStatus.Available));

                return (true, string.Empty);
            }, TxOptions);
        }

        // Báo mất/báo hỏng cho 1 dòng mượn cụ thể: cập nhật LoanDetail (Status = Lost/Damaged),
        // cập nhật BookCopy tương ứng (Status = Lost/Damaged), tạo CompensationCase, khóa thẻ
        // (LibraryCard.Status = Inactive).
        public (bool Success, string ErrorMessage) ReportLostOrDamaged(int loanDetailId, CompensationReason reason, DateTime reportDate)
        {
            var reportDay = reportDate.Date;

            using var session = _context.Client.StartSession();
            try
            {
                return session.WithTransaction<(bool Success, string ErrorMessage)>((s, ct) =>
                {
                    var detail = _context.LoanDetails.Find(s, ld => ld.LoanDetailId == loanDetailId).FirstOrDefault();
                    if (detail == null)
                    {
                        return (false, "Không tìm thấy dòng mượn.");
                    }

                    if (detail.Status != LoanDetailStatus.Borrowed)
                    {
                        return (false, "Dòng mượn này không ở trạng thái đang mượn, không thể báo mất/hỏng.");
                    }

                    // Phiếu cha luôn tồn tại vì LoanDetail được tạo cùng lúc với Loan
                    var cardNumber = _context.Loans.Find(s, l => l.LoanId == detail.LoanId)
                        .Project(l => l.CardNumber).First();

                    // Khóa theo thẻ vì sắp đổi trạng thái thẻ (cùng khóa với CreateLoan và Resolve)
                    _context.AcquireLock(s, "Card:" + cardNumber);

                    var newDetailStatus = reason == CompensationReason.Lost
                        ? LoanDetailStatus.Lost
                        : LoanDetailStatus.Damaged;
                    var newCopyStatus = reason == CompensationReason.Lost
                        ? BookCopyStatus.Lost
                        : BookCopyStatus.Damaged;

                    // Đổi trạng thái có điều kiện Status = Borrowed để chặn báo mất/hỏng đồng thời hoặc báo sau khi đã trả
                    var changed = _context.LoanDetails.UpdateOne(
                        s,
                        Builders<LoanDetail>.Filter.Eq(ld => ld.LoanDetailId, loanDetailId)
                            & Builders<LoanDetail>.Filter.Eq(ld => ld.Status, LoanDetailStatus.Borrowed),
                        Builders<LoanDetail>.Update.Set(ld => ld.Status, newDetailStatus));

                    if (changed.ModifiedCount != 1)
                    {
                        throw new ConflictException("Dòng mượn vừa được xử lý bởi thao tác khác, vui lòng tải lại trang.");
                    }

                    _context.BookCopies.UpdateOne(
                        s,
                        Builders<BookCopy>.Filter.Eq(c => c.BookCopyId, detail.BookCopyId),
                        Builders<BookCopy>.Update.Set(c => c.Status, newCopyStatus));

                    _context.CompensationCases.InsertOne(s, new CompensationCase
                    {
                        CompensationCaseId = _context.NextId(nameof(CompensationCase)),
                        LoanDetailId = detail.LoanDetailId,
                        CardNumber = cardNumber,
                        Reason = reason,
                        CreatedDate = reportDay,
                        IsResolved = false
                    });

                    // Khóa thẻ ngay khi phát sinh case; chỉ mở lại khi hết case chưa xử lý
                    // (xử lý ở CompensationService.TryReactivateCard)
                    _context.LibraryCards.UpdateOne(
                        s,
                        Builders<LibraryCard>.Filter.Eq(c => c.CardNumber, cardNumber),
                        Builders<LibraryCard>.Update.Set(c => c.Status, LibraryCardStatus.Inactive));

                    return (true, string.Empty);
                }, TxOptions);
            }
            catch (ConflictException ex)
            {
                return (false, ex.Message);
            }
        }
    }
}
