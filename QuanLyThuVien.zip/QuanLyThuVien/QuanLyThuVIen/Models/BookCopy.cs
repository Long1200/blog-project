using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // Đầu sách (bản sao vật lý) của 1 mã sách, phân biệt bằng số kiểm soát
    // Ví dụ: mã sách "CT101" có thể có nhiều BookCopy với ControlNumber 001, 002, 003...
    public class BookCopy
    {
        // Id số nguyên tự tăng: MongoDB không tự sinh số nguyên nên lấy từ MongoDbContext.NextId
        [BsonId]
        public int BookCopyId { get; set; }

        [Required(ErrorMessage = "Mã sách không được để trống")]
        [StringLength(20)]
        [Display(Name = "Mã sách")]
        public string BookCode { get; set; } = string.Empty;

        // Không có khóa ngoại thật trong MongoDB; Controller tự nạp Book cha khi cần hiển thị
        [BsonIgnore]
        public Book? Book { get; set; }

        // Số kiểm soát dùng để phân biệt các đầu sách cùng 1 mã sách (ví dụ: 001, 002...)
        // Cặp (BookCode, ControlNumber) có unique index, được tạo trong MongoDbContext.EnsureIndexes
        [Required(ErrorMessage = "Số kiểm soát không được để trống")]
        [StringLength(10, ErrorMessage = "Số kiểm soát tối đa 10 ký tự")]
        [Display(Name = "Số kiểm soát")]
        public string ControlNumber { get; set; } = string.Empty;

        // Lưu enum dạng chữ ("Available"...) để đọc trực tiếp trên Atlas dễ hơn số 0/1/2/3
        [BsonRepresentation(BsonType.String)]
        [Display(Name = "Tình trạng")]
        public BookCopyStatus Status { get; set; } = BookCopyStatus.Available;

        [StringLength(250, ErrorMessage = "Ghi chú tối đa 250 ký tự")]
        [Display(Name = "Ghi chú")]
        public string? Note { get; set; }
    }
}
