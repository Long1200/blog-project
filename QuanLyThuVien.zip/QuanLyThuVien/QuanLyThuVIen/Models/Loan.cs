using System.ComponentModel.DataAnnotations;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // Phiếu mượn: 1 thẻ thư viện mượn tối đa 3 mã sách/lần, mỗi mã sách là 1 LoanDetail
    // Việc phiếu mượn còn "đang hoạt động" hay không được TÍNH RUNTIME dựa vào các
    // LoanDetail (còn dòng nào Status = Borrowed thì phiếu vẫn coi là đang hoạt động),
    // không lưu cột Status riêng ở đây để tránh dữ liệu bị lệch nhau.
    public class Loan
    {
        // Id số nguyên tự tăng, lấy từ MongoDbContext.NextId
        [BsonId]
        public int LoanId { get; set; }

        [Required(ErrorMessage = "Số thẻ không được để trống")]
        [StringLength(20)]
        [Display(Name = "Số thẻ")]
        public string CardNumber { get; set; } = string.Empty;

        // Không có khóa ngoại thật trong MongoDB; Controller tự nạp thẻ khi cần hiển thị
        [BsonIgnore]
        public LibraryCard? LibraryCard { get; set; }

        [Required(ErrorMessage = "Ngày mượn không được để trống")]
        [DataType(DataType.Date)]
        [BsonDateTimeOptions(DateOnly = true)]
        [Display(Name = "Ngày mượn")]
        public DateTime LoanDate { get; set; }

        // Hạn trả: LoanDate + tối đa 15 ngày, việc kiểm tra 15 ngày do LoanService xử lý
        // DateOnly = true để chỉ lưu ngày (không có giờ), so sánh hạn trả cho chính xác
        [Required(ErrorMessage = "Hạn trả không được để trống")]
        [DataType(DataType.Date)]
        [BsonDateTimeOptions(DateOnly = true)]
        [Display(Name = "Hạn trả")]
        public DateTime DueDate { get; set; }

        // Các dòng mượn nằm ở collection riêng (LoanDetails), KHÔNG lưu trong document Loan.
        // Service/Controller tự nạp theo LoanId rồi gán vào đây.
        [BsonIgnore]
        public ICollection<LoanDetail> LoanDetails { get; set; } = new List<LoanDetail>();
    }
}
