using System.ComponentModel.DataAnnotations;
using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // 1 dòng trong phiếu mượn, ứng với 1 đầu sách (BookCopy) cụ thể đã được chọn khi mượn
    public class LoanDetail
    {
        [BsonId]
        public int LoanDetailId { get; set; }

        [Required]
        public int LoanId { get; set; }

        // Không có khóa ngoại thật; nạp thủ công khi cần
        [BsonIgnore]
        public Loan? Loan { get; set; }

        // Đầu sách cụ thể được chọn cho mã sách này khi mượn (chọn ở LoanService)
        [Required]
        public int BookCopyId { get; set; }

        [BsonIgnore]
        public BookCopy? BookCopy { get; set; }

        // Ngày trả thực tế; null nếu chưa trả (đang mượn/đã báo mất/báo hỏng)
        [DataType(DataType.Date)]
        [BsonDateTimeOptions(DateOnly = true)]
        [Display(Name = "Ngày trả")]
        public DateTime? ReturnDate { get; set; }

        [BsonRepresentation(BsonType.String)]
        [Display(Name = "Tình trạng")]
        public LoanDetailStatus Status { get; set; } = LoanDetailStatus.Borrowed;
    }
}
