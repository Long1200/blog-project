using System.ComponentModel.DataAnnotations;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // Một mã sách (Book) có thể ứng với nhiều đầu sách (BookCopy) khác nhau
    public class Book
    {
        // Mã sách là khóa chính tự nhiên, do thủ thư đặt (ví dụ: CT101) -> dùng luôn làm _id trong MongoDB
        [BsonId]
        [Required(ErrorMessage = "Mã sách không được để trống")]
        [StringLength(20, ErrorMessage = "Mã sách tối đa 20 ký tự")]
        [Display(Name = "Mã sách")]
        public string BookCode { get; set; } = string.Empty;

        [Required(ErrorMessage = "Tên sách không được để trống")]
        [StringLength(200, ErrorMessage = "Tên sách tối đa 200 ký tự")]
        [Display(Name = "Tên sách")]
        public string Title { get; set; } = string.Empty;

        [Required(ErrorMessage = "Tác giả không được để trống")]
        [StringLength(100, ErrorMessage = "Tên tác giả tối đa 100 ký tự")]
        [Display(Name = "Tác giả")]
        public string Author { get; set; } = string.Empty;

        [StringLength(50, ErrorMessage = "Thể loại tối đa 50 ký tự")]
        [Display(Name = "Thể loại")]
        public string? Genre { get; set; }

        // Giới hạn năm hợp lý để tránh nhập sai (không dùng năm âm hoặc quá xa thực tế)
        [Range(1000, 2100, ErrorMessage = "Năm xuất bản phải trong khoảng từ 1000 đến 2100")]
        [Display(Name = "Năm xuất bản")]
        public int PublicationYear { get; set; }

        [StringLength(150, ErrorMessage = "Tên nhà xuất bản tối đa 150 ký tự")]
        [Display(Name = "Nhà xuất bản")]
        public string? Publisher { get; set; }

        // Đường dẫn URL tới ảnh bìa sách (không lưu file nhị phân trong CSDL, chỉ lưu link).
        // Cho phép để trống; View sẽ hiển thị ảnh mặc định (icon sách) nếu không có ảnh.
        [StringLength(500, ErrorMessage = "Đường dẫn ảnh tối đa 500 ký tự")]
        [Display(Name = "Ảnh bìa (URL)")]
        [Url(ErrorMessage = "Đường dẫn ảnh không hợp lệ")]
        public string? ImageUrl { get; set; }

        // Giới thiệu / tóm tắt nội dung sách: admin nhập ở form thêm/sửa sách, độc giả xem ở trang chi tiết.
        // Cho phép để trống; View sẽ hiển thị thông báo "chưa có phần giới thiệu".
        [StringLength(3000, ErrorMessage = "Phần tóm tắt tối đa 3000 ký tự")]
        [Display(Name = "Tóm tắt nội dung")]
        [DataType(DataType.MultilineText)]
        public string? Summary { get; set; }

        // MongoDB không có Include()/JOIN: danh sách này KHÔNG được lưu trong document Book.
        // Controller tự truy vấn BookCopies theo BookCode rồi gán vào đây để View dùng như cũ.
        // Khởi tạo sẵn danh sách rỗng để tránh NullReferenceException khi chưa nạp.
        // Lượt mượn MẪU (dữ liệu demo cho bảng xếp hạng/sách hot). Số hiển thị = lượt mượn thật + số này.
        // BindNever: không cho form thêm/sửa sách ghi đè; muốn bỏ dữ liệu mẫu thì đặt lại về 0 trong SeedData.
        [Microsoft.AspNetCore.Mvc.ModelBinding.BindNever]
        public int SampleBorrowCount { get; set; }

        [BsonIgnore]
        public ICollection<BookCopy> BookCopies { get; set; } = new List<BookCopy>();
    }
}
