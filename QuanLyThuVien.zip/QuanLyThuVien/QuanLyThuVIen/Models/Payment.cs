using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    public enum PaymentType
    {
        CardRenewal,   // Gia hạn thẻ thư viện
        Compensation   // Bồi thường sách mất/hỏng
    }

    // Một lần thanh toán của độc giả. Hiện là thanh toán MÔ PHỎNG (chưa nối cổng thanh toán thật),
    // chỉ lưu lại để hiển thị lịch sử/biên lai.
    public class Payment
    {
        [BsonId]
        public int PaymentId { get; set; }

        public string UserId { get; set; } = string.Empty;
        public string CardNumber { get; set; } = string.Empty;

        [BsonRepresentation(BsonType.String)]
        public PaymentType Type { get; set; }

        // Số tiền (VND, không có phần lẻ nên dùng long)
        public long Amount { get; set; }

        public string Method { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;
    }
}
