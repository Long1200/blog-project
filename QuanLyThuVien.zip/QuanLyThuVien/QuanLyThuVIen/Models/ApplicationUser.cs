using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // Tài khoản người dùng, kế thừa IdentityUser để dùng luôn cơ chế đăng nhập/đăng ký/băm mật khẩu
    // và đăng nhập bằng Google/Facebook (external login) có sẵn của ASP.NET Core Identity.
    // Các trường thêm bên dưới là thông tin cá nhân hiển thị ở trang "Trang cá nhân".
    // [BsonIgnoreExtraElements]: bỏ qua trường lạ trong document để đọc không bị lỗi nếu sau này đổi cấu trúc.
    // Id (chuỗi GUID do IdentityUser tự sinh) được driver tự map thành _id theo quy ước tên "Id".
    [BsonIgnoreExtraElements]
    public class ApplicationUser : IdentityUser
    {
        [Required(ErrorMessage = "Họ tên không được để trống")]
        [StringLength(100, ErrorMessage = "Họ tên tối đa 100 ký tự")]
        [Display(Name = "Họ tên")]
        public string FullName { get; set; } = string.Empty;

        [DataType(DataType.Date)]
        [Display(Name = "Ngày sinh")]
        public DateTime? DateOfBirth { get; set; }

        [StringLength(200, ErrorMessage = "Địa chỉ tối đa 200 ký tự")]
        [Display(Name = "Địa chỉ")]
        public string? Address { get; set; }

        // URL ảnh đại diện (không lưu file nhị phân, chỉ lưu link) - để trống sẽ hiển thị icon mặc định
        [StringLength(500, ErrorMessage = "Đường dẫn ảnh tối đa 500 ký tự")]
        [Display(Name = "Ảnh đại diện (URL)")]
        public string? AvatarUrl { get; set; }

        // Quyền quản trị (vào được /admin). Chỉ được bật bởi AdminSeeder hoặc sửa trực tiếp trong MongoDB,
        // KHÔNG có form nào cho người dùng tự đặt, nên đăng ký tài khoản mới không thể thành admin.
        public bool IsAdmin { get; set; }

        // Số thẻ thư viện đã liên kết với tài khoản này (null = chưa liên kết).
        // Nhờ đó trang cá nhân biết sách mượn / bồi thường / gia hạn thẻ là của ai.
        public string? LibraryCardNumber { get; set; }

        // Ngày tạo tài khoản, dùng để hiển thị trên trang cá nhân
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        // Các tài khoản Google/Facebook đã liên kết. Nhúng thẳng vào document user (thay cho bảng
        // AspNetUserLogins của EF) vì mỗi user chỉ có vài liên kết và luôn được đọc cùng user.
        public List<ApplicationUserLogin> Logins { get; set; } = new();
    }

    // Một liên kết đăng nhập ngoài: (nhà cung cấp, khóa của user ở nhà cung cấp đó)
    public class ApplicationUserLogin
    {
        public string LoginProvider { get; set; } = string.Empty;
        public string ProviderKey { get; set; } = string.Empty;
        public string? ProviderDisplayName { get; set; }
    }
}
