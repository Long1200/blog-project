namespace QuanLyThuVIen.Models.ViewModels
{
    // 1 cuốn trong phiếu mượn tạm
    public class BorrowCartItem
    {
        public Book Book { get; set; } = null!;
        // Số bản còn cho mượn tại thời điểm xem (0 = đã hết, không thể xác nhận)
        public int AvailableCopies { get; set; }
    }

    public class BorrowCartViewModel
    {
        public LibraryCard? Card { get; set; }
        public List<BorrowCartItem> Items { get; set; } = new();
        public DateTime LoanDate { get; set; } = DateTime.Today;
        // Hạn trả = ngày mượn + 15 ngày (khớp LoanService)
        public DateTime DueDate => LoanDate.AddDays(15);
        public int MaxBooks { get; set; } = 3;

        // Lý do chưa thể mượn (chưa liên kết thẻ, thẻ hết hạn/khóa, còn phiếu chưa trả...)
        public List<string> Problems { get; set; } = new();

        public bool HasOutOfStock => Items.Any(i => i.AvailableCopies <= 0);
        public bool CanConfirm => Card != null && Problems.Count == 0 && Items.Count > 0 && !HasOutOfStock;
    }
}
