namespace QuanLyThuVIen.Models.ViewModels
{
    // Dữ liệu đánh giá/bình luận/thích của 1 cuốn sách, dùng ở trang Chi tiết sách
    public class BookFeedbackViewModel
    {
        public double AverageRating { get; set; }
        public int RatingCount { get; set; }
        public int LikeCount { get; set; }
        public int DislikeCount { get; set; }
        public List<BookReview> Reviews { get; set; } = new();

        public bool IsSignedIn { get; set; }
        public bool IsAdmin { get; set; }
        public string? CurrentUserId { get; set; }
        public ReactionType? MyReaction { get; set; }
        public BookReview? MyReview { get; set; }
    }
}
