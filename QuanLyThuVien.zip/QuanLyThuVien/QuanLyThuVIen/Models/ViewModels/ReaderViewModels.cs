namespace QuanLyThuVIen.Models.ViewModels
{
    // Mức phí (đặt ở 1 chỗ để dễ chỉnh). Số tiền chỉ là giá trị mẫu cho đồ án.
    public static class LibraryFees
    {
        public const long RenewCard = 50_000;
        public const int RenewMonths = 12;
        public const long Damaged = 50_000;
        public const long Lost = 150_000;

        public static readonly string[] PaymentMethods =
            { "Ví MoMo", "ZaloPay", "Chuyển khoản ngân hàng", "Thẻ ATM / Visa" };

        public static long ForReason(CompensationReason reason) =>
            reason == CompensationReason.Lost ? Lost : Damaged;

        public static string Vnd(long amount) =>
            amount.ToString("N0", System.Globalization.CultureInfo.GetCultureInfo("vi-VN")) + " ₫";
    }

    public class BorrowedItem
    {
        public string BookCode { get; set; } = string.Empty;
        public string Title { get; set; } = string.Empty;
        public string Author { get; set; } = string.Empty;
        public string? ImageUrl { get; set; }
        public string ControlNumber { get; set; } = string.Empty;
        public int LoanId { get; set; }
        public DateTime LoanDate { get; set; }
        public DateTime DueDate { get; set; }
        // Số ngày còn lại đến hạn trả (âm = đã quá hạn)
        public int DaysLeft { get; set; }
        public bool IsOverdue => DaysLeft < 0;
        public bool IsDueSoon => DaysLeft >= 0 && DaysLeft <= 3;
    }

    public class CompensationItem
    {
        public int CaseId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string ControlNumber { get; set; } = string.Empty;
        public CompensationReason Reason { get; set; }
        public DateTime CreatedDate { get; set; }
        public long Amount { get; set; }
    }

    // Toàn bộ dữ liệu độc giả cần xem, gom 1 lần để trang chủ và trang cá nhân dùng chung
    public class ReaderSummary
    {
        public LibraryCard? Card { get; set; }
        public List<BorrowedItem> Borrowed { get; set; } = new();
        public List<CompensationItem> Cases { get; set; } = new();
        public List<Payment> Payments { get; set; } = new();

        public bool CardExpired => Card != null && Card.ExpiryDate.Date < DateTime.Today;
        public long TotalCompensation => Cases.Sum(c => c.Amount);
        public int OverdueCount => Borrowed.Count(b => b.IsOverdue);
        public int DueSoonCount => Borrowed.Count(b => b.IsDueSoon);
    }

    public class MyLibraryViewModel
    {
        public ApplicationUser User { get; set; } = null!;
        public ReaderSummary Summary { get; set; } = new();
    }

    public class RenewCardViewModel
    {
        public LibraryCard Card { get; set; } = null!;
        public DateTime NewExpiry { get; set; }
        public long Fee { get; set; } = LibraryFees.RenewCard;
        public int Months { get; set; } = LibraryFees.RenewMonths;
        public bool HasUnresolvedCases { get; set; }
    }

    // 1 cuốn sách kèm số lượt mượn, dùng cho slide "Sách hot", bảng xếp hạng, "Sách mới nhập"
    public class BookStat
    {
        public Book Book { get; set; } = null!;
        // Tổng số lượt mượn từ trước đến nay (mỗi LoanDetail = 1 lượt)
        public int BorrowCount { get; set; }
        // Số lượt mượn trong 30 ngày gần đây (dùng để chọn sách hot)
        public int RecentCount { get; set; }
    }

    public class HomeViewModel
    {
        public int TotalBooks { get; set; }
        public int AvailableCopies { get; set; }
        public List<string> Genres { get; set; } = new();
        public List<Book> NewBooks { get; set; } = new();
        // Sách hot (slide show tự chuyển), tối đa 5 cuốn
        public List<BookStat> HotBooks { get; set; } = new();
        // Xếp hạng sách được mượn nhiều nhất (chỉ gồm sách đã có lượt mượn), tối đa 5 cuốn
        public List<BookStat> RankedBooks { get; set; } = new();
        // Sách mới nhập kho (có đầu sách được thêm gần đây nhất), tối đa 4 cuốn
        public List<BookStat> NewlyStocked { get; set; } = new();
        public Dictionary<string, int> AvailableByBook { get; set; } = new();
        public ReaderSummary? Reader { get; set; }
        public string? UserName { get; set; }
    }
}
