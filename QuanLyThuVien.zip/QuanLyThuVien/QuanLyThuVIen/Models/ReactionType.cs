namespace QuanLyThuVIen.Models
{
    // Thích / Không thích một cuốn sách
    public enum ReactionType
    {
        Like,
        Dislike
    }
}
