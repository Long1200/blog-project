using System.ComponentModel.DataAnnotations;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // Đánh giá sao + bình luận của 1 tài khoản cho 1 mã sách (mỗi người chỉ 1 đánh giá/sách, gửi lại sẽ cập nhật).
    // Cặp (BookCode, UserId) có unique index tạo trong MongoDbContext.EnsureIndexes.
    public class BookReview
    {
        [BsonId]
        public int ReviewId { get; set; }

        public string BookCode { get; set; } = string.Empty;

        public string UserId { get; set; } = string.Empty;

        // Tên hiển thị lưu sẵn trong đánh giá để khỏi phải truy vấn user khi liệt kê bình luận
        [StringLength(100)]
        public string UserName { get; set; } = string.Empty;

        [Range(1, 5, ErrorMessage = "Số sao phải từ 1 đến 5")]
        public int Rating { get; set; }

        [StringLength(1000, ErrorMessage = "Bình luận tối đa 1000 ký tự")]
        public string? Comment { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public DateTime? UpdatedAt { get; set; }
    }
}
