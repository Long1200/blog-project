using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;

namespace QuanLyThuVIen.Models
{
    // Mỗi tài khoản chỉ có tối đa 1 phản ứng (thích hoặc không thích) cho mỗi mã sách.
    // Cặp (BookCode, UserId) có unique index tạo trong MongoDbContext.EnsureIndexes.
    public class BookReaction
    {
        [BsonId]
        public int ReactionId { get; set; }

        public string BookCode { get; set; } = string.Empty;

        // Id của ApplicationUser (chuỗi GUID)
        public string UserId { get; set; } = string.Empty;

        [BsonRepresentation(BsonType.String)]
        public ReactionType Type { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
    }
}
