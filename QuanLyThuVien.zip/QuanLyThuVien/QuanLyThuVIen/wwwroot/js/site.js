﻿// Please see documentation at https://learn.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.

// Gắn data-label cho từng ô của mọi bảng .table dựa theo tiêu đề cột (<th>) tương ứng.
// CSS ở site.css dùng nhãn này để biến bảng thành danh sách thẻ trên điện thoại (< 768px).
// Bảng nào không muốn chuyển thẻ thì thêm class "table-keep" (bảng đó sẽ cuộn ngang).
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('table.table').forEach(function (table) {
        if (table.classList.contains('table-keep')) return;
        var headRow = table.querySelector('thead tr');
        if (!headRow) return;
        var labels = Array.prototype.map.call(headRow.children, function (th) {
            return th.textContent.trim();
        });
        table.querySelectorAll('tbody tr').forEach(function (tr) {
            var col = 0;
            Array.prototype.forEach.call(tr.children, function (td) {
                if (td.tagName !== 'TD') return;
                td.setAttribute('data-label', labels[col] || '');
                col += td.colSpan || 1;
            });
        });
        table.classList.add('table-cards');
    });
});


/* =========================================================
   HIỆU ỨNG GIAO DIỆN
   1) Mở sách: bấm vào sách -> cuốn sách bay ra giữa màn hình, bìa mở ra,
      các trang lật rồi phóng to và chuyển sang trang chi tiết.
   2) Hiện dần các thẻ khi cuộn tới.
   3) Nghiêng 3D khi rê chuột lên thẻ sách (chỉ máy có chuột).
   ========================================================= */
(function () {
    'use strict';

    var reduce = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var DETAIL_RE = /\/Catalog\/Details(\/|$)/i;
    var busy = false;
    var hiddenImg = null;

    function el(tag, cls) {
        var e = document.createElement(tag);
        if (cls) e.className = cls;
        return e;
    }

    function cleanup() {
        var root = document.querySelector('.bfx-root');
        if (root) root.remove();
        if (hiddenImg) { hiddenImg.style.visibility = ''; hiddenImg = null; }
        busy = false;
    }

    // Bấm nút Back của trình duyệt (trang được lấy lại từ bộ nhớ đệm) -> dọn lớp phủ cũ
    window.addEventListener('pageshow', function (e) {
        if (e.persisted) {
            cleanup();
            document.documentElement.classList.remove('book-arriving');
        }
    });

    // Trang chi tiết vừa được mở bằng hiệu ứng: gỡ lớp "cánh cửa" sau khi chạy xong
    if (document.documentElement.classList.contains('book-arriving')) {
        setTimeout(function () {
            document.documentElement.classList.remove('book-arriving');
        }, 1600);
    }

    function findCoverImg(a) {
        var scope = a.closest('.card, .hot-slide, .rank-row, tr, li') || a;
        return a.querySelector('img') || scope.querySelector('img');
    }

    function openBook(a, ev) {
        busy = true;
        var href = a.href;
        var img = findCoverImg(a);
        var vw = window.innerWidth, vh = window.innerHeight;

        // Vị trí xuất phát: đúng chỗ ảnh bìa đang nằm (nếu không có ảnh thì lấy điểm vừa bấm)
        var r = img ? img.getBoundingClientRect() : null;
        if (!r || r.width < 20 || r.height < 20) {
            var cx = ev.clientX || vw / 2, cy = ev.clientY || vh / 2;
            r = { left: cx - 35, top: cy - 50, width: 70, height: 100 };
            img = null;
        }
        var hasImg = img && img.complete && img.naturalWidth > 0;

        var ratio = Math.min(2, Math.max(0.8, r.height / r.width));
        var w = Math.min(vw * 0.44, 300, (vh * 0.6) / ratio);
        var h = w * ratio;

        // --- Dựng cuốn sách ---
        var root = el('div', 'bfx-root');
        var backdrop = el('div', 'bfx-backdrop');
        var wrap = el('div', 'bfx');
        wrap.style.width = w + 'px';
        wrap.style.height = h + 'px';
        var book = el('div', 'bfx-book');

        var pages = el('div', 'bfx-pages');
        var ink = el('div', 'bfx-ink');
        pages.appendChild(ink);

        var leaf2 = el('div', 'bfx-leaf'); leaf2.appendChild(el('div', 'bfx-ink'));
        var leaf1 = el('div', 'bfx-leaf'); leaf1.appendChild(el('div', 'bfx-ink'));

        var cover = el('div', 'bfx-cover');
        var front = el('div', 'bfx-front');
        if (hasImg) {
            var src = (img.currentSrc || img.src).replace(/"/g, '%22');
            front.style.backgroundImage = 'url("' + src + '")';
        } else {
            front.innerHTML = '<i class="bi bi-book"></i>';
        }
        var back = el('div', 'bfx-back');
        cover.appendChild(front);
        cover.appendChild(back);

        book.appendChild(pages);
        book.appendChild(leaf2);
        book.appendChild(leaf1);
        book.appendChild(cover);
        wrap.appendChild(book);
        root.appendChild(backdrop);
        root.appendChild(wrap);

        // Đặt cuốn sách đúng vị trí ảnh gốc TRƯỚC khi gắn vào trang để không bị nháy
        var s0 = r.width / w;
        var T0 = 'translate(' + r.left + 'px,' + r.top + 'px) scale(' + s0 + ')';
        var x1 = (vw - w) / 2, y1 = (vh - h) / 2;
        var T1 = 'translate(' + x1 + 'px,' + y1 + 'px) scale(1)';
        var T2 = 'translate(' + (x1 + w / 2) + 'px,' + y1 + 'px) scale(1)'; // gáy sách ở giữa màn hình khi mở
        var S = Math.max(vw / w, vh / h) * 1.25;
        var T3 = 'translate(' + (vw / 2 - S * w / 2) + 'px,' + (vh / 2 - S * h / 2) + 'px) scale(' + S + ')';
        wrap.style.transform = T0;

        document.body.appendChild(root);
        if (img) { img.style.visibility = 'hidden'; hiddenImg = img; }

        // --- Chuỗi chuyển động ---
        var easeOut = 'cubic-bezier(.22,.8,.24,1)';
        var aMove = wrap.animate([{ transform: T0 }, { transform: T1 }],
            { duration: 340, easing: easeOut, fill: 'forwards' });
        backdrop.animate([{ opacity: 0 }, { opacity: 1 }], { duration: 340, fill: 'forwards' });

        aMove.finished.then(function () {
            // Mở bìa + lật vài trang
            var dur = 700;
            var aOpen = wrap.animate([{ transform: T1 }, { transform: T2 }],
                { duration: dur, easing: 'cubic-bezier(.45,.05,.25,1)', fill: 'forwards' });
            cover.animate([{ transform: 'rotateY(0deg)' }, { transform: 'rotateY(-172deg)' }],
                { duration: dur, easing: 'cubic-bezier(.4,.1,.2,1)', fill: 'forwards' });
            [leaf1, leaf2].forEach(function (leaf, i) {
                leaf.animate([
                    { transform: 'rotateY(0deg)', opacity: 1, offset: 0 },
                    { transform: 'rotateY(-100deg)', opacity: 1, offset: 0.6 },
                    { transform: 'rotateY(-165deg)', opacity: 0, offset: 1 }
                ], { duration: 480, delay: 120 + i * 100, easing: 'ease-in-out', fill: 'forwards' });
            });
            return aOpen.finished;
        }).then(function () {
            // Phóng to trang sách cho phủ kín màn hình
            var dur = 420;
            var aZoom = wrap.animate([{ transform: T2 }, { transform: T3 }],
                { duration: dur, easing: 'cubic-bezier(.6,0,.9,.4)', fill: 'forwards' });
            cover.animate([{ opacity: 1 }, { opacity: 0 }], { duration: 250, fill: 'forwards' });
            ink.animate([{ opacity: 1 }, { opacity: 0 }], { duration: dur, fill: 'forwards' });
            return aZoom.finished;
        }).then(function () {
            try { sessionStorage.setItem('bookArrive', '1'); } catch (e) { }
            window.location.href = href;
            // Phòng khi chuyển trang thất bại (mất mạng...) thì gỡ lớp phủ, không để kẹt màn hình
            setTimeout(cleanup, 8000);
        }).catch(function () {
            cleanup();
            window.location.href = href;
        });
    }

    document.addEventListener('click', function (e) {
        if (e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
        var a = e.target.closest && e.target.closest('a[href]');
        if (!a || a.target === '_blank' || a.hasAttribute('download')) return;

        var url;
        try { url = new URL(a.href, window.location.href); } catch (err) { return; }
        if (url.origin !== window.location.origin || !DETAIL_RE.test(url.pathname)) return;
        if (url.pathname === window.location.pathname && url.search === window.location.search) return;
        if (reduce || !Element.prototype.animate) return; // để trình duyệt chuyển trang bình thường

        e.preventDefault();
        if (busy) return;
        openBook(a, e);
    });

    // ---------- Hiện dần khi cuộn tới ----------
    function initReveal() {
        var items = document.querySelectorAll('.book-tile, main .card, .rank-row');
        if (!items.length) return;
        if (reduce || !('IntersectionObserver' in window)) return;

        items.forEach(function (it) { it.classList.add('fx-reveal'); });
        var io = new IntersectionObserver(function (entries) {
            var i = 0;
            entries.forEach(function (en) {
                if (!en.isIntersecting) return;
                en.target.style.setProperty('--fx-i', Math.min(i++, 10));
                en.target.classList.add('fx-in');
                io.unobserve(en.target);
            });
        }, { threshold: 0.08 });
        items.forEach(function (it) { io.observe(it); });
    }

    // ---------- Nghiêng 3D khi rê chuột lên sách ----------
    function initTilt() {
        if (reduce || !window.matchMedia('(hover: hover) and (pointer: fine)').matches) return;
        var cur = null;
        function reset() {
            if (!cur) return;
            cur.classList.remove('fx-tilt');
            cur.style.removeProperty('--rx');
            cur.style.removeProperty('--ry');
            cur = null;
        }
        document.addEventListener('pointermove', function (e) {
            var t = e.target.closest && e.target.closest('.book-tile');
            if (cur && cur !== t) reset();
            if (!t) return;
            cur = t;
            var r = t.getBoundingClientRect();
            var px = (e.clientX - r.left) / r.width - 0.5;
            var py = (e.clientY - r.top) / r.height - 0.5;
            t.style.setProperty('--ry', (px * 12).toFixed(2) + 'deg');
            t.style.setProperty('--rx', (-py * 12).toFixed(2) + 'deg');
            t.classList.add('fx-tilt');
        }, { passive: true });
        document.addEventListener('mouseleave', reset);
    }

    document.addEventListener('DOMContentLoaded', function () {
        initReveal();
        initTilt();
    });
})();
