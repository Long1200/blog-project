# Checklist kiểm thử toàn bộ luồng – Quản lý thư viện (MongoDB)

## 0. Chuẩn bị
- [ ] Atlas: có cluster, database user, **Network Access** cho IP máy đang chạy.
- [ ] Đặt chuỗi kết nối (thay `<db_username>`, `<db_password>`; mật khẩu có ký tự đặc biệt phải URL-encode):
  `cd QuanLyThuVIen` rồi `dotnet user-secrets set "MongoDb:ConnectionString" "mongodb+srv://<db_username>:<db_password>@longnguyen.2zp8jrp.mongodb.net/"`
- [ ] `dotnet restore` → `dotnet build` : **0 lỗi**, không còn cảnh báo về EntityFramework / SqlClient.
- [ ] `dotnet run` : app khởi động không ném lỗi "Chưa cấu hình MongoDb:ConnectionString".
- [ ] Atlas → Browse Collections: có `Books` (15 cuốn mẫu), `BookCopies`, `Counters`; tab Indexes có `UX_BookCopies_BookCode_ControlNumber`, `UX_Users_NormalizedUserName`...
- [ ] Mở lại app lần 2: dữ liệu mẫu **không bị nhân đôi**.
- [ ] Thư mục dự án không còn `Migrations/` và `Infrastructure/DbRetry.cs`.

## 1. Tài khoản
- [ ] Đăng ký email mới + mật khẩu hợp lệ (≥6 ký tự, có chữ và số) → thành công, tự đăng nhập.
- [ ] Đăng ký trùng email → báo lỗi, không tạo thêm user trong collection `Users`.
- [ ] Mật khẩu thiếu số / dưới 6 ký tự → báo lỗi tiếng Việt.
- [ ] Đăng xuất → đăng nhập lại đúng mật khẩu OK; sai mật khẩu báo lỗi; sai 5 lần → khóa 5 phút.
- [ ] Trang cá nhân (Profile) hiển thị đúng; sửa hồ sơ lưu được và tải lại vẫn còn.
- [ ] Đổi mật khẩu: sai mật khẩu cũ báo lỗi; đúng thì đăng nhập lại bằng mật khẩu mới được.
- [ ] Truy cập `/Account/Profile` khi chưa đăng nhập → chuyển về `/Account/Login`.
- [ ] (Nếu đã cấu hình OAuth) Đăng nhập Google/Facebook → tạo/nhận đúng user.

## 2. Đầu sách (Book)
- [ ] Danh sách phân trang đúng; tìm kiếm không phân biệt hoa thường; tìm chuỗi có ký tự đặc biệt (`.`, `(`) không báo lỗi.
- [ ] Thêm sách mới: thiếu trường bắt buộc báo lỗi; trùng `BookCode` bị chặn.
- [ ] Chi tiết sách hiển thị danh sách bản sao (BookCopy) và ảnh bìa.
- [ ] Sửa sách lưu đúng; xóa sách **còn bản sao** → bị chặn với thông báo; xóa sách không còn bản sao → thành công.

## 3. Bản sao sách (BookCopy)
- [ ] Thêm bản sao: `Id` tự tăng (collection `Counters`), cặp (BookCode, ControlNumber) trùng bị chặn (kiểm tra cả lớp unique index).
- [ ] Đổi trạng thái Available / Lost / Damaged lưu đúng; bản sao đang Borrowed không đổi tùy tiện.

## 4. Thẻ thư viện (LibraryCard)
- [ ] Tạo thẻ mới (mã thẻ duy nhất, ngày hết hạn); trùng mã bị chặn.
- [ ] Tìm kiếm / xem chi tiết / sửa thẻ.
- [ ] Khóa thẻ (Active → Inactive) và mở khóa.
- [ ] Thẻ còn case bồi thường chưa xử lý → **không** mở khóa thủ công được.

## 5. Mượn sách (Loan)
- [ ] Mượn 1 mã sách với thẻ Active còn hạn → tạo phiếu; bản sao chuyển Borrowed; `LoanId`, `LoanDetailId` tăng đúng.
- [ ] Mượn 3 mã → OK; chọn 4 mã → "tối đa 3 mã"; chọn trùng mã → báo lỗi; không chọn mã nào → báo lỗi.
- [ ] Thẻ Inactive → chặn; thẻ hết hạn → chặn; mã sách không tồn tại → chặn.
- [ ] Thẻ đang có phiếu chưa trả hết → chặn mượn tiếp.
- [ ] Hết bản sao Available của 1 mã → báo lỗi và **không** tạo phiếu dở dang (collection `Loans`/`LoanDetails` không có dữ liệu mới, các bản sao khác không bị đổi sang Borrowed – kiểm tra transaction rollback).
- [ ] Danh sách phiếu mượn và tìm kiếm theo số thẻ / mã phiếu / mã sách.
- [ ] Đang mượn (ActiveLoans) theo số thẻ hiển thị đúng.

## 6. Trả sách và báo mất/hỏng
- [ ] Trả từng dòng: dòng chuyển Returned, bản sao về Available; trả hết thì thẻ được mượn tiếp.
- [ ] Trả dòng đã trả rồi → bị chặn.
- [ ] Báo mất → dòng Lost, bản sao Lost, tạo CompensationCase, thẻ chuyển Inactive.
- [ ] Báo hỏng → tương tự với Damaged.
- [ ] Báo mất/hỏng cho dòng không ở trạng thái đang mượn → bị chặn.

## 7. Bồi thường (Compensation)
- [ ] Tra cứu theo số thẻ hiển thị đúng các case.
- [ ] Xử lý bồi thường → case IsResolved = true; **hết case chưa xử lý thì thẻ tự mở lại Active**.
- [ ] Xử lý case đã bồi thường rồi → báo "đã được bồi thường trước đó".

## 8. Báo cáo và trang chủ
- [ ] Trang chủ (Dashboard) số liệu khớp dữ liệu thật trong Atlas.
- [ ] Báo cáo theo năm / từ khóa chạy đúng, không lỗi khi năm không có dữ liệu.

## 9. Đồng thời và độ bền (chỉ cần thử khi có thời gian)
- [ ] Mở 2 tab, cùng lúc tạo phiếu mượn cho **cùng một thẻ** → chỉ 1 phiếu được tạo (cơ chế AcquireLock).
- [ ] Mở 2 tab, cùng lúc mượn **bản sao cuối cùng** của một mã sách → chỉ 1 bên thành công.
- [ ] Tắt mạng / sai chuỗi kết nối → lỗi rõ ràng, không treo vô hạn.

## 10. Bảo mật khi nộp bài
- [ ] `appsettings.json` có `ConnectionString` **rỗng** (không lộ mật khẩu Atlas).
- [ ] Không có file `.user-secrets` hay chuỗi `mongodb+srv://...:mật_khẩu@` trong mã nguồn nộp.

## 11. Giao diện độc giả (Trang chủ, Trang cá nhân, thanh toán)
- [ ] Trang chủ `/` hiển thị ô tìm sách, thể loại, 8 sách mới; tìm kiếm chuyển sang trang Sách. Trang số liệu cũ nằm ở `/Home/Dashboard` (menu "Tổng quan").
- [ ] Chưa đăng nhập vào `/MyLibrary` → chuyển về trang đăng nhập.
- [ ] Trang cá nhân: nhập sai số thẻ/họ tên → báo lỗi; đúng → liên kết thành công; thẻ đã gắn tài khoản khác → bị chặn.
- [ ] Sách đang mượn: hiện đúng tên sách, ngày mượn, hạn trả, số ngày còn lại; quá hạn hiện badge đỏ; còn ≤ 3 ngày hiện badge vàng.
- [ ] Gia hạn thẻ: hạn mới = hạn cũ + 12 tháng (thẻ đã hết hạn thì tính từ hôm nay); có dòng mới trong `Payments`; thẻ hết hạn và không còn bồi thường → mở lại Active.
- [ ] Thanh toán bồi thường: chỉ thấy khoản của thẻ mình; thanh toán xong case IsResolved = true, thẻ tự mở lại khi hết khoản chưa trả; tổng tiền cập nhật khi bỏ tick.
- [ ] Bấm thanh toán 2 lần / 2 tab → chỉ ghi nhận 1 lần.

## 12. Tách giao diện Người dùng / Admin
- [ ] Trang người dùng: `https://localhost:<port>/` (menu: Trang chủ, Sách, Trang cá nhân). Không còn menu Thẻ thư viện / Mượn sách / Báo cáo.
- [ ] Trang admin: `https://localhost:<port>/admin` → chưa đăng nhập tự chuyển về `/admin/login`; giao diện tông màu cam, có nhãn ADMIN.
- [ ] Đăng nhập admin bằng `admin@thuvien.local` / mật khẩu cấu hình (Development: `admin123`) → vào Tổng quan; menu có Sách, Thẻ thư viện, Mượn sách, Báo cáo.
- [ ] Đăng nhập bằng tài khoản độc giả ở `/admin/login` → báo "Email hoặc mật khẩu không đúng".
- [ ] Đang đăng nhập bằng tài khoản độc giả, gõ thẳng `/admin/Book` → bị chuyển về `/admin/login` kèm cảnh báo không có quyền.
- [ ] Đăng ký tài khoản mới ở trang người dùng → không vào được `/admin` (IsAdmin mặc định false).
- [ ] Mọi chức năng quản lý cũ (thêm/sửa/xóa sách, thẻ, mượn/trả, bồi thường, báo cáo) vẫn chạy bình thường dưới `/admin/...`.
