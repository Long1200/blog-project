# DANH SÁCH 25 GITHUB ISSUES – DỰ ÁN QUẢN LÝ THƯ VIỆN

> **Hướng dẫn cấu trúc GitHub:**
> - **4 Milestones:** `Sprint 1` (15/09/2026), `Sprint 2` (21/09/2026), `Sprint 3` (25/09/2026), `Sprint 4` (01/10/2026).
> - **25 Issues:** Mỗi User Story là 1 GitHub Issue; các Sub-task được tích hợp thành **GitHub Tasklist (`- [ ]` / `- [x]`)** ngay bên trong phần mô tả Issue (chuẩn GitHub Issues & GitHub Projects).

---
## 1. `[US-12] Quản lý danh mục thể loại và nhà xuất bản`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 3` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn quản lý danh mục thể loại và nhà xuất bản để danh mục được chuẩn hóa, thống nhất mỗi khi nhập sách.
• Ghi chú kỹ thuật: Hoàn thành trước story 11 vì sách cần có thể loại, NXB để gán

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế bảng Thể loại & Nhà xuất bản và dữ liệu mẫu` (@MinhNgo - 1.0 pts)
- [x] `Xây dựng CRUD Quản lý danh mục Thể loại và Nhà xuất bản` (@MinhNgo - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `3`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-10 00:00:00` → `2026-09-11 00:00:00`
```

---
## 2. `[US-25] Quản lý tài khoản người dùng và phân quyền (thủ thư, sinh viên)`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là quản trị hệ thống, tôi muốn quản lý tài khoản người dùng và phân quyền (thủ thư, sinh viên) để kiểm soát được từng người dùng chức năng nào trong hệ thống.
• Ghi chú kỹ thuật: Tạo tài khoản và phân quyền trước để các story đăng nhập chạy được

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế CSDL Người dùng & Phân quyền (Admin, Thủ thư, Sinh viên)` (@BangBach - 2.0 pts)
- [x] `Xây dựng chức năng Quản lý tài khoản & gán quyền người dùng` (@BangBach - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-10 00:00:00` → `2026-09-11 00:00:00`
```

---
## 3. `[US-11] Thêm, sửa, xóa thông tin sách (mã sách, tên, tác giả, thể loại, năm xuất bản, nhà xuất bản)`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn thêm, sửa, xóa thông tin sách (mã sách, tên, tác giả, thể loại, năm xuất bản, nhà xuất bản) để duy trì dữ liệu sách đầy đủ, chính xác để phục vụ việc mượn trả.
• Ghi chú kỹ thuật: Cần có danh mục từ story 12

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế bảng Sách liên kết khóa ngoại Thể loại & Nhà xuất bản` (@MinhNgo - 2.0 pts)
- [x] `Xây dựng chức năng Thêm, sửa, xóa, kiểm tra trùng mã sách` (@MinhNgo - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-11 00:00:00` → `2026-09-14 00:00:00`
```

---
## 4. `[US-01] Đăng nhập vào hệ thống bằng tài khoản cá nhân`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 2` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là người dùng hệ thống (sinh viên, thủ thư, quản trị), tôi muốn đăng nhập vào hệ thống bằng tài khoản cá nhân để sử dụng hệ thống với đúng phân quyền được cấp.
• Ghi chú kỹ thuật: Phụ thuộc story 25 (đã có tài khoản)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng giao diện và xử lý xác thực đăng nhập tài khoản` (@BangBach - 1.0 pts)
- [x] `Phân luồng điều hướng giao diện theo vai trò (Admin / Thủ thư / Sinh viên)` (@BangBach - 1.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `2`
- **Priority:** `High`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-11 00:00:00` → `2026-09-14 00:00:00`
```

---
## 5. `[US-13] Quản lý các đầu sách của mỗi mã sách (số kiểm soát 001, 002,…, tình trạng, ghi chú)`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn quản lý các đầu sách của mỗi mã sách (số kiểm soát 001, 002,…, tình trạng, ghi chú) để phân biệt và theo dõi riêng từng cuốn thuộc cùng một mã sách.
• Ghi chú kỹ thuật: Cần story 11 (đã có thông tin sách)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế bảng Đầu sách (số kiểm soát 001, 002..., tình trạng, ghi chú)` (@MinhNgo - 2.0 pts)
- [x] `Xây dựng chức năng Quản lý đầu sách theo mã sách & kiểm tra trùng số kiểm soát` (@MinhNgo - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-14 00:00:00` → `2026-09-15 00:00:00`
```

---
## 6. `[US-14] Cấp thẻ thư viện cho sinh viên (số thẻ, họ tên, ngày hết hạn, tình trạng sử dụng)`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 3` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn cấp thẻ thư viện cho sinh viên (số thẻ, họ tên, ngày hết hạn, tình trạng sử dụng) để sinh viên có đủ điều kiện để mượn sách.
• Ghi chú kỹ thuật: Độc lập với nhóm sách, làm song song được

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế bảng Thẻ thư viện và giao diện cấp thẻ cho sinh viên` (@BangBach - 1.5 pts)
- [x] `Xử lý lưu thông tin cấp thẻ (số thẻ, họ tên, ngày hết hạn, trạng thái)` (@BangBach - 1.5 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `3`
- **Priority:** `High`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-14 00:00:00` → `2026-09-15 00:00:00`
```

---
## 7. `[US-05] Đăng xuất khỏi hệ thống`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: high, points: 1` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là người dùng hệ thống (sinh viên, thủ thư, quản trị), tôi muốn đăng xuất khỏi hệ thống để chấm dứt phiên làm việc, giữ an toàn cho tài khoản.
• Ghi chú kỹ thuật: Làm sau story 1 (đã có đăng nhập)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng chức năng Đăng xuất và hủy phiên đăng nhập (Session/Token)` (@MinhNgo - 1.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `1`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-15 00:00:00` → `2026-09-15 00:00:00`
```

---
## 8. `[US-15] Cập nhật thông tin và gia hạn thẻ thư viện`
- **Milestone:** `Sprint 1` | **Labels:** `user-story, priority: medium, points: 3` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn cập nhật thông tin và gia hạn thẻ thư viện để thẻ đã hết hạn vẫn có thể tiếp tục sử dụng.
• Ghi chú kỹ thuật: Làm sau story 14 (đã có thẻ)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng chức năng Cập nhật thông tin và gia hạn ngày hết hạn thẻ` (@BangBach - 2.0 pts)
- [x] `Kiểm thử nghiệp vụ gia hạn thẻ thư viện` (@AnPham - 1.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E1`
- **Sprint:** `Sprint 1`
- **Story Points:** `3`
- **Priority:** `Medium`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-15 00:00:00` → `2026-09-15 00:00:00`
```

---
## 9. `[US-06] Tra cứu sách theo tên, tác giả, thể loại, nhà xuất bản hoặc năm xuất bản`
- **Milestone:** `Sprint 2` | **Labels:** `user-story, priority: medium, points: 3` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là sinh viên, tôi muốn tra cứu sách theo tên, tác giả, thể loại, nhà xuất bản hoặc năm xuất bản để tìm ra cuốn sách mình cần mượn một cách nhanh chóng.
• Ghi chú kỹ thuật: Cần dữ liệu sách từ story 11, 13 (Sprint 1)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng bộ lọc và tìm kiếm sách đa tiêu chí (tên, tác giả, thể loại, NXB, năm)` (@MinhNgo - 2.0 pts)
- [x] `Thiết kế giao diện danh sách kết quả tra cứu sách cho sinh viên` (@MinhNgo - 1.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E2`
- **Sprint:** `Sprint 2`
- **Story Points:** `3`
- **Priority:** `Medium`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-16 00:00:00` → `2026-09-17 00:00:00`
```

---
## 10. `[US-17] Kiểm tra điều kiện được mượn (thẻ hợp lệ, tối đa 3 mã sách mỗi lần, thẻ không đang mượn sách khác)`
- **Milestone:** `Sprint 2` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn kiểm tra điều kiện được mượn (thẻ hợp lệ, tối đa 3 mã sách mỗi lần, thẻ không đang mượn sách khác) để bảo đảm việc mượn tuân thủ quy định của thư viện.
• Ghi chú kỹ thuật: Cần story 13, 14 (Sprint 1)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Cài đặt nghiệp vụ kiểm tra thẻ hợp lệ, chưa hết hạn và không có sách chưa trả` (@BangBach - 3.0 pts)
- [x] `Kiểm tra giới hạn tối đa 3 mã sách mỗi lần mượn và đầu sách ở trạng thái 'Còn'` (@BangBach - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E2`
- **Sprint:** `Sprint 2`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-16 00:00:00` → `2026-09-17 00:00:00`
```

---
## 11. `[US-07] Xem chi tiết sách kèm danh sách đầu sách (số kiểm soát, tình trạng còn/cho mượn/mất/hỏng, ghi chú)`
- **Milestone:** `Sprint 2` | **Labels:** `user-story, priority: medium, points: 2` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là sinh viên, tôi muốn xem chi tiết sách kèm danh sách đầu sách (số kiểm soát, tình trạng còn/cho mượn/mất/hỏng, ghi chú) để biết cuốn nào đang còn trong thư viện để đến mượn.
• Ghi chú kỹ thuật: Cần story 13 để hiển thị tình trạng đầu sách

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng màn hình Chi tiết sách kèm danh sách đầu sách và trạng thái từng cuốn` (@MinhNgo - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E2`
- **Sprint:** `Sprint 2`
- **Story Points:** `2`
- **Priority:** `Medium`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-17 00:00:00` → `2026-09-18 00:00:00`
```

---
## 12. `[US-18] Tạo phiếu mượn sách (tối đa 3 mã sách, thời hạn trả tối đa 15 ngày)`
- **Milestone:** `Sprint 2` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn tạo phiếu mượn sách (tối đa 3 mã sách, thời hạn trả tối đa 15 ngày) để ghi nhận việc mượn của sinh viên và chuyển tình trạng đầu sách sang 'cho mượn'.
• Ghi chú kỹ thuật: Làm sau story 17 (kiểm tra điều kiện)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế bảng Phiếu mượn & Chi tiết phiếu mượn (hạn trả tối đa 15 ngày)` (@BangBach - 2.0 pts)
- [x] `Xây dựng chức năng Tạo phiếu mượn & tự động cập nhật đầu sách sang 'Cho mượn'` (@BangBach - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E2`
- **Sprint:** `Sprint 2`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-17 00:00:00` → `2026-09-18 00:00:00`
```

---
## 13. `[US-19] Nhận trả sách (cập nhật tình trạng đầu sách, đóng phiếu mượn)`
- **Milestone:** `Sprint 2` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn nhận trả sách (cập nhật tình trạng đầu sách, đóng phiếu mượn) để đầu sách trở về trạng thái 'còn' và sinh viên được phép mượn tiếp.
• Ghi chú kỹ thuật: Làm sau story 18 (có phiếu mượn mới nhận trả được)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng chức năng Nhận trả sách, đóng phiếu mượn & chuyển đầu sách về 'Còn'` (@MinhNgo - 3.0 pts)
- [x] `Kiểm thử luồng mượn – trả sách khép kín` (@AnPham - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E2`
- **Sprint:** `Sprint 2`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-18 00:00:00` → `2026-09-21 00:00:00`
```

---
## 14. `[US-20] Tìm phiếu mượn theo số thẻ, sinh viên hoặc đầu sách`
- **Milestone:** `Sprint 2` | **Labels:** `user-story, priority: medium, points: 3` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn tìm phiếu mượn theo số thẻ, sinh viên hoặc đầu sách để biết được ai đang mượn cuốn sách nào.
• Ghi chú kỹ thuật: Cần story 18 (dữ liệu phiếu mượn)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng chức năng Tìm kiếm phiếu mượn theo số thẻ, sinh viên hoặc đầu sách` (@BangBach - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E2`
- **Sprint:** `Sprint 2`
- **Story Points:** `3`
- **Priority:** `Medium`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-21 00:00:00` → `2026-09-21 00:00:00`
```

---
## 15. `[US-16] Khóa hoặc mở khóa thẻ thư viện (chuyển giữa sử dụng được / không sử dụng được)`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: high, points: 3` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn khóa hoặc mở khóa thẻ thư viện (chuyển giữa sử dụng được / không sử dụng được) để kiểm soát hiệu lực của thẻ khi sinh viên làm mất, làm hỏng sách hoặc sau khi đã bồi thường.
• Ghi chú kỹ thuật: Làm trước story 22 (cần khóa thẻ khi sách mất/hỏng)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng chức năng Khóa / Mở khóa trạng thái sử dụng của thẻ thư viện` (@MinhNgo - 2.0 pts)
- [x] `Ghi nhận lý do khóa/mở khóa và kiểm tra ràng buộc mượn sách` (@MinhNgo - 1.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `3`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-22 00:00:00` → `2026-09-23 00:00:00`
```

---
## 16. `[US-08] Xem thông tin thẻ thư viện của mình (số thẻ, ngày hết hạn, tình trạng sử dụng được/không)`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: medium, points: 2` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là sinh viên, tôi muốn xem thông tin thẻ thư viện của mình (số thẻ, ngày hết hạn, tình trạng sử dụng được/không) để kiểm tra thẻ còn hiệu lực hay không trước khi đi mượn sách.
• Ghi chú kỹ thuật: Cần story 14 (đã có thẻ thư viện)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng màn hình Xem thông tin và tình trạng thẻ thư viện cá nhân của sinh viên` (@BangBach - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `2`
- **Priority:** `Medium`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-22 00:00:00` → `2026-09-22 00:00:00`
```

---
## 17. `[US-22] Ghi nhận sách bị mất hoặc hỏng (cập nhật tình trạng đầu sách, tạm khóa thẻ)`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn ghi nhận sách bị mất hoặc hỏng (cập nhật tình trạng đầu sách, tạm khóa thẻ) để phản ánh đúng thực trạng của sách và áp dụng quy định xử lý.
• Ghi chú kỹ thuật: Cần story 16 (khóa thẻ)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng chức năng Ghi nhận sách mất/hỏng, cập nhật trạng thái đầu sách` (@MinhNgo - 3.0 pts)
- [x] `Tự động khóa thẻ thư viện sinh viên khi ghi nhận mất/hỏng sách` (@MinhNgo - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-23 00:00:00` → `2026-09-24 00:00:00`
```

---
## 18. `[US-09] Xem các sách đang mượn cùng hạn trả (tối đa 15 ngày)`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: medium, points: 3` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là sinh viên, tôi muốn xem các sách đang mượn cùng hạn trả (tối đa 15 ngày) để chủ động trả sách đúng thời hạn.
• Ghi chú kỹ thuật: Cần story 18 (có phiếu mượn)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng màn hình Danh sách sách sinh viên đang mượn và ngày hết hạn trả` (@BangBach - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `3`
- **Priority:** `Medium`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-23 00:00:00` → `2026-09-23 00:00:00`
```

---
## 19. `[US-10] Xem lại lịch sử mượn – trả sách của bản thân`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: low, points: 2` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là sinh viên, tôi muốn xem lại lịch sử mượn – trả sách của bản thân để nắm được những sách mình đã mượn trong quá khứ.
• Ghi chú kỹ thuật: Cần story 19 (dữ liệu trả sách)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng màn hình Lịch sử mượn – trả sách của sinh viên` (@BangBach - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `2`
- **Priority:** `Low`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-24 00:00:00` → `2026-09-24 00:00:00`
```

---
## 20. `[US-23] Quản lý việc bồi thường (bồi thường xong thì thẻ của sinh viên được sử dụng lại)`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: high, points: 5` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn quản lý việc bồi thường (bồi thường xong thì thẻ của sinh viên được sử dụng lại) để sinh viên lấy lại quyền mượn sách sau khi đã bồi thường.
• Ghi chú kỹ thuật: Làm sau story 22 (đã ghi nhận mất/hỏng)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế phiếu/biên nhận bồi thường sách mất/hỏng` (@BangBach - 2.0 pts)
- [x] `Xây dựng chức năng Xác nhận bồi thường và tự động mở khóa lại thẻ sinh viên` (@BangBach - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `5`
- **Priority:** `High`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-24 00:00:00` → `2026-09-25 00:00:00`
```

---
## 21. `[US-21] Theo dõi các sách mượn quá hạn 15 ngày`
- **Milestone:** `Sprint 3` | **Labels:** `user-story, priority: low, points: 3` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn theo dõi các sách mượn quá hạn 15 ngày để nhắc sinh viên trả sách và quản lý được những sách chưa hoàn trả.
• Ghi chú kỹ thuật: Cần story 18 (dữ liệu phiếu mượn)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng danh sách theo dõi & cảnh báo các phiếu mượn quá hạn 15 ngày` (@MinhNgo - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E3`
- **Sprint:** `Sprint 3`
- **Story Points:** `3`
- **Priority:** `Low`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-25 00:00:00` → `2026-09-25 00:00:00`
```

---
## 22. `[US-02] Đăng nhập thông qua tài khoản Gmail`
- **Milestone:** `Sprint 4` | **Labels:** `user-story, priority: medium, points: 3` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là người dùng hệ thống (sinh viên, thủ thư, quản trị), tôi muốn đăng nhập thông qua tài khoản gmail để vào hệ thống nhanh chóng, không phải nhớ thêm một mật khẩu nữa.
• Ghi chú kỹ thuật: Cần story 1 (đăng nhập tài khoản)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Tích hợp cấu hình Google OAuth2 đăng nhập bằng tài khoản Gmail` (@MinhNgo - 2.0 pts)
- [x] `Liên kết tài khoản Gmail với hồ sơ người dùng trong hệ thống` (@MinhNgo - 1.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E4`
- **Sprint:** `Sprint 4`
- **Story Points:** `3`
- **Priority:** `Medium`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-28 00:00:00` → `2026-09-28 00:00:00`
```

---
## 23. `[US-03] Đăng ký dữ liệu khuôn mặt cho tài khoản`
- **Milestone:** `Sprint 4` | **Labels:** `user-story, priority: low, points: 5` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là người dùng hệ thống (sinh viên, thủ thư, quản trị), tôi muốn đăng ký dữ liệu khuôn mặt cho tài khoản để hệ thống lưu được dữ liệu khuôn mặt để nhận diện lúc đăng nhập.
• Ghi chú kỹ thuật: Cần story 1; thuộc phần mở rộng

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Thiết kế lưu trữ đặc trưng khuôn mặt (Face Embedding) gắn với tài khoản` (@BangBach - 2.0 pts)
- [x] `Xây dựng giao diện camera thu thập & đăng ký dữ liệu khuôn mặt` (@BangBach - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E4`
- **Sprint:** `Sprint 4`
- **Story Points:** `5`
- **Priority:** `Low`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-28 00:00:00` → `2026-09-29 00:00:00`
```

---
## 24. `[US-24] Lập báo cáo hằng năm về sách bị mất / hỏng phục vụ thanh lý`
- **Milestone:** `Sprint 4` | **Labels:** `user-story, priority: medium, points: 5` | **Assignee:** `BangBach`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là thủ thư, tôi muốn lập báo cáo hằng năm về sách bị mất / hỏng phục vụ thanh lý để thư viện có số liệu làm căn cứ để thanh lý sách.
• Ghi chú kỹ thuật: Cần story 22; lấy dữ liệu sách mất/hỏng

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng truy vấn thống kê sách mất/hỏng theo năm phục vụ thanh lý` (@BangBach - 3.0 pts)
- [x] `Xây dựng giao diện xem và xuất báo cáo thanh lý hằng năm` (@BangBach - 2.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E4`
- **Sprint:** `Sprint 4`
- **Story Points:** `5`
- **Priority:** `Medium`
- **Assignee:** `BangBach`
- **Thời gian dự kiến:** `2026-09-29 00:00:00` → `2026-09-30 00:00:00`
```

---
## 25. `[US-04] Đăng nhập bằng nhận diện khuôn mặt`
- **Milestone:** `Sprint 4` | **Labels:** `user-story, priority: low, points: 8` | **Assignee:** `MinhNgo`

```markdown
### 📋 Mô tả User Story
• User Story: Với vai trò là người dùng hệ thống (sinh viên, thủ thư, quản trị), tôi muốn đăng nhập bằng nhận diện khuôn mặt để đăng nhập thuận tiện và nhanh gọn mà không cần nhập mật khẩu.
• Ghi chú kỹ thuật: Làm sau story 3 (đã có dữ liệu khuôn mặt)

### ✅ Danh sách công việc (Sub-tasks)
- [x] `Xây dựng luồng quét camera và so khớp khuôn mặt khi đăng nhập` (@MinhNgo - 5.0 pts)
- [x] `Tích hợp cấp phiên đăng nhập & kiểm thử độ chính xác nhận diện khuôn mặt` (@MinhNgo - 3.0 pts)

### 📊 Thông tin Scrum
- **Epic:** `LIB-E4`
- **Sprint:** `Sprint 4`
- **Story Points:** `8`
- **Priority:** `Low`
- **Assignee:** `MinhNgo`
- **Thời gian dự kiến:** `2026-09-29 00:00:00` → `2026-10-01 00:00:00`
```
