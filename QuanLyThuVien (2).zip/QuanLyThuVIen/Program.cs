using Microsoft.AspNetCore.Authentication.Facebook;
using Microsoft.AspNetCore.Authentication.Google;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using QuanLyThuVIen.Models;
using QuanLyThuVIen.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Đăng ký LibraryDbContext, dùng SQL Server với connection string trong appsettings.json
// ConfigureWarnings bỏ qua PendingModelChangesWarning: dự án này chỉnh sửa Model nhiều lần
// nhưng các bảng (kể cả bảng Identity: AspNetRoles, AspNetUsers...) đã tồn tại sẵn và đúng
// cấu trúc trong DB rồi, nên không cần EF chặn Migrate() lại để bắt tạo migration mới mỗi lần.
builder.Services.AddDbContext<LibraryDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"))
           .ConfigureWarnings(w => w.Ignore(RelationalEventId.PendingModelChangesWarning)));

// ---------- ASP.NET Core Identity: đăng ký / đăng nhập / trang cá nhân ----------
// RequireDigit + RequireLowercase (không RequireUppercase, không RequireNonAlphanumeric):
// bắt buộc mật khẩu có cả chữ và số, không bắt buộc ký tự đặc biệt/hoa để người dùng dễ đặt.
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
{
    options.Password.RequireDigit = true;
    options.Password.RequireLowercase = true;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.Password.RequiredLength = 6;

    options.User.RequireUniqueEmail = true;

    options.Lockout.MaxFailedAccessAttempts = 5;
    options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(5);
})
    .AddEntityFrameworkStores<LibraryDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromDays(14);
    options.SlidingExpiration = true;
});

// ---------- Đăng nhập Google / Facebook ----------
// ClientId/ClientSecret đọc từ appsettings.json (mục "Authentication"). Chỉ bật provider nào
// đã điền đủ Id/Secret để tránh app báo lỗi lúc khởi động khi chưa cấu hình xong OAuth.
var googleClientId = builder.Configuration["Authentication:Google:ClientId"];
var googleClientSecret = builder.Configuration["Authentication:Google:ClientSecret"];
var facebookAppId = builder.Configuration["Authentication:Facebook:AppId"];
var facebookAppSecret = builder.Configuration["Authentication:Facebook:AppSecret"];

var authBuilder = builder.Services.AddAuthentication();

if (!string.IsNullOrWhiteSpace(googleClientId) && !string.IsNullOrWhiteSpace(googleClientSecret))
{
    authBuilder.AddGoogle(GoogleDefaults.AuthenticationScheme, options =>
    {
        options.ClientId = googleClientId;
        options.ClientSecret = googleClientSecret;
    });
}

if (!string.IsNullOrWhiteSpace(facebookAppId) && !string.IsNullOrWhiteSpace(facebookAppSecret))
{
    authBuilder.AddFacebook(FacebookDefaults.AuthenticationScheme, options =>
    {
        options.AppId = facebookAppId;
        options.AppSecret = facebookAppSecret;
    });
}

// Đăng ký LoanService, CompensationService (AddScoped để khớp lifetime với DbContext,
// tránh lỗi "Cannot consume scoped service from singleton" khi dùng ở Giai đoạn 4-6)
builder.Services.AddScoped<LoanService>();
builder.Services.AddScoped<CompensationService>();

var app = builder.Build();

// Tự động áp dụng migration còn thiếu (bao gồm các bảng Identity mới) và nạp dữ liệu mẫu
// 15 cuốn sách kèm ảnh bìa nếu bảng Books đang trống, để chạy app lên là có sẵn dữ liệu để demo.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<LibraryDbContext>();
    db.Database.Migrate();
    QuanLyThuVIen.Infrastructure.SeedData.EnsureSeeded(db);
}

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
