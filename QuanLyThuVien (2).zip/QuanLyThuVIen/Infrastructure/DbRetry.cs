using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;

namespace QuanLyThuVIen.Infrastructure
{
    // Hàm dùng chung để thử lại 1 thao tác ghi CSDL khi SQL Server báo lỗi TẠM THỜI do
    // xung đột giao dịch (2 request chạy transaction Serializable gần như đồng thời).
    // Dùng cho LoanService/CompensationService thay vì để lỗi văng thẳng lên người dùng
    // ngay lần thử đầu tiên.
    public static class DbRetry
    {
        private const int MaxAttempts = 3;

        // Các mã lỗi SQL Server được coi là "tạm thời", nên thử lại thay vì báo lỗi ngay:
        // 1205 = Deadlock victim, 3960 = Xung đột snapshot isolation, 1222 = Hết thời gian chờ khóa
        private static readonly HashSet<int> TransientErrorNumbers = new() { 1205, 3960, 1222 };

        // Bắt buộc truyền vào context: sau 1 lần thử thất bại (transaction đã rollback ở DB),
        // các entity Added/Modified dở dang của lần thử đó VẪN còn bị EF Core theo dõi trong bộ nhớ
        // (rollback DB không tự xóa change tracker). Nếu không dọn, lần thử lại có thể chèn/ghi
        // trùng dữ liệu cũ của lần thất bại. Nên PHẢI gọi ChangeTracker.Clear() trước khi thử lại
        // để action() chạy lại hoàn toàn "sạch" như lần đầu.
        public static T Execute<T>(DbContext context, Func<T> action)
        {
            for (int attempt = 1; attempt <= MaxAttempts; attempt++)
            {
                try
                {
                    return action();
                }
                catch (SqlException ex) when (attempt < MaxAttempts && TransientErrorNumbers.Contains(ex.Number))
                {
                    context.ChangeTracker.Clear();
                    // Chờ tăng dần theo số lần thử để giảm khả năng 2 request lại đụng nhau ngay lập tức
                    Thread.Sleep(100 * attempt);
                }
            }

            // Không thể tới đây: vòng lặp trên luôn return ở lần thành công, hoặc throw ở lần thử cuối
            // (vì điều kiện "attempt < MaxAttempts" sai nên catch không bắt nữa). Viết để trình biên
            // dịch không báo thiếu return/throw ở cuối hàm.
            throw new InvalidOperationException("Không thể thực hiện thao tác sau nhiều lần thử lại.");
        }
    }
}
