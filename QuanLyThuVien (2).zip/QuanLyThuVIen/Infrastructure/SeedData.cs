using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Infrastructure
{
    // Dữ liệu mẫu 15 mã sách kèm ảnh bìa (ImageUrl lấy từ Open Library Covers API - dịch vụ
    // ảnh bìa sách công khai, miễn phí, dùng ISBN để tra cứu: https://covers.openlibrary.org).
    // Sách chỉ được chèn khi bảng Books đang trống, để không tạo trùng mỗi lần khởi động app
    // và không ghi đè dữ liệu người dùng đã tự nhập.
    // Đầu sách (BookCopy) được bổ sung riêng cho những mã sách CHƯA có đầu sách nào: nhờ vậy
    // CSDL cũ (đã seed sách nhưng chưa có đầu sách) cũng được tự sửa, mà không đụng tới
    // những mã sách người dùng đã tự thêm đầu sách.
    public static class SeedData
    {
        public static void EnsureSeeded(LibraryDbContext context)
        {
            if (!context.Books.Any())
            {
                SeedBooks(context);
            }

            SeedBookCopies(context);
        }

        // Số đầu sách mẫu tạo cho mỗi mã sách chưa có đầu sách nào
        private const int SampleCopiesPerBook = 3;

        // Tạo đầu sách mẫu (001, 002, 003) ở tình trạng Available cho mã sách chưa có đầu sách.
        // Lý do: LoanService chỉ cho mượn khi có BookCopy Available, nếu chỉ seed Book thì
        // mọi mã sách đều bị báo "không còn đầu sách nào trống".
        private static void SeedBookCopies(LibraryDbContext context)
        {
            // Lấy 1 lần danh sách mã sách đã có đầu sách rồi ToList() để tránh xung đột DataReader
            var codesWithCopies = context.BookCopies
                .Select(c => c.BookCode)
                .Distinct()
                .ToList();

            var codesWithoutCopies = context.Books
                .Where(b => !codesWithCopies.Contains(b.BookCode))
                .Select(b => b.BookCode)
                .ToList();

            if (codesWithoutCopies.Count == 0)
            {
                return;
            }

            var copies = new List<BookCopy>();
            foreach (var bookCode in codesWithoutCopies)
            {
                for (int i = 1; i <= SampleCopiesPerBook; i++)
                {
                    copies.Add(new BookCopy
                    {
                        BookCode = bookCode,
                        ControlNumber = i.ToString("D3"),
                        Status = BookCopyStatus.Available
                    });
                }
            }

            context.BookCopies.AddRange(copies);
            context.SaveChanges();
        }

        private static void SeedBooks(LibraryDbContext context)
        {
            var books = new List<Book>
            {
                new() {
                    BookCode = "VH001", Title = "1984", Author = "George Orwell",
                    Genre = "Viễn tưởng", PublicationYear = 1949, Publisher = "Secker & Warburg",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780451524935-L.jpg"
                },
                new() {
                    BookCode = "VH002", Title = "To Kill a Mockingbird", Author = "Harper Lee",
                    Genre = "Văn học kinh điển", PublicationYear = 1960, Publisher = "J. B. Lippincott & Co.",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780061120084-L.jpg"
                },
                new() {
                    BookCode = "VH003", Title = "Harry Potter and the Sorcerer's Stone", Author = "J.K. Rowling",
                    Genre = "Thiếu nhi - Giả tưởng", PublicationYear = 1997, Publisher = "Bloomsbury",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780590353427-L.jpg"
                },
                new() {
                    BookCode = "VH004", Title = "The Great Gatsby", Author = "F. Scott Fitzgerald",
                    Genre = "Văn học kinh điển", PublicationYear = 1925, Publisher = "Charles Scribner's Sons",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780743273565-L.jpg"
                },
                new() {
                    BookCode = "VH005", Title = "Pride and Prejudice", Author = "Jane Austen",
                    Genre = "Văn học kinh điển", PublicationYear = 1813, Publisher = "T. Egerton",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780141439518-L.jpg"
                },
                new() {
                    BookCode = "VH006", Title = "The Hobbit", Author = "J.R.R. Tolkien",
                    Genre = "Giả tưởng", PublicationYear = 1937, Publisher = "George Allen & Unwin",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780547928227-L.jpg"
                },
                new() {
                    BookCode = "VH007", Title = "Sapiens: A Brief History of Humankind", Author = "Yuval Noah Harari",
                    Genre = "Khoa học - Lịch sử", PublicationYear = 2011, Publisher = "Harvill Secker",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780062316097-L.jpg"
                },
                new() {
                    BookCode = "VH008", Title = "The Alchemist", Author = "Paulo Coelho",
                    Genre = "Tiểu thuyết", PublicationYear = 1988, Publisher = "HarperTorch",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780061122415-L.jpg"
                },
                new() {
                    BookCode = "VH009", Title = "How to Win Friends and Influence People", Author = "Dale Carnegie",
                    Genre = "Kỹ năng sống", PublicationYear = 1936, Publisher = "Simon & Schuster",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780671027032-L.jpg"
                },
                new() {
                    BookCode = "VH010", Title = "The Da Vinci Code", Author = "Dan Brown",
                    Genre = "Trinh thám", PublicationYear = 2003, Publisher = "Doubleday",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780307474278-L.jpg"
                },
                new() {
                    BookCode = "VH011", Title = "The Catcher in the Rye", Author = "J.D. Salinger",
                    Genre = "Văn học kinh điển", PublicationYear = 1951, Publisher = "Little, Brown and Company",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780316769488-L.jpg"
                },
                new() {
                    BookCode = "VH012", Title = "Animal Farm", Author = "George Orwell",
                    Genre = "Ngụ ngôn - Chính trị", PublicationYear = 1945, Publisher = "Secker & Warburg",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780451526342-L.jpg"
                },
                new() {
                    BookCode = "VH013", Title = "Brave New World", Author = "Aldous Huxley",
                    Genre = "Viễn tưởng", PublicationYear = 1932, Publisher = "Chatto & Windus",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780060850524-L.jpg"
                },
                new() {
                    BookCode = "VH014", Title = "The Little Prince", Author = "Antoine de Saint-Exupéry",
                    Genre = "Thiếu nhi", PublicationYear = 1943, Publisher = "Reynal & Hitchcock",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9780156012195-L.jpg"
                },
                new() {
                    BookCode = "VH015", Title = "Think and Grow Rich", Author = "Napoleon Hill",
                    Genre = "Kỹ năng sống", PublicationYear = 1937, Publisher = "The Ralston Society",
                    ImageUrl = "https://covers.openlibrary.org/b/isbn/9781585424337-L.jpg"
                },
            };

            context.Books.AddRange(books);
            context.SaveChanges();
        }
    }
}
