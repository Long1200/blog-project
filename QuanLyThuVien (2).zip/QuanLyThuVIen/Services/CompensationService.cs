using Microsoft.EntityFrameworkCore;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Services
{
    // Service xử lý nghiệp vụ bồi thường: đánh dấu case đã bồi thường,
    // kiểm tra và mở lại thẻ khi thẻ đã hết case chưa xử lý.
    public class CompensationService
    {
        private readonly LibraryDbContext _context;

        public CompensationService(LibraryDbContext context)
        {
            _context = context;
        }

        // Lấy danh sách case bồi thường chưa xử lý (IsResolved = false) của 1 thẻ.
        // Include tới BookCopy/Book để View hiển thị được tên sách mà không cần query lại.
        // Chỉ đọc dữ liệu nên không cần transaction/retry.
        public List<CompensationCase> GetUnresolvedCases(string cardNumber)
        {
            return _context.CompensationCases
                .Include(c => c.LoanDetail)
                    .ThenInclude(ld => ld!.BookCopy)
                        .ThenInclude(bc => bc!.Book)
                .Where(c => c.CardNumber == cardNumber && !c.IsResolved)
                .OrderBy(c => c.CreatedDate)
                .ToList();
        }

        // Đánh dấu 1 case đã bồi thường xong (IsResolved = true, ResolvedDate = resolvedDate),
        // sau đó gọi TryReactivateCard để kiểm tra mở lại thẻ nếu không còn case nào chưa xử lý.
        public (bool Success, string ErrorMessage) Resolve(int compensationCaseId, DateTime resolvedDate)
        {
            // Dùng Serializable + DbRetry như LoanService: tránh 2 request cùng xử lý bồi thường
            // cho các case khác nhau của cùng 1 thẻ chạy gần như đồng thời (có thể khiến
            // TryReactivateCard đọc nhầm dữ liệu), và tự thử lại nếu SQL Server báo lỗi tạm thời.
            return DbRetry.Execute(_context, () =>
            {
                using var transaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
                try
                {
                    var compensationCase = _context.CompensationCases.Find(compensationCaseId);
                    if (compensationCase == null)
                    {
                        transaction.Rollback();
                        return (false, "Không tìm thấy case bồi thường.");
                    }

                    if (compensationCase.IsResolved)
                    {
                        transaction.Rollback();
                        return (false, "Case này đã được bồi thường trước đó.");
                    }

                    compensationCase.IsResolved = true;
                    compensationCase.ResolvedDate = resolvedDate;
                    _context.SaveChanges();

                    // Gọi ngay trong transaction hiện tại (cùng _context) để việc mở thẻ (nếu có)
                    // và việc đánh dấu case đã bồi thường được commit/rollback cùng nhau.
                    TryReactivateCard(compensationCase.CardNumber);

                    transaction.Commit();
                    return (true, string.Empty);
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            });
        }

        // Kiểm tra 1 thẻ còn CompensationCase nào chưa xử lý (IsResolved = false) không;
        // nếu hết thì mở lại thẻ (LibraryCard.Status = Active) và trả về true.
        // Được gọi từ Resolve (đã có transaction + retry bên ngoài); nếu gọi độc lập thì tự chạy
        // trực tiếp trên _context, không cần transaction riêng vì chỉ đọc + ghi trên 1 thẻ.
        public bool TryReactivateCard(string cardNumber)
        {
            bool hasUnresolvedCase = _context.CompensationCases
                .Any(c => c.CardNumber == cardNumber && !c.IsResolved);

            if (hasUnresolvedCase)
            {
                return false;
            }

            var card = _context.LibraryCards.Find(cardNumber);
            if (card == null)
            {
                return false;
            }

            card.Status = LibraryCardStatus.Active;
            _context.SaveChanges();
            return true;
        }
    }
}
