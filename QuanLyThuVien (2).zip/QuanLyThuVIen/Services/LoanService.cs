using Microsoft.EntityFrameworkCore;
using QuanLyThuVIen.Infrastructure;
using QuanLyThuVIen.Models;

namespace QuanLyThuVIen.Services
{
    // Service xử lý toàn bộ nghiệp vụ liên quan tới phiếu mượn (Loan/LoanDetail):
    // tạo phiếu mượn, trả sách, báo mất/báo hỏng.
    public class LoanService
    {
        private readonly LibraryDbContext _context;

        public LoanService(LibraryDbContext context)
        {
            _context = context;
        }

        // Tạo phiếu mượn mới cho 1 thẻ với danh sách mã sách được chọn (tối đa 3 mã).
        // Trả về Success=false kèm ErrorMessage nếu không tạo được, ngược lại trả về Loan vừa tạo.
        public (bool Success, string ErrorMessage, Loan? Loan) CreateLoan(string cardNumber, List<string> bookCodes, DateTime loanDate)
        {
            // ----- Validate định dạng cơ bản (không cần đọc DB) làm trước, ngoài transaction,
            // để không giữ khóa DB một cách không cần thiết khi dữ liệu đầu vào đã sai rõ ràng -----
            if (bookCodes == null || bookCodes.Count == 0)
            {
                return (false, "Phải chọn ít nhất 1 mã sách để mượn.", null);
            }
            if (bookCodes.Count > 3)
            {
                return (false, "Mỗi lần mượn tối đa 3 mã sách.", null);
            }
            if (bookCodes.Distinct().Count() != bookCodes.Count)
            {
                return (false, "Danh sách mã sách bị trùng lặp, mỗi mã chỉ được chọn 1 lần.", null);
            }

            // ----- Toàn bộ phần đọc + ghi còn lại nằm trong 1 transaction mức Serializable để
            // tránh 2 request tạo phiếu mượn gần như đồng thời (cùng 1 thẻ, hoặc cùng tranh nhau
            // đầu sách cuối cùng) đọc thấy dữ liệu "còn hợp lệ" trước khi bên kia kịp ghi.
            // Bọc thêm DbRetry.Execute: nếu SQL Server báo lỗi tạm thời (deadlock...) do 2 giao
            // dịch Serializable đụng nhau, tự động thử lại thay vì báo lỗi ngay cho người dùng. -----
            return DbRetry.Execute(_context, () =>
            {
                using var transaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
                try
                {
                    // ----- 1) Thẻ phải tồn tại -----
                    var card = _context.LibraryCards.Find(cardNumber);
                    if (card == null)
                    {
                        transaction.Rollback();
                        return (false, "Không tìm thấy thẻ thư viện.", null);
                    }

                    // ----- 2) Thẻ phải đang Active (chưa bị khóa do mất/hỏng sách chưa bồi thường...) -----
                    if (card.Status != LibraryCardStatus.Active)
                    {
                        transaction.Rollback();
                        return (false, "Thẻ thư viện đang bị khóa, không thể mượn sách.", null);
                    }

                    // ----- 3) Thẻ chưa hết hạn tính theo ngày mượn -----
                    if (card.ExpiryDate.Date < loanDate.Date)
                    {
                        transaction.Rollback();
                        return (false, "Thẻ thư viện đã hết hạn, không thể mượn sách.", null);
                    }

                    // ----- 4) Thẻ không được có phiếu mượn đang dở dang -----
                    // Tính runtime: chỉ cần còn 1 LoanDetail của thẻ này đang Status = Borrowed
                    // là coi như còn phiếu chưa trả hết, EF Core tự join qua navigation Loan.
                    bool hasActiveLoan = _context.LoanDetails
                        .Any(ld => ld.Loan!.CardNumber == cardNumber && ld.Status == LoanDetailStatus.Borrowed);
                    if (hasActiveLoan)
                    {
                        transaction.Rollback();
                        return (false, "Thẻ đang có phiếu mượn chưa trả hết, không thể mượn tiếp.", null);
                    }

                    // ----- 5) Từng mã sách phải tồn tại trong hệ thống -----
                    foreach (var bookCode in bookCodes)
                    {
                        bool bookExists = _context.Books.Any(b => b.BookCode == bookCode);
                        if (!bookExists)
                        {
                            transaction.Rollback();
                            return (false, $"Mã sách '{bookCode}' không tồn tại.", null);
                        }
                    }

                    // ----- 6) Chọn 1 BookCopy đang Available cho từng mã sách + tạo Loan/LoanDetail -----
                    var loan = new Loan
                    {
                        CardNumber = cardNumber,
                        LoanDate = loanDate,
                        // Hạn trả = ngày mượn + tối đa 15 ngày theo quy định của thư viện
                        DueDate = loanDate.AddDays(15)
                    };
                    _context.Loans.Add(loan);

                    foreach (var bookCode in bookCodes)
                    {
                        var copy = _context.BookCopies
                            .FirstOrDefault(c => c.BookCode == bookCode && c.Status == BookCopyStatus.Available);

                        if (copy == null)
                        {
                            // Không còn đầu sách nào trống: rollback toàn bộ, không tạo phiếu dở dang
                            transaction.Rollback();
                            return (false, $"Mã sách '{bookCode}' hiện không còn đầu sách nào trống để cho mượn.", null);
                        }

                        copy.Status = BookCopyStatus.Borrowed;

                        loan.LoanDetails.Add(new LoanDetail
                        {
                            BookCopyId = copy.BookCopyId,
                            Status = LoanDetailStatus.Borrowed
                        });
                    }

                    _context.SaveChanges();
                    transaction.Commit();

                    return (true, string.Empty, loan);
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            });
        }

        // Lấy danh sách phiếu mượn đang hoạt động của 1 thẻ, tính RUNTIME dựa vào
        // LoanDetail còn dòng nào Status = Borrowed (không lưu cột Status riêng ở Loan).
        // Include BookCopy + Book để View hiển thị được tên sách mà không cần query lại.
        // Chỉ đọc dữ liệu (không ghi) nên không cần transaction/retry.
        public List<Loan> GetActiveLoans(string cardNumber)
        {
            return _context.Loans
                .Include(l => l.LoanDetails)
                    .ThenInclude(ld => ld.BookCopy)
                        .ThenInclude(bc => bc!.Book)
                .Where(l => l.CardNumber == cardNumber
                    && l.LoanDetails.Any(ld => ld.Status == LoanDetailStatus.Borrowed))
                .OrderByDescending(l => l.LoanDate)
                .ToList();
        }

        // Trả sách cho 1 dòng mượn cụ thể: cập nhật LoanDetail (ReturnDate, Status = Returned),
        // cập nhật BookCopy tương ứng về Status = Available.
        public (bool Success, string ErrorMessage) Return(int loanDetailId, DateTime returnDate)
        {
            // Dùng Serializable + DbRetry như CreateLoan: tránh trường hợp 2 request cùng trả
            // (hoặc 1 request trả + 1 request báo mất/hỏng) trên cùng 1 LoanDetail chạy gần như
            // đồng thời, và tự thử lại nếu SQL Server báo lỗi tạm thời do 2 giao dịch đụng nhau.
            return DbRetry.Execute(_context, () =>
            {
                using var transaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
                try
                {
                    var detail = _context.LoanDetails
                        .Include(ld => ld.BookCopy)
                        .FirstOrDefault(ld => ld.LoanDetailId == loanDetailId);

                    if (detail == null)
                    {
                        transaction.Rollback();
                        return (false, "Không tìm thấy dòng mượn.");
                    }

                    if (detail.Status != LoanDetailStatus.Borrowed)
                    {
                        transaction.Rollback();
                        return (false, "Dòng mượn này không ở trạng thái đang mượn, không thể trả.");
                    }

                    detail.ReturnDate = returnDate;
                    detail.Status = LoanDetailStatus.Returned;

                    if (detail.BookCopy != null)
                    {
                        detail.BookCopy.Status = BookCopyStatus.Available;
                    }

                    _context.SaveChanges();
                    transaction.Commit();

                    return (true, string.Empty);
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            });
        }

        // Báo mất/báo hỏng cho 1 dòng mượn cụ thể: cập nhật LoanDetail (Status = Lost/Damaged),
        // cập nhật BookCopy tương ứng (Status = Lost/Damaged), tạo CompensationCase, khóa thẻ
        // (LibraryCard.Status = Inactive).
        public (bool Success, string ErrorMessage) ReportLostOrDamaged(int loanDetailId, CompensationReason reason, DateTime reportDate)
        {
            return DbRetry.Execute(_context, () =>
            {
                using var transaction = _context.Database.BeginTransaction(System.Data.IsolationLevel.Serializable);
                try
                {
                    var detail = _context.LoanDetails
                        .Include(ld => ld.BookCopy)
                        .Include(ld => ld.Loan)
                        .FirstOrDefault(ld => ld.LoanDetailId == loanDetailId);

                    if (detail == null)
                    {
                        transaction.Rollback();
                        return (false, "Không tìm thấy dòng mượn.");
                    }

                    if (detail.Status != LoanDetailStatus.Borrowed)
                    {
                        transaction.Rollback();
                        return (false, "Dòng mượn này không ở trạng thái đang mượn, không thể báo mất/hỏng.");
                    }

                    // Loan là FK bắt buộc (Required) của LoanDetail nên chắc chắn tồn tại; đã Include ở trên.
                    var cardNumber = detail.Loan!.CardNumber;

                    detail.Status = reason == CompensationReason.Lost
                        ? LoanDetailStatus.Lost
                        : LoanDetailStatus.Damaged;

                    if (detail.BookCopy != null)
                    {
                        detail.BookCopy.Status = reason == CompensationReason.Lost
                            ? BookCopyStatus.Lost
                            : BookCopyStatus.Damaged;
                    }

                    _context.CompensationCases.Add(new CompensationCase
                    {
                        LoanDetailId = detail.LoanDetailId,
                        CardNumber = cardNumber,
                        Reason = reason,
                        CreatedDate = reportDate,
                        IsResolved = false
                    });

                    // Khóa thẻ ngay khi phát sinh case bồi thường; chỉ mở lại khi hết case chưa xử lý
                    // (xử lý ở CompensationService.TryReactivateCard)
                    var card = _context.LibraryCards.Find(cardNumber);
                    if (card != null)
                    {
                        card.Status = LibraryCardStatus.Inactive;
                    }

                    _context.SaveChanges();
                    transaction.Commit();

                    return (true, string.Empty);
                }
                catch
                {
                    transaction.Rollback();
                    throw;
                }
            });
        }
    }
}
